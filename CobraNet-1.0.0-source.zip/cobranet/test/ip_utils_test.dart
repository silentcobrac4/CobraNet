import 'package:cobranet/core/ip_utils.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('IpUtils.toInt / fromInt', () {
    test('round-trips IPv4 addresses', () {
      expect(IpUtils.toInt('0.0.0.0'), 0);
      expect(IpUtils.toInt('255.255.255.255'), 0xFFFFFFFF);
      expect(IpUtils.toInt('192.168.1.10'), 0xC0A8010A);
      expect(IpUtils.fromInt(0xC0A8010A), '192.168.1.10');
    });

    test('rejects malformed addresses', () {
      expect(IpUtils.toInt(null), isNull);
      expect(IpUtils.toInt('192.168.1'), isNull);
      expect(IpUtils.toInt('192.168.1.256'), isNull);
      expect(IpUtils.toInt('192.168.1.-1'), isNull);
      expect(IpUtils.toInt('192.168.1.a'), isNull);
      expect(IpUtils.toInt('192.168.1.1.1'), isNull);
    });
  });

  group('private ranges', () {
    test('detects RFC1918 and loopback', () {
      expect(IpUtils.isPrivate('10.0.0.1'), isTrue);
      expect(IpUtils.isPrivate('172.16.0.1'), isTrue);
      expect(IpUtils.isPrivate('172.31.255.254'), isTrue);
      expect(IpUtils.isPrivate('192.168.0.1'), isTrue);
      expect(IpUtils.isPrivate('127.0.0.1'), isTrue);
      expect(IpUtils.isPrivate('169.254.1.1'), isTrue);
    });

    test('rejects public addresses', () {
      expect(IpUtils.isPrivate('8.8.8.8'), isFalse);
      expect(IpUtils.isPrivate('172.32.0.1'), isFalse);
      expect(IpUtils.isPrivate('1.1.1.1'), isFalse);
    });
  });

  group('netmask conversion', () {
    test('prefix to mask', () {
      expect(IpUtils.maskFromPrefix(0), '0.0.0.0');
      expect(IpUtils.maskFromPrefix(8), '255.0.0.0');
      expect(IpUtils.maskFromPrefix(24), '255.255.255.0');
      expect(IpUtils.maskFromPrefix(32), '255.255.255.255');
    });

    test('mask to prefix', () {
      expect(IpUtils.prefixFromMask('255.255.255.0'), 24);
      expect(IpUtils.prefixFromMask('255.0.0.0'), 8);
      expect(IpUtils.prefixFromMask('0.0.0.0'), 0);
      expect(IpUtils.prefixFromMask('255.255.255.255'), 32);
    });

    test('rejects non-contiguous masks', () {
      expect(IpUtils.prefixFromMask('255.0.255.0'), isNull);
      expect(IpUtils.prefixFromMask('nonsense'), isNull);
    });
  });

  group('subnet maths', () {
    test('computes a /24', () {
      final info = IpUtils.parseSubnet('192.168.1.42/24')!;
      expect(info.network, '192.168.1.0');
      expect(info.broadcast, '192.168.1.255');
      expect(info.firstHost, '192.168.1.1');
      expect(info.lastHost, '192.168.1.254');
      expect(info.mask, '255.255.255.0');
      expect(info.wildcard, '0.0.0.255');
      expect(info.hostCount, 254);
      expect(info.totalAddresses, 256);
      expect(info.cidr, '192.168.1.0/24');
      expect(info.isPrivate, isTrue);
    });

    test('handles a /30', () {
      final info = IpUtils.parseSubnet('10.0.0.6/30')!;
      expect(info.network, '10.0.0.4');
      expect(info.broadcast, '10.0.0.7');
      expect(info.firstHost, '10.0.0.5');
      expect(info.lastHost, '10.0.0.6');
      expect(info.hostCount, 2);
    });

    test('handles /31 and /32 edge cases', () {
      expect(IpUtils.hostCount(31), 2);
      expect(IpUtils.hostCount(32), 1);
      final single = IpUtils.parseSubnet('8.8.8.8/32')!;
      expect(single.network, '8.8.8.8');
      expect(single.broadcast, '8.8.8.8');
      expect(single.totalAddresses, 1);
    });

    test('bare addresses assume /24', () {
      final info = IpUtils.parseSubnet('192.168.0.10')!;
      expect(info.prefix, 24);
      expect(info.cidr, '192.168.0.0/24');
    });

    test('returns null for bad input', () {
      expect(IpUtils.parseSubnet(''), isNull);
      expect(IpUtils.parseSubnet('192.168.1.0/33'), isNull);
      expect(IpUtils.parseSubnet('999.1.1.1/24'), isNull);
    });
  });

  group('host enumeration', () {
    test('lists usable hosts', () {
      final hosts = IpUtils.hosts('192.168.1.10', 30);
      expect(hosts, ['192.168.1.9', '192.168.1.10']);
    });

    test('caps huge ranges', () {
      final hosts = IpUtils.hosts('10.0.0.1', 8, cap: 100);
      expect(hosts.length, 100);
      expect(hosts.first, '10.0.0.1');
    });
  });

  group('MacUtils', () {
    test('validates MAC addresses', () {
      expect(MacUtils.isValid('AA:BB:CC:DD:EE:FF'), isTrue);
      expect(MacUtils.isValid('aa-bb-cc-dd-ee-ff'), isTrue);
      expect(MacUtils.isValid('aabbccddeeff'), isTrue);
      expect(MacUtils.isValid('AA:BB:CC:DD:EE'), isFalse);
      expect(MacUtils.isValid('ZZ:BB:CC:DD:EE:FF'), isFalse);
      expect(MacUtils.isValid(null), isFalse);
    });

    test('normalizes separators and case', () {
      expect(MacUtils.normalize('aa-bb-cc-dd-ee-ff'), 'AA:BB:CC:DD:EE:FF');
      expect(MacUtils.normalize('aabb.ccdd.eeff'), 'AA:BB:CC:DD:EE:FF');
    });

    test('splits into bytes', () {
      expect(MacUtils.toBytes('AA:BB:CC:DD:EE:FF'),
          [0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF]);
      expect(MacUtils.toBytes('bad'), isEmpty);
    });
  });

  group('connection type helpers', () {
    test('multicast detection', () {
      expect(IpUtils.isMulticast('224.0.0.1'), isTrue);
      expect(IpUtils.isMulticast('192.168.1.1'), isFalse);
    });
  });
}
