import 'package:cobranet/models/device.dart';
import 'package:cobranet/models/scan_snapshot.dart';
import 'package:cobranet/models/settings.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Device', () {
    test('serialises and restores', () {
      final device = Device(
        ip: '192.168.1.20',
        mac: 'AA:BB:CC:DD:EE:FF',
        hostname: 'printer.local',
        customName: 'Office printer',
        notes: 'Second floor',
        favorite: true,
        latencyMs: 12,
        openPorts: [80, 631],
        type: DeviceType.printer,
        saved: true,
      );
      final restored = Device.fromJson(device.toJson());
      expect(restored.ip, device.ip);
      expect(restored.mac, device.mac);
      expect(restored.customName, 'Office printer');
      expect(restored.type, DeviceType.printer);
      expect(restored.openPorts, [80, 631]);
      expect(restored.favorite, isTrue);
      expect(restored.notes, 'Second floor');
    });

    test('display name prefers custom name then hostname', () {
      final base = Device(ip: '10.0.0.5');
      expect(base.displayName, '10.0.0.5');
      expect(base.copyWith(hostname: 'nas').displayName, 'nas');
      expect(
        base.copyWith(hostname: 'nas', customName: 'Backup box').displayName,
        'Backup box',
      );
    });

    test('identity follows the MAC when available', () {
      expect(Device(ip: '10.0.0.5').identity, 'ip:10.0.0.5');
      expect(
        Device(ip: '10.0.0.5', mac: 'aa-bb-cc-dd-ee-ff').identity,
        'mac:AA:BB:CC:DD:EE:FF',
      );
    });

    test('infers a router from the gateway', () {
      expect(
        Device.inferType(ip: '192.168.1.1', gateway: '192.168.1.1'),
        DeviceType.router,
      );
      expect(
        Device.inferType(
          ip: '192.168.1.7',
          localIp: '192.168.1.7',
          gateway: '192.168.1.1',
        ),
        DeviceType.thisDevice,
      );
    });

    test('infers from hostname and ports', () {
      expect(
        Device.inferType(ip: '10.0.0.2', hostname: 'HP-Printer'),
        DeviceType.printer,
      );
      expect(
        Device.inferType(ip: '10.0.0.3', ports: [554]),
        DeviceType.camera,
      );
      expect(Device.inferType(ip: '10.0.0.4'), DeviceType.unknown);
    });
  });

  group('ScanSnapshot', () {
    test('round-trips through JSON', () {
      final snapshot = ScanSnapshot(
        startedAt: DateTime(2026, 1, 2, 3, 4),
        finishedAt: DateTime(2026, 1, 2, 3, 5),
        devices: [Device(ip: '192.168.1.2', online: true)],
        ssid: 'Home',
        localIp: '192.168.1.2',
        gateway: '192.168.1.1',
        cidr: '192.168.1.2/24',
      );
      final restored = ScanSnapshot.fromJson(snapshot.toJson());
      expect(restored.devices.length, 1);
      expect(restored.ssid, 'Home');
      expect(restored.onlineCount, 1);
      expect(restored.duration.inMinutes, 1);
    });
  });

  group('Settings', () {
    test('clamps out-of-range values', () {
      final settings = Settings.fromJson({
        'pingCount': 999,
        'scanConcurrency': 0,
        'scanTimeoutMs': 1,
      });
      expect(settings.pingCount, 50);
      expect(settings.scanConcurrency, 1);
      expect(settings.scanTimeoutMs, 200);
    });

    test('falls back to sensible defaults', () {
      final settings = Settings.fromJson({});
      expect(settings.theme, ThemeMode.system);
      expect(settings.pingCount, 4);
      expect(settings.deepScan, isTrue);
      expect(settings.locale, isNull);
    });
  });
}
