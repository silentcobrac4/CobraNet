import 'package:cupertino_ui/cupertino_ui.dart' show GlobalCupertinoLocalizations;
import 'package:flutter_localizations/flutter_localizations.dart'
    show GlobalWidgetsLocalizations;
import 'package:material_ui/material_ui.dart';

import 'core/theme.dart';
import 'screens/root_shell.dart';
import 'state/app_state.dart';

class CobraNetApp extends StatelessWidget {
  const CobraNetApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final locale = state.settings.locale;
        return MaterialApp(
          title: 'CobraNet',
          debugShowCheckedModeBanner: false,
          locale: locale == null ? null : Locale(locale),
          supportedLocales: const [Locale('ar'), Locale('en')],
          localeListResolutionCallback: (locales, supported) {
            for (final item in locales ?? const <Locale>[]) {
              if (item.languageCode == 'ar') return const Locale('ar');
            }
            return const Locale('en');
          },
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: AppTheme.build(Brightness.light),
          darkTheme: AppTheme.build(Brightness.dark),
          themeMode: state.settings.theme,
          home: const RootShell(),
        );
      },
    );
  }
}
