import 'package:material_ui/material_ui.dart';

import 'app.dart';
import 'services/oui_service.dart';
import 'services/store.dart';
import 'state/app_state.dart';
import 'state/global.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await Store.open();
  await OuiService.ensureLoaded();
  app = AppState(store);
  await app.init();
  runApp(CobraNetApp(state: app));
}
