import 'app_state.dart';

/// The single app state instance. Set in `main()` before `runApp`.
late AppState app;
