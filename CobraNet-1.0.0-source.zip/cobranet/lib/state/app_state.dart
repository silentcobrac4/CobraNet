import 'package:material_ui/material_ui.dart';

import '../core/ip_utils.dart';
import '../models/device.dart';
import '../models/history_entry.dart';
import '../models/scan_snapshot.dart';
import '../models/settings.dart';
import '../services/network_info_service.dart';
import '../services/scanner.dart';
import '../services/store.dart';

class AppState extends ChangeNotifier {
  AppState(this.store)
      : settings = store.readSettings(),
        knownDevices = store.readKnownDevices(),
        history = store.readHistory(),
        lastScan = store.readLastScan() {
    scan = ScanController(
      store: store,
      getSettings: () => settings,
      getKnown: () => knownDevices,
      onSnapshot: _handleSnapshot,
    );
  }

  final Store store;
  Settings settings;
  List<Device> knownDevices;
  List<HistoryEntry> history;
  ScanSnapshot? lastScan;
  NetInfo? netInfo;
  bool netInfoLoading = false;
  late final ScanController scan;

  Future<void> init() async {
    netInfo = await NetworkInfoService.detect();
    notifyListeners();
  }

  Future<void> refreshNetwork() async {
    netInfoLoading = true;
    notifyListeners();
    netInfo = await NetworkInfoService.detect();
    netInfoLoading = false;
    notifyListeners();
    return;
  }

  Future<void> updateSettings(Settings next) async {
    settings = next;
    notifyListeners();
    await store.writeSettings(next);
  }

  Future<void> setTheme(ThemeMode mode) =>
      updateSettings(settings.copyWith(theme: mode));

  Future<void> setLocale(String? locale) => updateSettings(
        locale == null
            ? settings.copyWith(clearLocale: true)
            : settings.copyWith(locale: locale),
      );

  void addHistory({
    required String tool,
    required String query,
    required String summary,
    String? detail,
    bool ok = true,
  }) {
    final entry = HistoryEntry(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      tool: tool,
      query: query,
      summary: summary,
      detail: detail,
      createdAt: DateTime.now(),
      ok: ok,
    );
    history = [entry, ...history].take(200).toList();
    store.writeHistory(history);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    history = [];
    notifyListeners();
    await store.writeHistory(history);
  }

  Device? findKnown(Device device) {
    for (final item in knownDevices) {
      if (item.mac != null &&
          device.mac != null &&
          MacUtils.normalize(item.mac!) == MacUtils.normalize(device.mac!)) {
        return item;
      }
      if (item.ip == device.ip) return item;
    }
    return null;
  }

  Future<void> saveDevice(Device device) async {
    final updated = <Device>[...knownDevices];
    final index = updated.indexWhere((item) {
      if (item.mac != null &&
          device.mac != null &&
          MacUtils.normalize(item.mac!) == MacUtils.normalize(device.mac!)) {
        return true;
      }
      return item.ip == device.ip;
    });
    final toSave = device.copyWith(saved: true, lastSeen: DateTime.now());
    if (index >= 0) {
      updated[index] = toSave;
    } else {
      updated.add(toSave);
    }
    knownDevices = updated;
    scan.replaceDevice(toSave);
    notifyListeners();
    await store.writeKnownDevices(updated);
  }

  Future<void> removeKnown(Device device) async {
    knownDevices = knownDevices.where((item) {
      if (item.mac != null &&
          device.mac != null &&
          MacUtils.normalize(item.mac!) == MacUtils.normalize(device.mac!)) {
        return false;
      }
      return item.ip != device.ip;
    }).toList();
    scan.replaceDevice(
      device.copyWith(clearCustomName: true, clearNotes: true, favorite: false, saved: false),
    );
    notifyListeners();
    await store.writeKnownDevices(knownDevices);
  }

  void _handleSnapshot(ScanSnapshot snapshot) {
    lastScan = snapshot;
    store.writeLastScan(snapshot);
    addHistory(
      tool: 'scan',
      query: snapshot.ssid ?? snapshot.cidr ?? '',
      summary: '${snapshot.devices.length} أجهزة · ${snapshot.onlineCount} متصل',
      detail: snapshot.devices
          .map((d) => '${d.displayName} (${d.ip})')
          .join('\n'),
      ok: !snapshot.cancelled,
    );
    notifyListeners();
  }

  Future<void> importBackup(Map<String, dynamic> data) async {
    await store.importData(data);
    settings = store.readSettings();
    knownDevices = store.readKnownDevices();
    history = store.readHistory();
    lastScan = store.readLastScan();
    notifyListeners();
  }

  Map<String, dynamic> exportBackup() => store.exportData(
        settings: settings,
        knownDevices: knownDevices,
        history: history,
        lastScan: lastScan,
      );

  Future<void> resetEverything() async {
    await store.clearAll();
    settings = Settings();
    knownDevices = [];
    history = [];
    lastScan = null;
    notifyListeners();
  }
}

class ScanController extends ChangeNotifier {
  ScanController({
    required this.store,
    required this.getSettings,
    required this.getKnown,
    required this.onSnapshot,
  });

  final Store store;
  final Settings Function() getSettings;
  final List<Device> Function() getKnown;
  final void Function(ScanSnapshot snapshot) onSnapshot;

  bool running = false;
  bool cancelled = false;
  String? error;
  String phase = 'ping';
  int done = 0;
  int total = 0;
  int found = 0;
  List<Device> devices = [];
  DateTime? startedAt;
  Duration? lastDuration;
  bool _cancelRequested = false;
  DateTime _lastNotify = DateTime.fromMillisecondsSinceEpoch(0);

  double get fraction => total == 0 ? 0 : (done / total).clamp(0, 1);

  Future<void> start(NetInfo? info, {List<String>? hosts}) async {
    if (running) return;
    running = true;
    cancelled = false;
    error = null;
    phase = 'ping';
    done = 0;
    total = 0;
    found = 0;
    devices = [];
    startedAt = DateTime.now();
    _cancelRequested = false;
    notifyListeners();
    final net = info ?? await NetworkInfoService.detect();
    try {
      final result = await Scanner.scan(
        info: net,
        settings: getSettings(),
        known: getKnown(),
        hosts: hosts,
        onProgress: (progress) {
          phase = progress.phase;
          done = progress.done;
          total = progress.total;
          found = progress.found;
          final now = DateTime.now();
          if (now.difference(_lastNotify).inMilliseconds > 100 ||
              progress.done == progress.total) {
            _lastNotify = now;
            notifyListeners();
          }
        },
        isCancelled: () => _cancelRequested,
      );
      final finished = DateTime.now();
      lastDuration = finished.difference(startedAt ?? finished);
      devices = result;
      final snapshot = ScanSnapshot(
        startedAt: startedAt ?? finished,
        finishedAt: finished,
        devices: devices,
        ssid: net.ssid,
        localIp: net.ip,
        gateway: net.gateway,
        cidr: net.cidr,
        cancelled: _cancelRequested,
      );
      onSnapshot(snapshot);
    } catch (e) {
      error = e is ScanException ? e.message : '$e';
    } finally {
      running = false;
      notifyListeners();
    }
  }

  void cancel() {
    if (!running) return;
    _cancelRequested = true;
    notifyListeners();
  }

  void replaceDevice(Device device) {
    final index = devices.indexWhere((d) => d.identity == device.identity);
    if (index >= 0) {
      devices = [...devices]..[index] = device;
      notifyListeners();
    }
  }
}
