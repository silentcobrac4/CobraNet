import 'package:material_ui/material_ui.dart';
import 'package:intl/intl.dart';

/// Tiny two-language helper. Every user-visible string is written fresh here,
/// in Arabic and English, so the app has no dependency on a translation
/// service or on anyone else's copy.
extension L10nX on BuildContext {
  bool get isArabic => Localizations.localeOf(this).languageCode == 'ar';

  /// `tr('نص عربي', 'English text')`
  String tr(String ar, String en) => isArabic ? ar : en;

  String get localeName => isArabic ? 'ar' : 'en';

  DateFormat get dateFormat =>
      DateFormat.yMMMd(localeName).add_Hm();

  DateFormat get shortDateFormat => DateFormat.MMMd(localeName);

  DateFormat get timeFormat => DateFormat.Hm(localeName);
}

/// Formats a byte count for the UI.
String formatBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  final kb = bytes / 1024;
  if (kb < 1024) return '${kb.toStringAsFixed(kb < 10 ? 1 : 0)} KB';
  final mb = kb / 1024;
  if (mb < 1024) return '${mb.toStringAsFixed(mb < 10 ? 1 : 0)} MB';
  final gb = mb / 1024;
  return '${gb.toStringAsFixed(2)} GB';
}

String formatDuration(Duration d) {
  if (d.inSeconds < 1) return '${d.inMilliseconds} ms';
  if (d.inMinutes < 1) return '${(d.inMilliseconds / 1000).toStringAsFixed(1)} s';
  return '${d.inMinutes}m ${d.inSeconds % 60}s';
}

String twoDigits(int n) => n.toString().padLeft(2, '0');
