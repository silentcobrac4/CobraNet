/// Small, dependency-free IPv4 helpers: parsing, masks, CIDR maths and the
/// list of hosts a scan should probe.
class IpUtils {
  IpUtils._();

  static int? toInt(String? ip) {
    if (ip == null) return null;
    final parts = ip.trim().split('.');
    if (parts.length != 4) return null;
    var value = 0;
    for (final part in parts) {
      if (part.isEmpty || part.length > 3) return null;
      final n = int.tryParse(part);
      if (n == null || n < 0 || n > 255) return null;
      value = (value << 8) | n;
    }
    return value;
  }

  static String fromInt(int value) {
    final v = value & 0xFFFFFFFF;
    return '${(v >> 24) & 0xFF}.${(v >> 16) & 0xFF}.${(v >> 8) & 0xFF}.${v & 0xFF}';
  }

  static bool isValid(String? ip) => toInt(ip) != null;

  static bool isPrivate(String? ip) {
    final v = toInt(ip);
    if (v == null) return false;
    final a = (v >> 24) & 0xFF;
    final b = (v >> 16) & 0xFF;
    if (a == 10) return true;
    if (a == 172 && b >= 16 && b <= 31) return true;
    if (a == 192 && b == 168) return true;
    if (a == 127) return true;
    if (a == 169 && b == 254) return true;
    return false;
  }

  static bool isMulticast(String? ip) {
    final v = toInt(ip);
    if (v == null) return false;
    return ((v >> 24) & 0xFF) >= 224 && ((v >> 24) & 0xFF) <= 239;
  }

  /// Returns the prefix length for a dotted netmask, or null if invalid.
  static int? prefixFromMask(String? mask) {
    final v = toInt(mask);
    if (v == null) return null;
    var count = 0;
    var seenZero = false;
    for (var i = 31; i >= 0; i--) {
      final bit = (v >> i) & 1;
      if (bit == 1) {
        if (seenZero) return null;
        count++;
      } else {
        seenZero = true;
      }
    }
    return count;
  }

  static String maskFromPrefix(int prefix) {
    if (prefix <= 0) return '0.0.0.0';
    if (prefix >= 32) return '255.255.255.255';
    final value = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
    return fromInt(value);
  }

  static int networkInt(int ip, int prefix) {
    if (prefix <= 0) return 0;
    if (prefix >= 32) return ip & 0xFFFFFFFF;
    final mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
    return ip & mask;
  }

  static int broadcastInt(int ip, int prefix) {
    if (prefix >= 32) return ip;
    if (prefix <= 0) return 0xFFFFFFFF;
    final mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
    return (networkInt(ip, prefix) | (~mask & 0xFFFFFFFF)) & 0xFFFFFFFF;
  }

  static int hostCount(int prefix) {
    if (prefix >= 31) return prefix == 32 ? 1 : 2;
    return (1 << (32 - prefix)) - 2;
  }

  /// Usable hosts in the subnet, capped so a /8 does not freeze a phone.
  static List<String> hosts(String ip, int prefix, {int cap = 1024}) {
    final value = toInt(ip);
    if (value == null) return const [];
    final start = networkInt(value, prefix);
    final end = broadcastInt(value, prefix);
    final result = <String>[];
    final first = prefix >= 31 ? start : start + 1;
    final last = prefix >= 31 ? end : end - 1;
    for (var i = first; i <= last && result.length < cap; i++) {
      result.add(fromInt(i));
    }
    return result;
  }

  static int? prefixFromInput(String input) {
    final text = input.trim();
    if (!text.contains('/')) return null;
    final parts = text.split('/');
    if (parts.length != 2) return null;
    final prefix = int.tryParse(parts[1]);
    if (prefix == null || prefix < 0 || prefix > 32) return null;
    if (!isValid(parts[0])) return null;
    return prefix;
  }

  static SubnetInfo? parseSubnet(String raw) {
    final text = raw.trim().replaceAll(' ', '');
    if (text.isEmpty) return null;
    String ipPart;
    int prefix;
    if (text.contains('/')) {
      final parts = text.split('/');
      ipPart = parts.first;
      final p = int.tryParse(parts.last);
      if (p == null) return null;
      prefix = p;
    } else {
      // Bare IP: assume /24 (the most common home network).
      ipPart = text;
      prefix = 24;
    }
    final ip = toInt(ipPart);
    if (ip == null || prefix < 0 || prefix > 32) return null;
    final network = networkInt(ip, prefix);
    final broadcast = broadcastInt(ip, prefix);
    final size = prefix >= 31 ? (prefix == 32 ? 1 : 2) : (1 << (32 - prefix));
    final firstHost = prefix >= 31 ? network : network + 1;
    final lastHost = prefix >= 31 ? broadcast : broadcast - 1;
    return SubnetInfo(
      ip: ipPart,
      prefix: prefix,
      network: fromInt(network),
      broadcast: fromInt(broadcast),
      firstHost: fromInt(firstHost),
      lastHost: fromInt(lastHost),
      mask: maskFromPrefix(prefix),
      wildcard: fromInt(~maskInt(prefix) & 0xFFFFFFFF),
      hostCount: hostCount(prefix),
      totalAddresses: size,
      cidr: '${fromInt(network)}/$prefix',
      isPrivate: isPrivate(ipPart),
    );
  }

  static int maskInt(int prefix) {
    if (prefix <= 0) return 0;
    if (prefix >= 32) return 0xFFFFFFFF;
    return (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
  }

  /// Parses a user-entered host list/range into concrete IP addresses.
  ///
  /// Accepted forms (comma separated):
  ///   - single address: `192.168.1.5`
  ///   - CIDR: `192.168.1.0/24` (capped to [cap] hosts)
  ///   - range: `192.168.1.1-192.168.1.50` or `192.168.1.1-50`
  static List<String> parseHostList(String text, {int cap = 1024}) {
    final result = <String>[];
    final seen = <String>{};
    void add(String ip) {
      if (!isValid(ip)) return;
      if (seen.add(ip)) result.add(ip);
      if (result.length >= cap) return;
    }

    for (final part in text.split(',')) {
      final item = part.trim();
      if (item.isEmpty) continue;
      if (item.contains('/')) {
        final info = parseSubnet(item);
        if (info != null) {
          for (final host in hosts(info.network, info.prefix, cap: cap)) {
            if (result.length >= cap) break;
            add(host);
          }
        }
        continue;
      }
      if (item.contains('-')) {
        final bits = item.split('-');
        if (bits.length == 2) {
          final start = bits[0].trim();
          var end = bits[1].trim();
          if (!end.contains('.')) {
            final parts = start.split('.');
            if (parts.length == 4) {
              end = '${parts[0]}.${parts[1]}.${parts[2]}.$end';
            }
          }
          final si = toInt(start);
          final ei = toInt(end);
          if (si != null && ei != null) {
            final lo = si < ei ? si : ei;
            final hi = si < ei ? ei : si;
            for (var v = lo; v <= hi && result.length < cap; v++) {
              add(fromInt(v));
            }
            continue;
          }
        }
      }
      add(item);
      if (result.length >= cap) break;
    }
    return result.take(cap).toList();
  }
}

class SubnetInfo {
  const SubnetInfo({
    required this.ip,
    required this.prefix,
    required this.network,
    required this.broadcast,
    required this.firstHost,
    required this.lastHost,
    required this.mask,
    required this.wildcard,
    required this.hostCount,
    required this.totalAddresses,
    required this.cidr,
    required this.isPrivate,
  });

  final String ip;
  final int prefix;
  final String network;
  final String broadcast;
  final String firstHost;
  final String lastHost;
  final String mask;
  final String wildcard;
  final int hostCount;
  final int totalAddresses;
  final String cidr;
  final bool isPrivate;
}

/// MAC address helpers, used by the device model and Wake-on-LAN.
class MacUtils {
  MacUtils._();

  static final _valid = RegExp(r'^[0-9A-Fa-f]{2}([:-]?[0-9A-Fa-f]{2}){5}$');

  static bool isValid(String? mac) =>
      mac != null && _valid.hasMatch(mac.trim());

  static String normalize(String mac) {
    final hex = mac.replaceAll(RegExp(r'[^0-9A-Fa-f]'), '').toUpperCase();
    if (hex.length != 12) return mac.trim().toUpperCase();
    final buffer = StringBuffer();
    for (var i = 0; i < 12; i += 2) {
      if (i != 0) buffer.write(':');
      buffer.write(hex.substring(i, i + 2));
    }
    return buffer.toString();
  }

  static List<int> toBytes(String mac) {
    final hex = mac.replaceAll(RegExp(r'[^0-9A-Fa-f]'), '');
    if (hex.length != 12) return const [];
    return [
      for (var i = 0; i < 12; i += 2) int.parse(hex.substring(i, i + 2), radix: 16)
    ];
  }

  static String vendorHint(String mac) {
    // No vendor database is shipped: it would be stale within weeks and this
    // app is offline-first. We show the OUI as a hint instead.
    final normalized = normalize(mac);
    if (!isValid(normalized)) return '';
    return normalized.substring(0, 8);
  }
}
