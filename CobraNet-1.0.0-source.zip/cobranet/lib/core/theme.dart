import 'package:material_ui/material_ui.dart';

/// CobraNet brand palette.
///
/// Deep forest + emerald (the cobra) and a warm amber accent. The app is
/// dark-first but ships a complete light scheme.
class AppColors {
  AppColors._();

  static const primary = Color(0xFF12D18E);
  static const primaryDim = Color(0xFF0AA06C);
  static const primaryDeep = Color(0xFF064E38);
  static const accent = Color(0xFFF4B740);
  static const danger = Color(0xFFFF5C5C);
  static const warning = Color(0xFFFFB020);
  static const success = Color(0xFF2BD98C);
  static const info = Color(0xFF5CB8FF);

  static const darkBg = Color(0xFF070D0B);
  static const darkSurface = Color(0xFF0E1714);
  static const darkSurface2 = Color(0xFF14211C);
  static const darkSurface3 = Color(0xFF1B2C25);
  static const darkBorder = Color(0xFF20342B);
  static const darkText = Color(0xFFE9F4EF);
  static const darkMuted = Color(0xFF87A398);

  static const lightBg = Color(0xFFF2F7F4);
  static const lightSurface = Color(0xFFFFFFFF);
  static const lightSurface2 = Color(0xFFEAF2ED);
  static const lightSurface3 = Color(0xFFDDEAE2);
  static const lightBorder = Color(0xFFD5E3DA);
  static const lightText = Color(0xFF0A1511);
  static const lightMuted = Color(0xFF5B7268);

  static const brandGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF0F3D2E), Color(0xFF0A2019), Color(0xFF07120E)],
  );

  static const scanGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF0F6E4E), Color(0xFF0B3A2A)],
  );
}

class AppRadius {
  AppRadius._();
  static const sm = 10.0;
  static const md = 14.0;
  static const lg = 20.0;
  static const xl = 28.0;
}

class AppTheme {
  AppTheme._();

  static ThemeData build(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: brightness,
    ).copyWith(
      primary: AppColors.primary,
      onPrimary: const Color(0xFF00261A),
      primaryContainer:
          dark ? const Color(0xFF11392B) : const Color(0xFFD3F7E7),
      onPrimaryContainer:
          dark ? const Color(0xFFB6F5D8) : const Color(0xFF003829),
      secondary: AppColors.accent,
      onSecondary: const Color(0xFF241800),
      secondaryContainer:
          dark ? const Color(0xFF3A2C0F) : const Color(0xFFFFEFC7),
      onSecondaryContainer:
          dark ? const Color(0xFFFFE2A0) : const Color(0xFF392A00),
      surface: dark ? AppColors.darkSurface : AppColors.lightSurface,
      onSurface: dark ? AppColors.darkText : AppColors.lightText,
      surfaceContainerHighest:
          dark ? AppColors.darkSurface2 : AppColors.lightSurface2,
      onSurfaceVariant: dark ? AppColors.darkMuted : AppColors.lightMuted,
      outline: dark ? AppColors.darkBorder : AppColors.lightBorder,
      outlineVariant: dark ? AppColors.darkBorder : AppColors.lightBorder,
      error: AppColors.danger,
      onError: Colors.white,
    );

    final base = ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
    );

    return base.copyWith(
      scaffoldBackgroundColor: dark ? AppColors.darkBg : AppColors.lightBg,
      splashFactory: InkSparkle.splashFactory,
      dividerColor: dark ? AppColors.darkBorder : AppColors.lightBorder,
      textTheme: base.textTheme.apply(
        bodyColor: dark ? AppColors.darkText : AppColors.lightText,
        displayColor: dark ? AppColors.darkText : AppColors.lightText,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: dark ? AppColors.darkSurface3 : const Color(0xFF13201B),
        contentTextStyle: const TextStyle(color: Colors.white, fontSize: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: dark ? AppColors.darkSurface : AppColors.lightSurface,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: dark ? AppColors.darkSurface : AppColors.lightSurface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.lg),
        ),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: dark ? AppColors.darkMuted : AppColors.lightMuted,
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.primary,
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: dark ? AppColors.darkSurface2 : AppColors.lightSurface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
        ),
      ),
    );
  }
}

/// Convenience colours for the current brightness.
extension AppThemeX on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  ColorScheme get scheme => Theme.of(this).colorScheme;
  Color get textColor => isDark ? AppColors.darkText : AppColors.lightText;
  Color get mutedColor => isDark ? AppColors.darkMuted : AppColors.lightMuted;
  Color get cardColor => isDark ? AppColors.darkSurface : AppColors.lightSurface;
  Color get cardAltColor =>
      isDark ? AppColors.darkSurface2 : AppColors.lightSurface2;
  Color get borderColor =>
      isDark ? AppColors.darkBorder : AppColors.lightBorder;
  Color get subtleFill =>
      isDark ? AppColors.darkSurface3 : AppColors.lightSurface3;
  TextStyle get monoStyle => TextStyle(
        fontFamily: 'monospace',
        fontFamilyFallback: const ['Roboto Mono', 'Courier New'],
        fontSize: 13,
        height: 1.5,
        color: textColor,
        letterSpacing: 0.2,
      );
}
