import 'package:material_ui/material_ui.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/ui.dart';
import '../widgets/visuals.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            ScreenHeader(
              title: context.tr('عن CobraNet', 'About CobraNet'),
              showBack: true,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
                children: [
                  Center(
                    child: Column(
                      children: [
                        const BrandMark(size: 84),
                        const SizedBox(height: 12),
                        Text(
                          'CobraNet',
                          style: headlineStyle(context).copyWith(fontSize: 24),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          context.tr(
                            'أدوات شبكة مجانية، بدون إعلانات.',
                            'Free network tools. No ads. No tracking.',
                          ),
                          textAlign: TextAlign.center,
                          style: mutedStyle(context),
                        ),
                        const SizedBox(height: 12),
                        const Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          alignment: WrapAlignment.center,
                          children: [
                            Pill(label: 'MIT', icon: Icons.code_rounded),
                            Pill(
                              label: 'No ads',
                              icon: Icons.block_rounded,
                              color: AppColors.danger,
                            ),
                            Pill(
                              label: 'Offline',
                              icon: Icons.cloud_off_rounded,
                              color: AppColors.info,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 22),
                  AppCard(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          context.tr('ما هو CobraNet؟', 'What is CobraNet?'),
                          style: titleStyle(context).copyWith(fontSize: 14),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          context.tr(
                            'تطبيق أدوات شبكة مفتوح المصدر لـ Android. يفحص شبكتك المحلية، يعرض الأجهزة المتصلة، ويقدّم بينغ وفحص منافذ واستعلام DNS وWHOIS وتتبع مسار وإيقاظ أجهزة وحاسبة شبكة واختبار سرعة. بُني من الصفر، وكل بياناتك تبقى على جهازك.',
                            'An open-source network toolbox for Android. Scan your LAN, see connected devices, and run ping, port scans, DNS and WHOIS lookups, traceroute, Wake-on-LAN, a subnet calculator and a speed test. Built from scratch — all your data stays on your device.',
                          ),
                          style: mutedStyle(context).copyWith(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  AppCard(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          context.tr('الخصوصية', 'Privacy'),
                          style: titleStyle(context).copyWith(fontSize: 14),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          context.tr(
                            'لا حسابات، لا إعلانات، لا تحليلات. لا يرسل التطبيق أي بيانات عنك. الاستعلامات التي تحتاج إنترنت (WHOIS، السرعة، فحص الروابط) تذهب مباشرة إلى الخادم الذي تطلبه ولا تمر عبر وسيط.',
                            'No accounts, no ads, no analytics. The app never sends data about you anywhere. Queries that need the internet (WHOIS, speed test, HTTP check) go straight to the server you ask for, never through a middleman.',
                          ),
                          style: mutedStyle(context).copyWith(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  AppCard(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          context.tr('الترخيص', 'License'),
                          style: titleStyle(context).copyWith(fontSize: 14),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          context.tr(
                            'يُوزّع هذا التطبيق بموجب ترخيص MIT. الكود المصدري متاح لك لتقرأه وتعدّله وتشاركه. أدوات الطرف الثالث المستخدمة تحتفظ بتراخيصها الخاصة.',
                            'Released under the MIT license. The source code is yours to read, modify and share. Third-party packages keep their own licenses.',
                          ),
                          style: mutedStyle(context).copyWith(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Center(
                    child: Text(
                      context.tr(
                        'صُنع بشغف، بلا إعلانات.',
                        'Made with care, without ads.',
                      ),
                      style: mutedStyle(context).copyWith(fontSize: 10.5),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
