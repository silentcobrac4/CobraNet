import 'package:material_ui/material_ui.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../models/device.dart';
import '../state/global.dart';
import '../services/oui_service.dart';
import '../widgets/ui.dart';
import '../widgets/visuals.dart';
import 'tools/ping_screen.dart';
import 'tools/port_scan_screen.dart';
import 'tools/wol_screen.dart';

class DeviceDetailScreen extends StatelessWidget {
  const DeviceDetailScreen({super.key, required this.device});

  final Device device;

  Device _current() {
    for (final item in app.scan.devices) {
      if (item.identity == device.identity) return item;
    }
    for (final item in app.knownDevices) {
      if (item.identity == device.identity) return item;
    }
    return device;
  }

  Future<void> _edit(BuildContext context, Device current) async {
    final nameController =
        TextEditingController(text: current.customName ?? '');
    final notesController = TextEditingController(text: current.notes ?? '');
    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          context.tr('بيانات الجهاز', 'Device details'),
          style: titleStyle(context).copyWith(fontSize: 17),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppField(
              controller: nameController,
              label: context.tr('اسم مخصص', 'Custom name'),
              hint: current.ip,
              autofocus: true,
            ),
            const SizedBox(height: 12),
            AppField(
              controller: notesController,
              label: context.tr('ملاحظات', 'Notes'),
              hint: context.tr('مثال: تلفاز الصالة', 'e.g. living room TV'),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(
              context.tr('إلغاء', 'Cancel'),
              style: TextStyle(color: context.mutedColor),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text(context.tr('حفظ', 'Save')),
          ),
        ],
      ),
    );
    if (saved == true) {
      final name = nameController.text.trim();
      final notes = notesController.text.trim();
      await app.saveDevice(current.copyWith(
        customName: name.isEmpty ? null : name,
        notes: notes.isEmpty ? null : notes,
        clearCustomName: name.isEmpty,
        clearNotes: notes.isEmpty,
      ));
      if (context.mounted) {
        showToast(context, context.tr('تم حفظ الجهاز', 'Device saved'));
      }
    }
    nameController.dispose();
    notesController.dispose();
  }

  Future<void> _remove(BuildContext context, Device current) async {
    final ok = await confirmDialog(
      context,
      title: context.tr('إزالة الجهاز؟', 'Remove device?'),
      message: context.tr(
        'سيُحذف الاسم والملاحظات والمفضلة. لن يؤثر ذلك على الشبكة.',
        'The custom name, notes and favorite will be deleted. The network is untouched.',
      ),
      confirmLabel: context.tr('إزالة', 'Remove'),
      danger: true,
    );
    if (ok) {
      await app.removeKnown(current);
      if (context.mounted) {
        showToast(context, context.tr('تمت الإزالة', 'Removed'));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([app, app.scan]),
      builder: (context, _) {
        final current = _current();
        final known = app.findKnown(current) != null;
        return Scaffold(
          body: SafeArea(
            bottom: false,
            child: Column(
              children: [
                ScreenHeader(
                  title: current.displayName,
                  subtitle: current.ip,
                  showBack: true,
                  trailing: IconButton(
                    onPressed: () => app.saveDevice(
                      current.copyWith(favorite: !current.favorite),
                    ),
                    icon: Icon(
                      current.favorite
                          ? Icons.star_rounded
                          : Icons.star_border_rounded,
                      color: current.favorite
                          ? AppColors.accent
                          : context.mutedColor,
                    ),
                  ),
                ),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(18, 4, 18, 28),
                    children: [
                      AppCard(
                        padding: const EdgeInsets.all(18),
                        child: Row(
                          children: [
                            DeviceGlyph(type: current.type, size: 64),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    current.displayName,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: titleStyle(context).copyWith(fontSize: 18),
                                  ),
                                  const SizedBox(height: 3),
                                  MonoText(
                                    current.ip,
                                    fontSize: 12.5,
                                    color: context.mutedColor,
                                  ),
                                  const SizedBox(height: 8),
                                  Wrap(
                                    spacing: 6,
                                    runSpacing: 6,
                                    children: [
                                      Pill(
                                        label: deviceTypeLabel(context, current.type),
                                        icon: DeviceGlyph.iconFor(current.type),
                                        color: DeviceGlyph.colorFor(current.type),
                                      ),
                                      Pill(
                                        label: current.online
                                            ? context.tr('متصل', 'Online')
                                            : context.tr('غير متصل', 'Offline'),
                                        color: current.online
                                            ? AppColors.primary
                                            : context.mutedColor,
                                      ),
                                      if (current.latencyMs != null)
                                        Pill(
                                          label: '${current.latencyMs} ms',
                                          color: AppColors.accent,
                                        ),
                                      if (known)
                                        Pill(
                                          label: context.tr('محفوظ', 'Saved'),
                                          color: AppColors.primary,
                                          icon: Icons.bookmark_rounded,
                                        ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _Action(
                              icon: Icons.network_ping_rounded,
                              label: context.tr('بينغ', 'Ping'),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                  builder: (_) => PingScreen(initialHost: current.ip),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _Action(
                              icon: Icons.lan_rounded,
                              label: context.tr('المنافذ', 'Ports'),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                  builder: (_) =>
                                      PortScanScreen(initialHost: current.ip),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _Action(
                              icon: Icons.power_settings_new_rounded,
                              label: context.tr('إيقاظ', 'Wake'),
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute<void>(
                                  builder: (_) => WolScreen(
                                    initialMac: current.mac ?? '',
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _Action(
                              icon: Icons.content_copy_rounded,
                              label: context.tr('نسخ', 'Copy'),
                              onTap: () => copyToClipboard(
                                context,
                                current.ip,
                                context.tr('تم نسخ العنوان', 'Address copied'),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      SectionTitle(title: context.tr('المعلومات', 'Information')),
                      AppCard(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 6),
                        child: Column(
                          children: [
                            InfoRow(
                              icon: Icons.tag_rounded,
                              label: context.tr('عنوان IP', 'IP address'),
                              value: current.ip,
                              mono: true,
                            ),
                            Divider(height: 1, color: context.borderColor),
                            InfoRow(
                              icon: Icons.fingerprint_rounded,
                              label: 'MAC',
                              value: current.mac ?? '—',
                              mono: true,
                            ),
                            Divider(height: 1, color: context.borderColor),
                            if (current.mac != null &&
                                OuiService.lookupSync(current.mac) != null) ...[
                              InfoRow(
                                icon: Icons.factory_outlined,
                                label: context.tr('الشركة المصنّعة', 'Manufacturer'),
                                value: OuiService.lookupSync(current.mac)!,
                              ),
                              Divider(height: 1, color: context.borderColor),
                            ],
                            InfoRow(
                              icon: Icons.badge_outlined,
                              label: context.tr('اسم المضيف', 'Hostname'),
                              value: current.hostname ?? '—',
                              mono: true,
                            ),
                            Divider(height: 1, color: context.borderColor),
                            InfoRow(
                              icon: Icons.memory_rounded,
                              label: context.tr('النوع', 'Type'),
                              value: deviceTypeLabel(context, current.type),
                            ),
                            Divider(height: 1, color: context.borderColor),
                            InfoRow(
                              icon: Icons.schedule_rounded,
                              label: context.tr('آخر ظهور', 'Last seen'),
                              value: context.dateFormat.format(current.lastSeen),
                            ),
                          ],
                        ),
                      ),
                      if (current.openPorts.isNotEmpty) ...[
                        const SizedBox(height: 18),
                        SectionTitle(
                          title: context.tr('منافذ مفتوحة', 'Open ports'),
                        ),
                        AppCard(
                          padding: const EdgeInsets.all(14),
                          child: Wrap(
                            spacing: 6,
                            runSpacing: 6,
                            children: current.openPorts
                                .map((port) => Pill(
                                      label: '$port',
                                      color: AppColors.primary,
                                    ))
                                .toList(),
                          ),
                        ),
                      ],
                      if (current.notes != null && current.notes!.isNotEmpty) ...[
                        const SizedBox(height: 18),
                        SectionTitle(title: context.tr('ملاحظات', 'Notes')),
                        AppCard(
                          padding: const EdgeInsets.all(14),
                          child: Text(
                            current.notes!,
                            style: bodyStyle(context).copyWith(fontSize: 13),
                          ),
                        ),
                      ],
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          Expanded(
                            child: SoftButton(
                              label: current.saved || known
                                  ? context.tr('تعديل الاسم', 'Edit name')
                                  : context.tr('حفظ الجهاز', 'Save device'),
                              icon: Icons.edit_rounded,
                              onPressed: () => _edit(context, current),
                            ),
                          ),
                          const SizedBox(width: 10),
                          if (current.saved || known)
                            SoftButton(
                              label: context.tr('إزالة', 'Remove'),
                              icon: Icons.delete_outline_rounded,
                              color: AppColors.danger,
                              onPressed: () => _remove(context, current),
                            ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SoftButton(
                        label: context.tr(
                          'فتح صفحة الجهاز في المتصفح',
                          'Open device web page',
                        ),
                        icon: Icons.open_in_new_rounded,
                        onPressed: () async {
                          final uri = Uri.parse('http://${current.ip}');
                          final ok = await launchUrl(
                            uri,
                            mode: LaunchMode.externalApplication,
                          );
                          if (!ok && context.mounted) {
                            showToast(
                              context,
                              context.tr(
                                'لا توجد صفحة ويب على هذا الجهاز',
                                'No web page on this device',
                              ),
                              error: true,
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _Action extends StatelessWidget {
  const _Action({
    required this.icon,
    required this.label,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 12),
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, size: 20, color: AppColors.primary),
          const SizedBox(height: 5),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: context.textColor,
            ),
          ),
        ],
      ),
    );
  }
}
