import 'package:material_ui/material_ui.dart';

import '../core/ip_utils.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../models/device.dart';
import '../services/permissions.dart';
import '../state/global.dart';
import '../widgets/ui.dart';
import '../widgets/visuals.dart';
import 'device_detail_screen.dart';

enum ScanFilter { all, online, favorites }

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final _searchController = TextEditingController();
  String _query = '';
  ScanFilter _filter = ScanFilter.all;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _openRangeDialog(BuildContext context) async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          context.tr('نطاق مخصّص', 'Custom range'),
          style: titleStyle(context).copyWith(fontSize: 17),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppField(
              controller: controller,
              label: context.tr('النطاق', 'Range'),
              hint: '192.168.1.1-192.168.1.100',
              mono: true,
              autofocus: true,
            ),
            const SizedBox(height: 8),
            Text(
              context.tr(
                'أمثلة: 10.0.0.5، 192.168.1.0/24، 192.168.1.1-50',
                'Examples: 10.0.0.5, 192.168.1.0/24, 192.168.1.1-50',
              ),
              style: mutedStyle(context).copyWith(fontSize: 10.5),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text(
              context.tr('إلغاء', 'Cancel'),
              style: TextStyle(color: context.mutedColor),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(controller.text.trim()),
            child: Text(context.tr('فحص', 'Scan')),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result == null || result.isEmpty) return;
    final hosts = IpUtils.parseHostList(result, cap: 1024);
    if (hosts.isEmpty) {
      if (context.mounted) {
        showToast(
          context,
          context.tr('نطاق غير صالح', 'Invalid range'),
          error: true,
        );
      }
      return;
    }
    await AppPermissions.ensureWifiAccess();
    if (context.mounted) {
      app.scan.start(app.netInfo, hosts: hosts);
    }
  }

  List<Device> _filtered(List<Device> devices) {
    final query = _query.trim().toLowerCase();
    return devices.where((device) {
      if (_filter == ScanFilter.online && !device.online) return false;
      if (_filter == ScanFilter.favorites && !device.favorite) return false;
      if (query.isEmpty) return true;
      return device.displayName.toLowerCase().contains(query) ||
          device.ip.toLowerCase().contains(query) ||
          (device.mac ?? '').toLowerCase().contains(query) ||
          (device.hostname ?? '').toLowerCase().contains(query);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge([app, app.scan]),
          builder: (context, _) {
            final scan = app.scan;
            final running = scan.running;
            final devices = scan.devices.isNotEmpty
                ? scan.devices
                : (app.lastScan?.devices ?? const <Device>[]);
            final shown = _filtered(devices);
            final last = app.lastScan;
            return Column(
              children: [
                ScreenHeader(
                  title: context.tr('أجهزة الشبكة', 'Network devices'),
                  subtitle: running
                      ? _phaseLabel(context, scan.phase)
                      : last == null
                          ? context.tr('لم يتم الفحص بعد', 'No scan yet')
                          : '${last.ssid ?? last.cidr ?? ''} · ${devices.length} ${context.tr('جهاز', 'devices')}',
                  showBack: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      RoundIconButton(
                        icon: Icons.tune_rounded,
                        tooltip: context.tr('نطاق مخصّص', 'Custom range'),
                        onPressed: running
                            ? null
                            : () => _openRangeDialog(context),
                      ),
                      const SizedBox(width: 6),
                      RoundIconButton(
                        icon: running ? Icons.stop_rounded : Icons.refresh_rounded,
                        color: running ? AppColors.danger : null,
                        tooltip: running
                            ? context.tr('إيقاف', 'Stop')
                            : context.tr('إعادة الفحص', 'Scan again'),
                        onPressed: () async {
                          if (running) {
                            scan.cancel();
                          } else {
                            await AppPermissions.ensureWifiAccess();
                            scan.start(app.netInfo);
                          }
                        },
                      ),
                    ],
                  ),
                ),
                if (running) _ScanProgress(scan: scan),
                if (scan.error != null)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 0),
                    child: _ErrorCard(onRetry: () => scan.start(app.netInfo)),
                  ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                  child: AppField(
                    controller: _searchController,
                    hint: context.tr('ابحث بالاسم أو العنوان', 'Search name or address'),
                    prefixIcon: Icons.search_rounded,
                    onChanged: (value) => setState(() => _query = value),
                    suffix: _query.isEmpty
                        ? null
                        : IconButton(
                            icon: const Icon(Icons.close_rounded, size: 18),
                            onPressed: () {
                              _searchController.clear();
                              setState(() => _query = '');
                            },
                          ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 10, 18, 8),
                  child: Row(
                    children: [
                      _FilterChip(
                        label: context.tr('الكل', 'All'),
                        count: devices.length,
                        active: _filter == ScanFilter.all,
                        onTap: () => setState(() => _filter = ScanFilter.all),
                      ),
                      const SizedBox(width: 8),
                      _FilterChip(
                        label: context.tr('متصل', 'Online'),
                        count: devices.where((d) => d.online).length,
                        active: _filter == ScanFilter.online,
                        onTap: () => setState(() => _filter = ScanFilter.online),
                      ),
                      const SizedBox(width: 8),
                      _FilterChip(
                        label: context.tr('المفضلة', 'Saved'),
                        count: devices.where((d) => d.favorite).length,
                        active: _filter == ScanFilter.favorites,
                        onTap: () => setState(() => _filter = ScanFilter.favorites),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? ListView(
                          children: [
                            const SizedBox(height: 30),
                            EmptyState(
                              icon: running
                                  ? Icons.radar_rounded
                                  : Icons.devices_other_rounded,
                              title: running
                                  ? context.tr('جارٍ البحث…', 'Searching…')
                                  : devices.isEmpty
                                      ? context.tr(
                                          'لم يتم العثور على أجهزة',
                                          'No devices found',
                                        )
                                      : context.tr(
                                          'لا توجد نتائج مطابقة',
                                          'No matching devices',
                                        ),
                              message: running
                                  ? context.tr(
                                      'قد يستغرق الفحص بعض الثواني.',
                                      'This can take a few seconds.',
                                    )
                                  : devices.isEmpty
                                      ? context.tr(
                                          'تأكد من اتصالك بالشبكة ثم أعد الفحص.',
                                          'Check your connection and scan again.',
                                        )
                                      : null,
                              action: devices.isEmpty && !running
                                  ? PrimaryButton(
                                      label: context.tr('بدء الفحص', 'Start scan'),
                                      icon: Icons.radar_rounded,
                                      expanded: false,
                                      onPressed: () async {
                                        await AppPermissions.ensureWifiAccess();
                                        scan.start(app.netInfo);
                                      },
                                    )
                                  : null,
                            ),
                          ],
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(18, 4, 18, 26),
                          itemCount: shown.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final device = shown[index];
                            return _DeviceTile(
                              device: device,
                              onTap: () async {
                                await Navigator.of(context).push(
                                  MaterialPageRoute<void>(
                                    builder: (_) =>
                                        DeviceDetailScreen(device: device),
                                  ),
                                );
                              },
                              onFavorite: () {
                                app.saveDevice(device.copyWith(
                                  favorite: !device.favorite,
                                ));
                              },
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  static String _phaseLabel(BuildContext context, String phase) {
    switch (phase) {
      case 'names':
        return context.tr('قراءة الأسماء…', 'Resolving names…');
      case 'ports':
        return context.tr('التعرف على الأجهزة…', 'Identifying devices…');
      default:
        return context.tr('جارٍ البحث عن الأجهزة…', 'Looking for devices…');
    }
  }
}

class _ScanProgress extends StatelessWidget {
  const _ScanProgress({required this.scan});
  final dynamic scan;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 2, 18, 0),
      child: AppCard(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(child: ScanRadar(size: 54, active: true, found: scan.found as int, progress: scan.fraction as double)),
                const SizedBox(width: 12),
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${scan.found} ${context.tr('جهاز مكتشف', 'devices found')}',
                        style: bodyStyle(context).copyWith(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: (scan.fraction as double) == 0
                              ? null
                              : scan.fraction as double,
                          minHeight: 5,
                          backgroundColor: context.cardAltColor,
                          color: AppColors.primary,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${(scan.done as int)} / ${scan.total as int}',
                        style: mutedStyle(context).copyWith(fontSize: 10.5),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                RoundIconButton(
                  icon: Icons.stop_rounded,
                  color: AppColors.danger,
                  tooltip: context.tr('إيقاف', 'Stop'),
                  onPressed: scan.cancel,
                  size: 36,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      color: AppColors.danger.withValues(alpha: 0.08),
      borderColor: AppColors.danger.withValues(alpha: 0.3),
      padding: const EdgeInsets.all(13),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded,
              color: AppColors.danger, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              context.tr(
                'تعذّر إكمال الفحص. تأكد من أنك على شبكة محلية.',
                'The scan could not run. Make sure you are on a local network.',
              ),
              style: mutedStyle(context).copyWith(fontSize: 11.5),
            ),
          ),
          TextButton(
            onPressed: onRetry,
            child: Text(context.tr('إعادة', 'Retry')),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.count,
    required this.active,
    required this.onTap,
  });
  final String label;
  final int count;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: active
              ? AppColors.primary.withValues(alpha: 0.13)
              : context.cardColor,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(
            color: active ? AppColors.primary : context.borderColor,
          ),
        ),
        child: Text(
          '$label  $count',
          style: TextStyle(
            fontSize: 11.5,
            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            color: active ? AppColors.primary : context.mutedColor,
          ),
        ),
      ),
    );
  }
}

class _DeviceTile extends StatelessWidget {
  const _DeviceTile({
    required this.device,
    required this.onTap,
    required this.onFavorite,
  });

  final Device device;
  final VoidCallback onTap;
  final VoidCallback onFavorite;

  @override
  Widget build(BuildContext context) {
    final latency = device.latencyMs;
    final latencyColor = latency == null
        ? context.mutedColor
        : latency < 15
            ? AppColors.primary
            : latency < 60
                ? AppColors.accent
                : AppColors.danger;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 11, 8, 11),
      onTap: onTap,
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              DeviceGlyph(type: device.type, size: 42),
              PositionedDirectional(
                bottom: -1,
                end: -1,
                child: Container(
                  width: 11,
                  height: 11,
                  decoration: BoxDecoration(
                    color: device.online
                        ? AppColors.primary
                        : context.mutedColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: context.cardColor, width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        device.displayName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: bodyStyle(context).copyWith(
                          fontWeight: FontWeight.w700,
                          fontSize: 13.5,
                        ),
                      ),
                    ),
                    if (device.type == DeviceType.thisDevice) ...[
                      const SizedBox(width: 6),
                      Pill(
                        label: context.tr('أنت', 'You'),
                        color: AppColors.primary,
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(
                      device.ip,
                      textDirection: TextDirection.ltr,
                      style: context.monoStyle.copyWith(
                        fontSize: 11,
                        color: context.mutedColor,
                      ),
                    ),
                    if (device.mac != null) ...[
                      Text(
                        '  ·  ',
                        style: mutedStyle(context).copyWith(fontSize: 10),
                      ),
                      Flexible(
                        child: Text(
                          device.mac!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textDirection: TextDirection.ltr,
                          style: context.monoStyle.copyWith(
                            fontSize: 10.5,
                            color: context.mutedColor,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          if (latency != null)
            Pill(label: '${latency}ms', color: latencyColor)
          else
            Text(
              deviceTypeLabel(context, device.type),
              style: mutedStyle(context).copyWith(fontSize: 10.5),
            ),
          const SizedBox(width: 2),
          IconButton(
            onPressed: onFavorite,
            visualDensity: VisualDensity.compact,
            iconSize: 19,
            icon: Icon(
              device.favorite ? Icons.star_rounded : Icons.star_border_rounded,
              color: device.favorite ? AppColors.accent : context.mutedColor,
            ),
          ),
        ],
      ),
    );
  }
}
