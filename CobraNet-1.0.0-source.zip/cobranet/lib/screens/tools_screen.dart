import 'package:material_ui/material_ui.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../widgets/ui.dart';
import 'tools/discovery_screen.dart';
import 'tools/dns_screen.dart';
import 'tools/http_check_screen.dart';
import 'tools/ping_screen.dart';
import 'tools/port_scan_screen.dart';
import 'tools/speed_test_screen.dart';
import 'tools/subnet_screen.dart';
import 'tools/traceroute_screen.dart';
import 'tools/whois_screen.dart';
import 'tools/wol_screen.dart';

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = <_ToolSpec>[
      _ToolSpec(
        icon: Icons.network_ping_rounded,
        color: AppColors.primary,
        title: context.tr('بينغ', 'Ping'),
        subtitle: context.tr('زمن الاستجابة وفقدان الحزم', 'Latency and packet loss'),
        builder: (_) => const PingScreen(),
      ),
      _ToolSpec(
        icon: Icons.lan_rounded,
        color: const Color(0xFF6FC3FF),
        title: context.tr('فحص المنافذ', 'Port scan'),
        subtitle: context.tr('اعرف الخدمات المفتوحة', 'Find open services'),
        builder: (_) => const PortScanScreen(),
      ),
      _ToolSpec(
        icon: Icons.dns_rounded,
        color: const Color(0xFFF4B740),
        title: context.tr('استعلام DNS', 'DNS lookup'),
        subtitle: context.tr('A و AAAA و MX و TXT', 'A, AAAA, MX and TXT'),
        builder: (_) => const DnsScreen(),
      ),
      _ToolSpec(
        icon: Icons.travel_explore_rounded,
        color: const Color(0xFF9C8CFF),
        title: 'WHOIS',
        subtitle: context.tr('بيانات تسجيل النطاق', 'Domain registration data'),
        builder: (_) => const WhoisScreen(),
      ),
      _ToolSpec(
        icon: Icons.route_rounded,
        color: const Color(0xFF5FE3D0),
        title: context.tr('تتبع المسار', 'Traceroute'),
        subtitle: context.tr('الطريق حتى الوجهة', 'Hops to the destination'),
        builder: (_) => const TracerouteScreen(),
      ),
      _ToolSpec(
        icon: Icons.power_settings_new_rounded,
        color: const Color(0xFFFF9F6B),
        title: context.tr('إيقاظ جهاز', 'Wake on LAN'),
        subtitle: context.tr('شغّل جهازًا بحزمة سحرية', 'Send a magic packet'),
        builder: (_) => const WolScreen(),
      ),
      _ToolSpec(
        icon: Icons.calculate_rounded,
        color: const Color(0xFFB6D86F),
        title: context.tr('حاسبة الشبكة', 'Subnet calculator'),
        subtitle: context.tr('النطاق والأقنعة بدون إنترنت', 'Ranges and masks offline'),
        builder: (_) => const SubnetScreen(),
      ),
      _ToolSpec(
        icon: Icons.speed_rounded,
        color: const Color(0xFFF1A7FF),
        title: context.tr('سرعة التنزيل', 'Speed test'),
        subtitle: context.tr('قِس سرعة اتصالك', 'Measure your link'),
        builder: (_) => const SpeedTestScreen(),
      ),
      _ToolSpec(
        icon: Icons.http_rounded,
        color: const Color(0xFF8FD47A),
        title: context.tr('فحص رابط', 'HTTP check'),
        subtitle: context.tr('الحالة والترويسات', 'Status and headers'),
        builder: (_) => const HttpCheckScreen(),
      ),
      _ToolSpec(
        icon: Icons.travel_explore_rounded,
        color: const Color(0xFF5FE3D0),
        title: context.tr('اكتشاف الأجهزة', 'Device discovery'),
        subtitle: context.tr('خدمات mDNS/Bonjour', 'mDNS/Bonjour services'),
        builder: (_) => const DiscoveryScreen(),
      ),
    ];

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        context.tr('الأدوات', 'Tools'),
                        style: headlineStyle(context),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        context.tr(
                          'كل أداة تعمل على جهازك مباشرة',
                          'Every tool runs right on your phone',
                        ),
                        style: mutedStyle(context),
                      ),
                    ],
                  ),
                ),
                const Pill(
                  label: '100% offline',
                  color: AppColors.primary,
                  icon: Icons.lock_rounded,
                ),
              ],
            ),
            const SizedBox(height: 18),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: tools.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.32,
              ),
              itemBuilder: (context, index) {
                final tool = tools[index];
                return AppCard(
                  padding: const EdgeInsets.all(14),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: tool.builder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: tool.color.withValues(alpha: 0.13),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(tool.icon, color: tool.color, size: 20),
                      ),
                      const Spacer(),
                      Text(
                        tool.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: bodyStyle(context).copyWith(
                          fontWeight: FontWeight.w700,
                          fontSize: 13.5,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        tool.subtitle,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: mutedStyle(context).copyWith(fontSize: 10.5),
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 18),
            AppCard(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  const Icon(Icons.info_outline_rounded,
                      size: 18, color: AppColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      context.tr(
                        'بعض الأدوات (WHOIS وسرعة التنزيل وفحص الروابط) تحتاج إنترنت. الباقي يعمل على شبكتك المحلية فقط.',
                        'WHOIS, the speed test and HTTP check need the internet. Everything else works on your local network only.',
                      ),
                      style: mutedStyle(context).copyWith(fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ToolSpec {
  const _ToolSpec({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.builder,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final WidgetBuilder builder;
}
