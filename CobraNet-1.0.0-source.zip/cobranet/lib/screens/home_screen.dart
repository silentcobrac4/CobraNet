import 'package:material_ui/material_ui.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../models/scan_snapshot.dart';
import '../services/permissions.dart';
import '../state/global.dart';
import '../widgets/ui.dart';
import '../widgets/visuals.dart';
import 'scan_screen.dart';
import 'tools/dns_screen.dart';
import 'tools/ping_screen.dart';
import 'tools/port_scan_screen.dart';
import 'tools/wol_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _startScan(BuildContext context) async {
    await AppPermissions.ensureWifiAccess();
    if (!context.mounted) return;
    app.scan.start(app.netInfo);
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const ScanScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: Listenable.merge([app, app.scan]),
          builder: (context, _) {
            final net = app.netInfo;
            final scan = app.scan;
            final last = app.lastScan;
            final devices = scan.running || scan.devices.isNotEmpty
                ? scan.devices
                : (last?.devices ?? const []);
            return RefreshIndicator(
              color: AppColors.primary,
              backgroundColor: context.cardColor,
              onRefresh: app.refreshNetwork,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
                children: [
                  Row(
                    children: [
                      const BrandMark(size: 46),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'CobraNet',
                              style: headlineStyle(context).copyWith(
                                fontSize: 21,
                                letterSpacing: -0.4,
                              ),
                            ),
                            Text(
                              context.tr(
                                'أدوات شبكتك، بدون إعلانات',
                                'Your network, without ads',
                              ),
                              style: mutedStyle(context).copyWith(fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      RoundIconButton(
                        icon: Icons.refresh_rounded,
                        tooltip: context.tr('تحديث الشبكة', 'Refresh network'),
                        onPressed: app.netInfoLoading ? null : app.refreshNetwork,
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  _NetworkCard(
                    net: net,
                    loading: app.netInfoLoading,
                    onRefresh: app.refreshNetwork,
                  ),
                  const SizedBox(height: 14),
                  _ScanCard(
                    scan: scan,
                    last: last,
                    deviceCount: devices.length,
                    onStart: () => _startScan(context),
                    onOpen: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const ScanScreen(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  SectionTitle(title: context.tr('أدوات سريعة', 'Quick tools')),
                  Row(
                    children: [
                      Expanded(
                        child: _QuickTool(
                          icon: Icons.network_ping_rounded,
                          label: context.tr('بينغ', 'Ping'),
                          color: AppColors.primary,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => PingScreen(
                                initialHost: net?.gateway ?? '',
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _QuickTool(
                          icon: Icons.lan_rounded,
                          label: context.tr('المنافذ', 'Ports'),
                          color: const Color(0xFF6FC3FF),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => PortScanScreen(
                                initialHost: net?.gateway ?? '',
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _QuickTool(
                          icon: Icons.dns_rounded,
                          label: context.tr('DNS', 'DNS'),
                          color: const Color(0xFFF4B740),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const DnsScreen(),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _QuickTool(
                          icon: Icons.power_settings_new_rounded,
                          label: context.tr('إيقاظ', 'Wake'),
                          color: const Color(0xFFFF9F6B),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const WolScreen(),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 22),
                  AppCard(
                    padding: const EdgeInsets.all(14),
                    color: context.cardColor,
                    child: Row(
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            color: AppColors.primary.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(11),
                          ),
                          child: const Icon(
                            Icons.verified_user_rounded,
                            size: 19,
                            color: AppColors.primary,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                context.tr(
                                  'مجاني ومفتوح المصدر',
                                  'Free and open source',
                                ),
                                style: bodyStyle(context).copyWith(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13.5,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                context.tr(
                                  'بدون إعلانات، بدون حسابات، وكل بياناتك تبقى على جهازك.',
                                  'No ads, no accounts. Your data never leaves this device.',
                                ),
                                style: mutedStyle(context).copyWith(fontSize: 11.5),
                              ),
                            ],
                          ),
                        ),
                        const Pill(label: 'MIT', color: AppColors.primary),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Center(
                    child: Text(
                      context.tr(
                        'اسحب للأسفل لتحديث معلومات الشبكة',
                        'Pull down to refresh the network info',
                      ),
                      style: mutedStyle(context).copyWith(fontSize: 10.5),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _NetworkCard extends StatelessWidget {
  const _NetworkCard({
    required this.net,
    required this.loading,
    required this.onRefresh,
  });

  final dynamic net;
  final bool loading;
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    final connected = net?.ip != null;
    const white = Color(0xFFEAF7F1);
    const dim = Color(0xFF9FC4B3);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0D4A36), Color(0xFF0A2E23), Color(0xFF081E18)],
        ),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        border: Border.all(color: Colors.white.withValues(alpha: 0.06)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: Icon(
                  connected
                      ? (net?.isWifi == true
                          ? Icons.wifi_rounded
                          : Icons.settings_ethernet_rounded)
                      : Icons.wifi_off_rounded,
                  color: connected ? AppColors.primary : dim,
                  size: 21,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      connected
                          ? _networkName(context, net)
                          : context.tr('غير متصل', 'Not connected'),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: white,
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      connected
                          ? _typeLabel(context, net?.connectionType)
                          : context.tr(
                              'اتصل بشبكة Wi-Fi أو شبكة محلية',
                              'Join a Wi-Fi or local network',
                            ),
                      style: const TextStyle(color: dim, fontSize: 11.5),
                    ),
                  ],
                ),
              ),
              if (loading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.primary,
                  ),
                )
              else
                RoundIconButton(
                  icon: Icons.refresh_rounded,
                  tooltip: context.tr('تحديث', 'Refresh'),
                  onPressed: onRefresh,
                  size: 36,
                  color: Colors.white,
                ),
            ],
          ),
          if (connected) ...[
            const SizedBox(height: 18),
            Row(
              children: [
                _NetStat(
                  label: context.tr('عنوان الجهاز', 'Local IP'),
                  value: '${net!.ip}',
                  mono: true,
                ),
                const SizedBox(width: 10),
                _NetStat(
                  label: context.tr('البوابة', 'Gateway'),
                  value: '${net.gateway ?? '—'}',
                  mono: true,
                ),
                const SizedBox(width: 10),
                _NetStat(
                  label: context.tr('القناع', 'Mask'),
                  value: '${net.mask ?? '—'}',
                  mono: true,
                ),
              ],
            ),
            if (net?.ssid == null) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.lock_outline_rounded, size: 14, color: dim),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      context.tr(
                        'اسم الشبكة مخفي. امنح إذن الموقع لعرضه.',
                        'Network name hidden. Grant location access to show it.',
                      ),
                      style: const TextStyle(color: dim, fontSize: 10.5),
                    ),
                  ),
                  GestureDetector(
                    onTap: () async {
                      await AppPermissions.ensureWifiAccess();
                      await onRefresh();
                    },
                    child: Text(
                      context.tr('منح', 'Allow'),
                      style: const TextStyle(
                        color: AppColors.primary,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ] else ...[
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: onRefresh,
                style: TextButton.styleFrom(
                  backgroundColor: Colors.white.withValues(alpha: 0.08),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                  ),
                ),
                child: Text(
                  context.tr('إعادة المحاولة', 'Try again'),
                  style: const TextStyle(
                    color: white,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  static String _networkName(BuildContext context, dynamic net) {
    final ssid = net?.ssid;
    if (ssid is String && ssid.trim().isNotEmpty) return ssid;
    if (net?.isWifi == true) return context.tr('شبكة Wi-Fi', 'Wi-Fi network');
    return context.tr('شبكة محلية', 'Local network');
  }

  static String _typeLabel(BuildContext context, String? type) {
    switch (type) {
      case 'wifi':
        return context.tr('شبكة لاسلكية · متصل', 'Wi-Fi · connected');
      case 'ethernet':
        return context.tr('شبكة سلكية · متصل', 'Ethernet · connected');
      case 'mobile':
        return context.tr('بيانات الجوال', 'Mobile data');
      case 'vpn':
        return context.tr('اتصال VPN', 'VPN');
      case 'none':
        return context.tr('غير متصل', 'Disconnected');
      default:
        return context.tr('متصل', 'Connected');
    }
  }
}

class _NetStat extends StatelessWidget {
  const _NetStat({
    required this.label,
    required this.value,
    this.mono = false,
  });
  final String label;
  final String value;
  final bool mono;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Color(0xFF9FC4B3), fontSize: 9.5),
            ),
            const SizedBox(height: 3),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textDirection: mono ? TextDirection.ltr : null,
              style: TextStyle(
                color: const Color(0xFFEAF7F1),
                fontSize: mono ? 10.5 : 12,
                fontWeight: FontWeight.w600,
                fontFamily: mono ? 'monospace' : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ScanCard extends StatelessWidget {
  const _ScanCard({
    required this.scan,
    required this.last,
    required this.deviceCount,
    required this.onStart,
    required this.onOpen,
  });

  final dynamic scan;
  final ScanSnapshot? last;
  final int deviceCount;
  final VoidCallback onStart;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    final running = scan.running == true;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 16, 14, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      running
                          ? context.tr('جارٍ فحص الشبكة', 'Scanning the network')
                          : context.tr('أجهزة الشبكة', 'Network devices'),
                      style: titleStyle(context).copyWith(fontSize: 16),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      running
                          ? _phase(context, scan.phase)
                          : last == null
                              ? context.tr(
                                  'اكتشف كل جهاز متصل بشبكتك',
                                  'Find every device on your network',
                                )
                              : _lastScanText(context, last!),
                      style: mutedStyle(context).copyWith(fontSize: 11.5),
                    ),
                    const SizedBox(height: 12),
                    if (running)
                      Row(
                        children: [
                          Text(
                            '${scan.found}',
                            style: TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                              color: context.textColor,
                              letterSpacing: -0.8,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            context.tr('جهاز حتى الآن', 'devices so far'),
                            style: mutedStyle(context).copyWith(fontSize: 11),
                          ),
                        ],
                      )
                    else if (last != null)
                      Row(
                        children: [
                          _MiniStat(
                            value: '${last!.devices.length}',
                            label: context.tr('جهاز', 'devices'),
                          ),
                          _MiniStat(
                            value: '${last!.onlineCount}',
                            label: context.tr('متصل', 'online'),
                          ),
                          _MiniStat(
                            value: '${last!.duration.inSeconds}s',
                            label: context.tr('المدة', 'time'),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              ScanRadar(
                size: 96,
                active: running,
                found: running ? (scan.found as int) : (last?.devices.length ?? 0),
                progress: running ? (scan.fraction as double) : 1,
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (running) ...[
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: (scan.fraction as double) == 0
                    ? null
                    : scan.fraction as double,
                minHeight: 5,
                backgroundColor: context.cardAltColor,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: SoftButton(
                    label: context.tr('إيقاف', 'Stop'),
                    icon: Icons.stop_rounded,
                    color: AppColors.danger,
                    onPressed: app.scan.cancel,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: SoftButton(
                    label: context.tr('التفاصيل', 'Details'),
                    icon: Icons.list_rounded,
                    onPressed: onOpen,
                  ),
                ),
              ],
            ),
          ] else
            Row(
              children: [
                if (last != null) ...[
                  Expanded(
                    child: SoftButton(
                      label: context.tr('عرض النتائج', 'Results'),
                      icon: Icons.devices_rounded,
                      onPressed: onOpen,
                    ),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  flex: last == null ? 1 : 2,
                  child: PrimaryButton(
                    label: context.tr('فحص الشبكة', 'Scan network'),
                    icon: Icons.radar_rounded,
                    onPressed: onStart,
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  static String _phase(BuildContext context, String? phase) {
    switch (phase) {
      case 'names':
        return context.tr('قراءة أسماء الأجهزة…', 'Resolving device names…');
      case 'ports':
        return context.tr('التعرف على أنواع الأجهزة…', 'Identifying devices…');
      default:
        return context.tr('البحث عن الأجهزة…', 'Looking for devices…');
    }
  }

  static String _lastScanText(BuildContext context, ScanSnapshot last) {
    final time = context.dateFormat.format(last.finishedAt);
    final net = last.ssid ?? last.cidr;
    if (net == null || net.isEmpty) {
      return context.tr('آخر فحص: $time', 'Last scan: $time');
    }
    return context.tr('$net · آخر فحص $time', '$net · last scan $time');
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.value, required this.label});
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsetsDirectional.only(end: 8),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: context.cardAltColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: value,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: context.textColor,
              ),
            ),
            TextSpan(
              text: ' $label',
              style: TextStyle(fontSize: 10, color: context.mutedColor),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickTool extends StatelessWidget {
  const _QuickTool({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 6),
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.13),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 20, color: color),
          ),
          const SizedBox(height: 7),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: context.textColor,
            ),
          ),
        ],
      ),
    );
  }
}
