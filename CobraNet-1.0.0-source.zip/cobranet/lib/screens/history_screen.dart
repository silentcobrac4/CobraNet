import 'package:material_ui/material_ui.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../state/global.dart';
import '../widgets/ui.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String _filter = 'all';

  static const _tools = <String, List<String>>{
    'scan': ['فحص الشبكة', 'Network scan', 'radar'],
    'ping': ['بينغ', 'Ping', 'ping'],
    'ports': ['المنافذ', 'Ports', 'lan'],
    'dns': ['DNS', 'DNS', 'dns'],
    'whois': ['WHOIS', 'WHOIS', 'whois'],
    'traceroute': ['تتبع المسار', 'Traceroute', 'route'],
    'wol': ['إيقاظ', 'Wake', 'bolt'],
    'subnet': ['حاسبة', 'Subnet', 'calc'],
    'speed': ['السرعة', 'Speed', 'speed'],
    'http': ['رابط', 'HTTP', 'http'],
  };

  IconData _icon(String tool) {
    switch (tool) {
      case 'scan':
        return Icons.radar_rounded;
      case 'ping':
        return Icons.network_ping_rounded;
      case 'ports':
        return Icons.lan_rounded;
      case 'dns':
        return Icons.dns_rounded;
      case 'whois':
        return Icons.travel_explore_rounded;
      case 'traceroute':
        return Icons.route_rounded;
      case 'wol':
        return Icons.power_settings_new_rounded;
      case 'subnet':
        return Icons.calculate_rounded;
      case 'speed':
        return Icons.speed_rounded;
      case 'http':
        return Icons.http_rounded;
      default:
        return Icons.history_rounded;
    }
  }

  String _title(BuildContext context, String tool) {
    final spec = _tools[tool];
    if (spec == null) return tool;
    return context.tr(spec[0], spec[1]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: app,
          builder: (context, _) {
            final entries = _filter == 'all'
                ? app.history
                : app.history.where((e) => e.tool == _filter).toList();
            final filters = <String>[
              'all',
              ..._tools.keys.where(
                (key) => app.history.any((entry) => entry.tool == key),
              ),
            ];
            return Column(
              children: [
                ScreenHeader(
                  title: context.tr('السجل', 'History'),
                  subtitle: context.tr(
                    'كل ما فعلته، محفوظ على جهازك فقط.',
                    'Everything you ran, stored only on this device.',
                  ),
                  trailing: app.history.isEmpty
                      ? null
                      : RoundIconButton(
                          icon: Icons.delete_outline_rounded,
                          tooltip: context.tr('مسح السجل', 'Clear history'),
                          onPressed: () async {
                            final ok = await confirmDialog(
                              context,
                              title: context.tr('مسح السجل؟', 'Clear history?'),
                              message: context.tr(
                                'سيُحذف كل سجل الأدوات. الأجهزة المحفوظة لن تتأثر.',
                                'All tool history will be deleted. Saved devices are kept.',
                              ),
                              confirmLabel: context.tr('مسح', 'Clear'),
                              danger: true,
                            );
                            if (ok) await app.clearHistory();
                          },
                        ),
                ),
                if (filters.length > 1)
                  SizedBox(
                    height: 42,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      itemCount: filters.length,
                      separatorBuilder: (_, _) => const SizedBox(width: 8),
                      itemBuilder: (context, index) {
                        final key = filters[index];
                        final active = _filter == key;
                        final label = key == 'all'
                            ? context.tr('الكل', 'All')
                            : _title(context, key);
                        return GestureDetector(
                          onTap: () => setState(() => _filter = key),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 150),
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(horizontal: 13),
                            decoration: BoxDecoration(
                              color: active
                                  ? AppColors.primary.withValues(alpha: 0.13)
                                  : context.cardColor,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: active
                                    ? AppColors.primary
                                    : context.borderColor,
                              ),
                            ),
                            child: Text(
                              label,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight:
                                    active ? FontWeight.w700 : FontWeight.w500,
                                color: active
                                    ? AppColors.primary
                                    : context.mutedColor,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                Expanded(
                  child: entries.isEmpty
                      ? EmptyState(
                          icon: Icons.history_rounded,
                          title: context.tr('لا يوجد سجل بعد', 'No history yet'),
                          message: context.tr(
                            'ستظهر هنا نتائج الأدوات التي تشغّلها.',
                            'Results from the tools you run will show up here.',
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(18, 14, 18, 26),
                          itemCount: entries.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final entry = entries[index];
                            return AppCard(
                              padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: (entry.ok
                                              ? AppColors.primary
                                              : AppColors.danger)
                                          .withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(11),
                                    ),
                                    child: Icon(
                                      _icon(entry.tool),
                                      size: 17,
                                      color: entry.ok
                                          ? AppColors.primary
                                          : AppColors.danger,
                                    ),
                                  ),
                                  const SizedBox(width: 11),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                _title(context, entry.tool),
                                                style: bodyStyle(context)
                                                    .copyWith(
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 12.5,
                                                ),
                                              ),
                                            ),
                                            Text(
                                              context.dateFormat
                                                  .format(entry.createdAt),
                                              style: mutedStyle(context)
                                                  .copyWith(fontSize: 9),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          entry.query,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          textDirection: TextDirection.ltr,
                                          style: context.monoStyle.copyWith(
                                            fontSize: 11,
                                            color: context.mutedColor,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          entry.summary,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          style: mutedStyle(context)
                                              .copyWith(fontSize: 11),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (entry.detail != null &&
                                      entry.detail!.isNotEmpty)
                                    IconButton(
                                      visualDensity: VisualDensity.compact,
                                      iconSize: 18,
                                      tooltip: context.tr('التفاصيل', 'Details'),
                                      icon: Icon(
                                        Icons.expand_more_rounded,
                                        color: context.mutedColor,
                                      ),
                                      onPressed: () => showModalBottomSheet<void>(
                                        context: context,
                                        isScrollControlled: true,
                                        builder: (context) => _DetailSheet(
                                          title: _title(context, entry.tool),
                                          query: entry.query,
                                          detail: entry.detail!,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _DetailSheet extends StatelessWidget {
  const _DetailSheet({
    required this.title,
    required this.query,
    required this.detail,
  });
  final String title;
  final String query;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.55,
      maxChildSize: 0.9,
      builder: (context, controller) => Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 38,
            height: 4,
            decoration: BoxDecoration(
              color: context.borderColor,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          ScreenHeader(title: title, subtitle: query),
          Expanded(
            child: ListView(
              controller: controller,
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
              children: [
                AppCard(
                  padding: const EdgeInsets.all(14),
                  child: SelectableText(
                    detail,
                    textDirection: TextDirection.ltr,
                    style: context.monoStyle.copyWith(fontSize: 11.5),
                  ),
                ),
                const SizedBox(height: 12),
                SoftButton(
                  label: context.tr('نسخ', 'Copy'),
                  icon: Icons.content_copy_rounded,
                  onPressed: () =>
                      copyToClipboard(context, detail, context.tr('تم النسخ', 'Copied')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
