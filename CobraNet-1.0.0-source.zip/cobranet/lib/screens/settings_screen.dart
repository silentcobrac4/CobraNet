import 'package:material_ui/material_ui.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../models/device.dart';
import '../services/backup_service.dart';
import '../services/csv_service.dart';
import '../state/global.dart';
import '../widgets/ui.dart';
import 'about_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _version = '';

  @override
  void initState() {
    super.initState();
    _loadVersion();
  }

  Future<void> _loadVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (!mounted) return;
      setState(() => _version = '${info.version}+${info.buildNumber}');
    } catch (_) {}
  }

  Future<void> _export() async {
    try {
      final file = await BackupService.writeExport(app.exportBackup());
      await BackupService.shareExport(file);
    } catch (e) {
      if (!mounted) return;
      showToast(context, '$e', error: true);
    }
  }

  Future<void> _import() async {
    try {
      final data = await BackupService.pickImport();
      if (data == null) return;
      await app.importBackup(data);
      if (!mounted) return;
      showToast(context, context.tr('تم استيراد النسخة', 'Backup imported'));
    } catch (e) {
      if (!mounted) return;
      showToast(
        context,
        context.tr('ملف غير صالح', 'Invalid file'),
        error: true,
      );
    }
  }

  Future<void> _exportCsv() async {
    final devices = <Device>[];
    final seen = <String>{};
    for (final d in [...(app.lastScan?.devices ?? const <Device>[]), ...app.knownDevices]) {
      if (seen.add(d.identity)) devices.add(d);
    }
    if (devices.isEmpty) {
      if (!mounted) return;
      showToast(
        context,
        context.tr('لا توجد أجهزة للتصدير', 'No devices to export'),
        error: true,
      );
      return;
    }
    try {
      await CsvService.shareDevices(devices);
    } catch (e) {
      if (!mounted) return;
      showToast(context, '$e', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: ListenableBuilder(
          listenable: app,
          builder: (context, _) {
            final settings = app.settings;
            return ListView(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
              children: [
                Text(
                  context.tr('الإعدادات', 'Settings'),
                  style: headlineStyle(context),
                ),
                const SizedBox(height: 2),
                Text(
                  context.tr(
                    'اضبط التطبيق كما يناسبك.',
                    'Make the app work the way you like.',
                  ),
                  style: mutedStyle(context),
                ),
                const SizedBox(height: 20),
                SectionTitle(title: context.tr('المظهر', 'Appearance')),
                AppCard(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        context.tr('السمة', 'Theme'),
                        style: mutedStyle(context).copyWith(fontSize: 11.5),
                      ),
                      const SizedBox(height: 8),
                      LabeledChips(
                        options: const ['system', 'dark', 'light'],
                        selected: settings.theme.name,
                        onSelected: (value) {
                          final mode = ThemeMode.values.firstWhere(
                            (m) => m.name == value,
                            orElse: () => ThemeMode.system,
                          );
                          app.setTheme(mode);
                        },
                      ),
                      const SizedBox(height: 16),
                      Text(
                        context.tr('اللغة', 'Language'),
                        style: mutedStyle(context).copyWith(fontSize: 11.5),
                      ),
                      const SizedBox(height: 8),
                      LabeledChips(
                        options: const ['auto', 'ar', 'en'],
                        selected: settings.locale ?? 'auto',
                        onSelected: (value) {
                          if (value == 'auto') {
                            app.setLocale(null);
                          } else {
                            app.setLocale(value);
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                SectionTitle(title: context.tr('الفحص', 'Scanning')),
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  child: Column(
                    children: [
                      _SwitchRow(
                        title: context.tr('فحص عميق', 'Deep scan'),
                        subtitle: context.tr(
                          'التعرف على نوع الجهاز عبر منافذه',
                          'Identify devices by their ports',
                        ),
                        value: settings.deepScan,
                        onChanged: (value) =>
                            app.updateSettings(settings.copyWith(deepScan: value)),
                      ),
                      Divider(height: 1, color: context.borderColor),
                      _SwitchRow(
                        title: context.tr('قراءة أسماء الأجهزة', 'Resolve names'),
                        subtitle: context.tr(
                          'استخدام DNS العكسي لأسماء الأجهزة',
                          'Use reverse DNS for device names',
                        ),
                        value: settings.resolveNames,
                        onChanged: (value) => app.updateSettings(
                          settings.copyWith(resolveNames: value),
                        ),
                      ),
                      Divider(height: 1, color: context.borderColor),
                      _SliderRow(
                        label: context.tr('مهلة الفحص', 'Scan timeout'),
                        value: '${settings.scanTimeoutMs} ms',
                        value2: settings.scanTimeoutMs.toDouble(),
                        min: 300,
                        max: 4000,
                        divisions: 37,
                        onChanged: (value) => app.updateSettings(
                          settings.copyWith(scanTimeoutMs: value.round()),
                        ),
                      ),
                      Divider(height: 1, color: context.borderColor),
                      _SliderRow(
                        label: context.tr('عدد الطلبات المتزامنة', 'Concurrency'),
                        value: '${settings.scanConcurrency}',
                        value2: settings.scanConcurrency.toDouble(),
                        min: 8,
                        max: 96,
                        divisions: 22,
                        onChanged: (value) => app.updateSettings(
                          settings.copyWith(scanConcurrency: value.round()),
                        ),
                      ),
                      Divider(height: 1, color: context.borderColor),
                      _SliderRow(
                        label: context.tr('عدد حزم البينغ', 'Ping count'),
                        value: '${settings.pingCount}',
                        value2: settings.pingCount.toDouble(),
                        min: 1,
                        max: 20,
                        divisions: 19,
                        onChanged: (value) => app.updateSettings(
                          settings.copyWith(pingCount: value.round()),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                SectionTitle(title: context.tr('محلي بالكامل', 'Local only')),
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  child: Column(
                    children: [
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.file_upload_outlined,
                            color: AppColors.primary),
                        title: Text(
                          context.tr('تصدير نسخة احتياطية', 'Export backup'),
                          style: bodyStyle(context).copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        subtitle: Text(
                          context.tr(
                            'ملف JSON يحتوي أجهزتك وسجلك',
                            'A JSON file with your devices and history',
                          ),
                          style: mutedStyle(context).copyWith(fontSize: 10.5),
                        ),
                        onTap: _export,
                      ),
                      Divider(height: 1, color: context.borderColor),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.file_download_outlined,
                            color: AppColors.info),
                        title: Text(
                          context.tr('استيراد نسخة احتياطية', 'Import backup'),
                          style: bodyStyle(context).copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        subtitle: Text(
                          context.tr(
                            'استعد أجهزتك وسجلك من ملف',
                            'Restore your devices and history from a file',
                          ),
                          style: mutedStyle(context).copyWith(fontSize: 10.5),
                        ),
                        onTap: _import,
                      ),
                      Divider(height: 1, color: context.borderColor),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.table_chart_outlined,
                            color: AppColors.accent),
                        title: Text(
                          context.tr('تصدير CSV (الأجهزة)', 'Export CSV (devices)'),
                          style: bodyStyle(context).copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        subtitle: Text(
                          context.tr(
                            'جدول الأجهزة بصيغة CSV للمشاركة أو التحليل',
                            'Devices table as CSV for sharing or analysis',
                          ),
                          style: mutedStyle(context).copyWith(fontSize: 10.5),
                        ),
                        onTap: _exportCsv,
                      ),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.restart_alt_rounded,
                            color: AppColors.danger),
                        title: Text(
                          context.tr('حذف كل البيانات', 'Delete all data'),
                          style: bodyStyle(context).copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                            color: AppColors.danger,
                          ),
                        ),
                        subtitle: Text(
                          context.tr('لا يمكن التراجع عن هذا الإجراء', 'This cannot be undone'),
                          style: mutedStyle(context).copyWith(fontSize: 10.5),
                        ),
                        onTap: () async {
                          final ok = await confirmDialog(
                            context,
                            title: context.tr('حذف كل البيانات؟', 'Delete all data?'),
                            message: context.tr(
                              'ستُحذف كل الأجهزة والسجل والإعدادات من هذا الجهاز.',
                              'All devices, history and settings will be removed from this device.',
                            ),
                            confirmLabel: context.tr('حذف', 'Delete'),
                            danger: true,
                          );
                          if (ok) {
                            await app.resetEverything();
                            if (!context.mounted) return;
                            showToast(
                              context,
                              context.tr('حُذفت البيانات', 'Data deleted'),
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                SectionTitle(title: context.tr('حول', 'About')),
                AppCard(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  child: Column(
                    children: [
                      InfoRow(
                        icon: Icons.info_outline_rounded,
                        label: context.tr('الإصدار', 'Version'),
                        value: _version.isEmpty ? '—' : _version,
                        mono: true,
                      ),
                      Divider(height: 1, color: context.borderColor),
                      InfoRow(
                        icon: Icons.code_rounded,
                        label: context.tr('الترخيص', 'License'),
                        value: 'MIT',
                      ),
                      Divider(height: 1, color: context.borderColor),
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.favorite_outline_rounded,
                            color: AppColors.primary),
                        title: Text(
                          context.tr('عن CobraNet', 'About CobraNet'),
                          style: bodyStyle(context).copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        trailing: Icon(Icons.chevron_right_rounded,
                            color: context.mutedColor),
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const AboutScreen(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Center(
                  child: Text(
                    'CobraNet · ${context.tr('مجاني ومفتوح المصدر', 'free and open source')}',
                    style: mutedStyle(context).copyWith(fontSize: 10.5),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _SwitchRow extends StatelessWidget {
  const _SwitchRow({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: bodyStyle(context).copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: mutedStyle(context).copyWith(fontSize: 10.5),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: AppColors.primary,
          ),
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({
    required this.label,
    required this.value,
    required this.value2,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  final String label;
  final String value;
  final double value2;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: bodyStyle(context).copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 12.5,
                  ),
                ),
              ),
              Text(
                value,
                style: context.monoStyle.copyWith(
                  fontSize: 11,
                  color: AppColors.primary,
                ),
              ),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: AppColors.primary,
              thumbColor: AppColors.primary,
              inactiveTrackColor: context.cardAltColor,
              trackHeight: 3,
            ),
            child: Slider(
              value: value2.clamp(min, max),
              min: min,
              max: max,
              divisions: divisions,
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
