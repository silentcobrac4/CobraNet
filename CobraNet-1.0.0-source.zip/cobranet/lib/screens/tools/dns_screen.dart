import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/dns_client.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class DnsScreen extends StatefulWidget {
  const DnsScreen({super.key, this.initialName = ''});
  final String initialName;

  @override
  State<DnsScreen> createState() => _DnsScreenState();
}

class _DnsScreenState extends State<DnsScreen> {
  late final TextEditingController _name =
      TextEditingController(text: widget.initialName);
  late final TextEditingController _server = TextEditingController();
  String _type = 'A';
  bool _running = false;
  DnsResult? _result;

  @override
  void dispose() {
    _name.dispose();
    _server.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      showToast(context, context.tr('أدخل اسمًا', 'Enter a name'), error: true);
      return;
    }
    setState(() {
      _running = true;
      _result = null;
    });
    final servers = <String>[
      if (_server.text.trim().isNotEmpty) _server.text.trim(),
      if (_server.text.trim().isEmpty && app.netInfo?.gateway != null)
        app.netInfo!.gateway!,
      if (_server.text.trim().isEmpty) ...app.netInfo?.dnsServers ?? const [],
      '1.1.1.1',
      '8.8.8.8',
    ];
    final result = await DnsClient.lookup(
      name: name,
      type: _type,
      servers: servers,
      timeoutMs: 2500,
    );
    if (!mounted) return;
    setState(() {
      _running = false;
      _result = result;
    });
    app.addHistory(
      tool: 'dns',
      query: '$name $_type',
      summary: result.summary,
      detail: result.records.map((r) => '${r.type} ${r.value}').join('\n'),
      ok: result.records.isNotEmpty,
    );
  }

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return ToolPage(
      title: context.tr('استعلام DNS', 'DNS lookup'),
      subtitle: context.tr(
        'استعلام مباشر عن سجلات A و AAAA و MX و TXT وغيرها.',
        'Query A, AAAA, MX, TXT and more directly.',
      ),
      icon: Icons.dns_rounded,
      children: [
        AppField(
          controller: _name,
          label: context.tr('الاسم أو العنوان', 'Name or address'),
          hint: 'example.com',
          mono: true,
          keyboardType: TextInputType.url,
          onSubmitted: (_) {
            if (!_running) _run();
          },
        ),
        const SizedBox(height: 12),
        AppField(
          controller: _server,
          label: context.tr('خادم مخصص (اختياري)', 'Custom server (optional)'),
          hint: '1.1.1.1',
          mono: true,
          keyboardType: TextInputType.text,
        ),
        const SizedBox(height: 14),
        SectionTitle(title: context.tr('نوع السجل', 'Record type')),
        LabeledChips(
          options: const ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS', 'PTR', 'SOA'],
          selected: _type,
          onSelected: (value) => setState(() => _type = value),
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ الاستعلام…', 'Querying…')
              : context.tr('استعلم', 'Look up'),
          icon: Icons.search_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (result != null) ...[
          const SizedBox(height: 18),
          ResultCard(
            title: context.tr('النتيجة', 'Result'),
            tone: result.records.isEmpty ? AppColors.accent : AppColors.primary,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Pill(label: result.statusText, color: result.status == 0
                        ? AppColors.primary
                        : AppColors.danger),
                    const SizedBox(width: 6),
                    if (result.server.isNotEmpty)
                      Pill(label: result.server, color: AppColors.info),
                    const SizedBox(width: 6),
                    Pill(label: '${result.ms}ms', color: AppColors.accent),
                  ],
                ),
                if (result.error != null) ...[
                  const SizedBox(height: 10),
                  Text(
                    result.error!,
                    style: mutedStyle(context).copyWith(fontSize: 12),
                  ),
                ],
                if (result.records.isEmpty && result.error == null) ...[
                  const SizedBox(height: 10),
                  Text(
                    context.tr('لا توجد سجلات من هذا النوع.', 'No records of this type.'),
                    style: mutedStyle(context),
                  ),
                ],
                for (final record in result.records) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: context.cardAltColor,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: context.borderColor),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Pill(label: record.type, color: AppColors.info),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SelectableText(
                            record.value,
                            textDirection: TextDirection.ltr,
                            style: context.monoStyle.copyWith(fontSize: 12),
                          ),
                        ),
                        if (record.ttl > 0)
                          Text(
                            'TTL ${record.ttl}',
                            style: mutedStyle(context).copyWith(fontSize: 9.5),
                          ),
                      ],
                    ),
                  ),
                ],
                if (result.records.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SoftButton(
                    label: context.tr('نسخ الكل', 'Copy all'),
                    icon: Icons.content_copy_rounded,
                    compact: true,
                    onPressed: () => copyToClipboard(
                      context,
                      result.records.map((r) => r.value).join('\n'),
                      context.tr('تم النسخ', 'Copied'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ],
    );
  }
}
