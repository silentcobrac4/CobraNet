import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class HttpCheckScreen extends StatefulWidget {
  const HttpCheckScreen({super.key, this.initialUrl = ''});
  final String initialUrl;

  @override
  State<HttpCheckScreen> createState() => _HttpCheckScreenState();
}

class _HttpCheckScreenState extends State<HttpCheckScreen> {
  late final TextEditingController _url =
      TextEditingController(text: widget.initialUrl);
  bool _running = false;
  HttpProbeResult? _result;

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final url = _url.text.trim();
    if (url.isEmpty) {
      showToast(context, context.tr('أدخل رابطًا', 'Enter a URL'), error: true);
      return;
    }
    setState(() {
      _running = true;
      _result = null;
    });
    final result = await HttpProbeService.probe(url);
    if (!mounted) return;
    setState(() {
      _running = false;
      _result = result;
    });
    app.addHistory(
      tool: 'http',
      query: url,
      summary: result.ok
          ? 'HTTP ${result.statusCode} · ${result.elapsedMs}ms'
          : (result.error ?? context.tr('فشل', 'Failed')),
      ok: result.ok,
    );
  }

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return ToolPage(
      title: context.tr('فحص رابط', 'HTTP check'),
      subtitle: context.tr(
        'اعرف حالة الرابط والترويسات وزمن الاستجابة.',
        'Check status code, headers and response time.',
      ),
      icon: Icons.http_rounded,
      children: [
        AppField(
          controller: _url,
          label: context.tr('الرابط', 'URL'),
          hint: 'https://example.com',
          mono: true,
          keyboardType: TextInputType.url,
          onSubmitted: (_) {
            if (!_running) _run();
          },
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ الفحص…', 'Checking…')
              : context.tr('افحص الرابط', 'Check URL'),
          icon: Icons.http_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (result != null) ...[
          const SizedBox(height: 18),
          ResultCard(
            title: context.tr('النتيجة', 'Result'),
            tone: result.ok ? AppColors.primary : AppColors.danger,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (result.ok) ...[
                  Row(
                    children: [
                      Pill(
                        label: '${result.statusCode}',
                        color: result.statusCode >= 400
                            ? AppColors.danger
                            : AppColors.primary,
                        solid: true,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          result.reasonPhrase,
                          style: bodyStyle(context).copyWith(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Pill(
                        label: '${result.elapsedMs}ms',
                        color: AppColors.accent,
                      ),
                    ],
                  ),
                  if (result.finalUrl != result.url) ...[
                    const SizedBox(height: 10),
                    Text(
                      result.finalUrl,
                      textDirection: TextDirection.ltr,
                      style: context.monoStyle.copyWith(
                        fontSize: 11,
                        color: context.mutedColor,
                      ),
                    ),
                  ],
                  if (result.redirects.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    SectionTitle(
                      title: context.tr('التحويلات', 'Redirects'),
                      padding: const EdgeInsets.only(bottom: 6),
                    ),
                    for (final item in result.redirects)
                      Text(
                        item,
                        textDirection: TextDirection.ltr,
                        style: context.monoStyle.copyWith(fontSize: 10.5),
                      ),
                  ],
                  const SizedBox(height: 14),
                  SectionTitle(
                    title: context.tr('الترويسات', 'Headers'),
                    padding: const EdgeInsets.only(bottom: 6),
                  ),
                  ...result.headers.entries.map(
                    (entry) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 120,
                            child: Text(
                              entry.key,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: mutedStyle(context).copyWith(fontSize: 10.5),
                            ),
                          ),
                          Expanded(
                            child: SelectableText(
                              entry.value,
                              textDirection: TextDirection.ltr,
                              style: context.monoStyle.copyWith(fontSize: 10.5),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ] else
                  Text(
                    result.error ?? context.tr('فشل الفحص', 'Check failed'),
                    style: mutedStyle(context).copyWith(fontSize: 12),
                  ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
