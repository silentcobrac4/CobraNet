import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class TracerouteScreen extends StatefulWidget {
  const TracerouteScreen({super.key, this.initialHost = ''});
  final String initialHost;

  @override
  State<TracerouteScreen> createState() => _TracerouteScreenState();
}

class _TracerouteScreenState extends State<TracerouteScreen> {
  late final TextEditingController _host =
      TextEditingController(text: widget.initialHost);
  bool _running = false;
  bool _cancelRequested = false;
  final List<TraceHop> _hops = [];
  String? _error;
  String? _note;

  @override
  void dispose() {
    _cancelRequested = true;
    _host.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final host = _host.text.trim();
    if (host.isEmpty) {
      showToast(context, context.tr('أدخل عنوانًا', 'Enter an address'), error: true);
      return;
    }
    setState(() {
      _running = true;
      _cancelRequested = false;
      _hops.clear();
      _error = null;
      _note = null;
    });
    final result = await TraceService.trace(
      host,
      onHop: (hop) {
        if (!mounted) return;
        setState(() {
          _hops.removeWhere((h) => h.ttl == hop.ttl);
          _hops.add(hop);
          _hops.sort((a, b) => a.ttl.compareTo(b.ttl));
        });
      },
      isCancelled: () => _cancelRequested,
    );
    if (!mounted) return;
    setState(() {
      _running = false;
      _hops
        ..clear()
        ..addAll(result.hops);
      _error = result.error;
      _note = result.note;
    });
    if (result.hops.isNotEmpty) {
      app.addHistory(
        tool: 'traceroute',
        query: host,
        summary: '${result.hops.length} ${context.tr('قفزة', 'hops')}',
        detail: result.hops
            .map((h) => '${h.ttl}  ${h.hosts.join(' ')}')
            .join('\n'),
        ok: result.error == null,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ToolPage(
      title: context.tr('تتبع المسار', 'Traceroute'),
      subtitle: context.tr(
        'اعرف القفزات التي تمر بها الحزم حتى الوجهة.',
        'See the hops packets take to reach a destination.',
      ),
      icon: Icons.route_rounded,
      trailing: _running
          ? RoundIconButton(
              icon: Icons.stop_rounded,
              color: AppColors.danger,
              tooltip: context.tr('إيقاف', 'Stop'),
              onPressed: () => setState(() => _cancelRequested = true),
            )
          : null,
      children: [
        AppField(
          controller: _host,
          label: context.tr('الوجهة', 'Destination'),
          hint: '8.8.8.8',
          mono: true,
          keyboardType: TextInputType.url,
          onSubmitted: (_) {
            if (!_running) _run();
          },
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ التتبع…', 'Tracing…')
              : context.tr('ابدأ التتبع', 'Start trace'),
          icon: Icons.play_arrow_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (_note != null) ...[
          const SizedBox(height: 10),
          Text(
            '${context.tr('الطريقة', 'Method')}: $_note',
            style: mutedStyle(context).copyWith(fontSize: 10.5),
          ),
        ],
        if (_error != null) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.accent.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.accent.withValues(alpha: 0.25)),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline_rounded,
                    size: 17, color: AppColors.accent),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    _error!,
                    style: mutedStyle(context).copyWith(fontSize: 11.5),
                  ),
                ),
              ],
            ),
          ),
        ],
        if (_hops.isNotEmpty) ...[
          const SizedBox(height: 18),
          ResultCard(
            title: context.tr('القفزات', 'Hops'),
            tone: AppColors.primary,
            child: Column(
              children: _hops.map((hop) {
                final host = hop.hosts.isEmpty
                    ? context.tr('لا رد', 'No reply')
                    : hop.hosts.join(', ');
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${hop.ttl}',
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          host,
                          textDirection: TextDirection.ltr,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: context.monoStyle.copyWith(fontSize: 12),
                        ),
                      ),
                      if (hop.times.isNotEmpty)
                        Text(
                          hop.times
                              .map((t) => '${t.toStringAsFixed(1)}ms')
                              .join(' / '),
                          style: mutedStyle(context).copyWith(fontSize: 10),
                        ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ],
    );
  }
}
