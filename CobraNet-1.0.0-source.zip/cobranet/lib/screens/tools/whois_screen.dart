import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class WhoisScreen extends StatefulWidget {
  const WhoisScreen({super.key, this.initialQuery = ''});
  final String initialQuery;

  @override
  State<WhoisScreen> createState() => _WhoisScreenState();
}

class _WhoisScreenState extends State<WhoisScreen> {
  late final TextEditingController _query =
      TextEditingController(text: widget.initialQuery);
  bool _running = false;
  String? _raw;
  String? _error;

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final query = _query.text.trim();
    if (query.isEmpty) {
      showToast(context, context.tr('أدخل نطاقًا', 'Enter a domain'), error: true);
      return;
    }
    setState(() {
      _running = true;
      _raw = null;
      _error = null;
    });
    try {
      final text = await WhoisService.lookup(query);
      if (!mounted) return;
      setState(() {
        _running = false;
        _raw = text;
      });
      final registrar = RegExp(
        r'^\s*registrar:\s*(.+)$',
        multiLine: true,
        caseSensitive: false,
      ).firstMatch(text)?.group(1)?.trim();
      app.addHistory(
        tool: 'whois',
        query: query,
        summary: registrar ?? context.tr('نتيجة WHOIS', 'WHOIS result'),
        detail: text.length > 4000 ? text.substring(0, 4000) : text,
        ok: true,
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _running = false;
        _error = e is NetToolException ? e.message : '$e';
      });
      app.addHistory(
        tool: 'whois',
        query: query,
        summary: _error ?? '',
        ok: false,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ToolPage(
      title: 'WHOIS',
      subtitle: context.tr(
        'بيانات تسجيل النطاق من خوادم WHOIS العامة.',
        'Domain registration data from public WHOIS servers.',
      ),
      icon: Icons.travel_explore_rounded,
      children: [
        AppField(
          controller: _query,
          label: context.tr('النطاق أو عنوان IP', 'Domain or IP address'),
          hint: 'example.com',
          mono: true,
          keyboardType: TextInputType.url,
          onSubmitted: (_) {
            if (!_running) _run();
          },
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ البحث…', 'Looking up…')
              : context.tr('ابحث', 'Look up'),
          icon: Icons.search_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (_error != null) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.danger.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.danger.withValues(alpha: 0.25)),
            ),
            child: Text(
              _error!,
              style: mutedStyle(context).copyWith(fontSize: 12),
            ),
          ),
        ],
        if (_raw != null && _raw!.isNotEmpty) ...[
          const SizedBox(height: 16),
          ResultCard(
            title: context.tr('السجل الكامل', 'Full record'),
            trailing: SoftButton(
              label: context.tr('نسخ', 'Copy'),
              icon: Icons.content_copy_rounded,
              compact: true,
              onPressed: () => copyToClipboard(
                context,
                _raw!,
                context.tr('تم النسخ', 'Copied'),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(12),
              constraints: const BoxConstraints(maxHeight: 420),
              decoration: BoxDecoration(
                color: context.cardAltColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: SingleChildScrollView(
                child: SelectableText(
                  _raw!,
                  textDirection: TextDirection.ltr,
                  style: context.monoStyle.copyWith(fontSize: 11.5),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}
