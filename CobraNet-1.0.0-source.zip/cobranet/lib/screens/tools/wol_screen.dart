import 'package:material_ui/material_ui.dart';

import '../../core/ip_utils.dart';
import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class WolScreen extends StatefulWidget {
  const WolScreen({super.key, this.initialMac = ''});
  final String initialMac;

  @override
  State<WolScreen> createState() => _WolScreenState();
}

class _WolScreenState extends State<WolScreen> {
  late final TextEditingController _mac =
      TextEditingController(text: widget.initialMac);
  final _broadcast = TextEditingController();
  bool _running = false;

  @override
  void dispose() {
    _mac.dispose();
    _broadcast.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final mac = _mac.text.trim();
    if (!MacUtils.isValid(mac)) {
      showToast(
        context,
        context.tr('أدخل عنوان MAC صالحًا', 'Enter a valid MAC address'),
        error: true,
      );
      return;
    }
    setState(() => _running = true);
    try {
      final net = app.netInfo;
      final targets = <String>{'255.255.255.255'};
      if (net?.ip != null) {
        final info = IpUtils.parseSubnet(net!.ip!);
        if (info != null) targets.add(info.broadcast);
      }
      if (_broadcast.text.trim().isNotEmpty) {
        targets.add(_broadcast.text.trim());
      }
      final count = await WolService.wake(
        mac: MacUtils.normalize(mac),
        broadcasts: targets,
      );
      if (!mounted) return;
      setState(() => _running = false);
      showToast(
        context,
        context.tr(
          'أُرسلت الحزمة السحرية إلى $count عنوان بث',
          'Magic packet sent to $count broadcast address(es)',
        ),
      );
      app.addHistory(
        tool: 'wol',
        query: MacUtils.normalize(mac),
        summary: '${targets.length} ${context.tr('بث', 'broadcasts')}',
        ok: true,
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _running = false);
      showToast(
        context,
        e is NetToolException ? e.message : '$e',
        error: true,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ToolPage(
      title: context.tr('إيقاظ جهاز', 'Wake on LAN'),
      subtitle: context.tr(
        'أرسل حزمة سحرية لتشغيل جهاز يدعم Wake-on-LAN.',
        'Send a magic packet to power on a Wake-on-LAN capable device.',
      ),
      icon: Icons.power_settings_new_rounded,
      children: [
        AppField(
          controller: _mac,
          label: 'MAC',
          hint: 'AA:BB:CC:DD:EE:FF',
          mono: true,
          keyboardType: TextInputType.text,
          textCapitalization: TextCapitalization.characters,
          onSubmitted: (_) {
            if (!_running) _run();
          },
        ),
        const SizedBox(height: 12),
        AppField(
          controller: _broadcast,
          label: context.tr('عنوان البث (اختياري)', 'Broadcast address (optional)'),
          hint: '192.168.1.255',
          mono: true,
          keyboardType: TextInputType.text,
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ الإرسال…', 'Sending…')
              : context.tr('أرسل الحزمة', 'Send packet'),
          icon: Icons.bolt_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        const SizedBox(height: 16),
        AppCard(
          padding: const EdgeInsets.all(13),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.lightbulb_outline_rounded,
                  size: 17, color: AppColors.accent),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  context.tr(
                    'يجب تفعيل Wake-on-LAN في إعدادات الجهاز، ويكون الجهاز متصلًا بالكهرباء والكابل أو Wi-Fi.',
                    'Wake-on-LAN must be enabled on the target device, and it must stay connected to power and to the network.',
                  ),
                  style: mutedStyle(context).copyWith(fontSize: 11.5),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
