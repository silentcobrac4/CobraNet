import 'dart:async';

import 'package:material_ui/material_ui.dart';
import 'package:multicast_dns/multicast_dns.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class DiscoveryScreen extends StatefulWidget {
  const DiscoveryScreen({super.key});

  @override
  State<DiscoveryScreen> createState() => _DiscoveryScreenState();
}

class _DiscoveredService {
  _DiscoveredService({
    required this.name,
    required this.type,
    required this.host,
    required this.port,
    required this.addresses,
  });

  final String name;
  final String type;
  final String host;
  final int port;
  final Set<String> addresses;

  String get key => '$name|$type|$host|$port';
}

class _DiscoveryScreenState extends State<DiscoveryScreen> {
  final List<_DiscoveredService> _services = [];
  bool _running = false;
  bool _cancelled = false;
  String? _error;

  static const _types = <String>[
    '_http._tcp',
    '_https._tcp',
    '_ssh._tcp',
    '_smb._tcp',
    '_ftp._tcp',
    '_printer._tcp',
    '_ipp._tcp',
    '_googlecast._tcp',
    '_airplay._tcp',
    '_raop._tcp',
    '_hap._tcp',
    '_workstation._tcp',
  ];

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void dispose() {
    _cancelled = true;
    super.dispose();
  }

  Future<void> _start() async {
    if (_running) return;
    setState(() {
      _running = true;
      _cancelled = false;
      _error = null;
      _services.clear();
    });

    final client = MDnsClient();
    try {
      await client.start();
      final deadline = DateTime.now().add(const Duration(seconds: 7));

      Future<void> browse(String type) async {
        try {
          await for (final ptr in client
              .lookup<PtrResourceRecord>(ResourceRecordQuery.serverPointer('$type.local'))) {
            if (_cancelled || DateTime.now().isAfter(deadline)) return;
            final srvRecords = client.lookup<SrvResourceRecord>(
              ResourceRecordQuery.service(ptr.domainName),
            );
            await for (final srv in srvRecords) {
              if (_cancelled || DateTime.now().isAfter(deadline)) return;
              final addresses = <String>{};
              try {
                await for (final ip in client.lookup<IPAddressResourceRecord>(
                  ResourceRecordQuery.addressIPv4(srv.target),
                )) {
                  addresses.add(ip.address.address);
                  if (_cancelled || DateTime.now().isAfter(deadline)) break;
                }
              } catch (_) {}
              final service = _DiscoveredService(
                name: ptr.domainName.split('.').first,
                type: type,
                host: srv.target,
                port: srv.port,
                addresses: addresses,
              );
              if (!_services.any((s) => s.key == service.key) && mounted) {
                setState(() => _services.add(service));
              }
              break;
            }
          }
        } catch (_) {}
      }

      await Future.wait(_types.map(browse));
      // Keep listening until deadline.
      while (!_cancelled && DateTime.now().isBefore(deadline)) {
        await Future.delayed(const Duration(milliseconds: 200));
      }
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      client.stop();
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ToolPage(
      title: context.tr('اكتشاف الأجهزة', 'Device discovery'),
      subtitle: context.tr(
        'اكتشف الأجهزة والخدمات (mDNS/Bonjour) في شبكتك.',
        'Discover devices and services (mDNS/Bonjour) on your network.',
      ),
      icon: Icons.travel_explore_rounded,
      trailing: _running
          ? RoundIconButton(
              icon: Icons.stop_rounded,
              color: AppColors.danger,
              tooltip: context.tr('إيقاف', 'Stop'),
              onPressed: () => setState(() => _cancelled = true),
            )
          : RoundIconButton(
              icon: Icons.refresh_rounded,
              tooltip: context.tr('إعادة', 'Refresh'),
              onPressed: _start,
            ),
      children: [
        AppCard(
          padding: const EdgeInsets.all(13),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.info_outline_rounded,
                  size: 17, color: AppColors.primary),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  context.tr(
                    'يستمع لبروتوكول mDNS لمدة 7 ثوانٍ. بعض الأجهزة لا تعلن عن نفسها.',
                    'Listens to mDNS for 7 seconds. Some devices do not announce themselves.',
                  ),
                  style: mutedStyle(context).copyWith(fontSize: 11.5),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (_error != null)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.danger.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.danger.withValues(alpha: 0.25)),
            ),
            child: Text(_error!, style: mutedStyle(context).copyWith(fontSize: 11.5)),
          ),
        if (_services.isEmpty && !_running)
          EmptyState(
            icon: Icons.travel_explore_rounded,
            title: context.tr('لم يُكتشف شيء', 'Nothing discovered'),
            message: context.tr(
              'اضغط "إعادة" لبدء الاكتشاف.',
              'Tap refresh to start discovery.',
            ),
          ),
        for (final service in _services) ...[
          AppCard(
            padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Icon(Icons.dns_rounded,
                      size: 17, color: AppColors.primary),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        service.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: bodyStyle(context).copyWith(
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${service.type}  ·  ${service.host}:${service.port}',
                        textDirection: TextDirection.ltr,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: context.monoStyle.copyWith(
                          fontSize: 10.5,
                          color: context.mutedColor,
                        ),
                      ),
                      if (service.addresses.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          service.addresses.join(', '),
                          textDirection: TextDirection.ltr,
                          style: context.monoStyle.copyWith(
                            fontSize: 10.5,
                            color: AppColors.primary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
        ],
        if (_running)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Row(
              children: [
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 10),
                Text(
                  context.tr('جارٍ الاكتشاف…', 'Discovering…'),
                  style: mutedStyle(context).copyWith(fontSize: 11.5),
                ),
              ],
            ),
          ),
      ],
    );
  }
}
