import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class SpeedTestScreen extends StatefulWidget {
  const SpeedTestScreen({super.key});

  @override
  State<SpeedTestScreen> createState() => _SpeedTestScreenState();
}

class _SpeedTestScreenState extends State<SpeedTestScreen> {
  final _url = TextEditingController(text: SpeedTestService.defaultUrl);
  bool _running = false;
  bool _cancelRequested = false;
  int _bytes = 0;
  double _mbps = 0;
  Duration _elapsed = Duration.zero;
  int? _latency;
  SpeedTestResult? _result;

  @override
  void dispose() {
    _cancelRequested = true;
    _url.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    setState(() {
      _running = true;
      _cancelRequested = false;
      _bytes = 0;
      _mbps = 0;
      _elapsed = Duration.zero;
      _result = null;
    });
    final latency = await SpeedTestService.latency(
      SpeedTestService.defaultUrl.replaceAll('__down?bytes=25000000', '__down?bytes=0'),
    );
    if (!mounted) return;
    setState(() => _latency = latency);

    final result = await SpeedTestService.download(
      url: _url.text.trim().isEmpty
          ? SpeedTestService.defaultUrl
          : _url.text.trim(),
      onProgress: (bytes, mbps, elapsed) {
        if (!mounted) return;
        setState(() {
          _bytes = bytes;
          _mbps = mbps;
          _elapsed = elapsed;
        });
      },
      isCancelled: () => _cancelRequested,
    );
    if (!mounted) return;
    setState(() {
      _running = false;
      _result = result;
      _bytes = result.bytes;
      _mbps = result.mbps;
      _elapsed = result.duration;
    });
    if (result.ok) {
      app.addHistory(
        tool: 'speed',
        query: 'download',
        summary: '${result.mbps.toStringAsFixed(1)} Mbps',
        detail: '${formatBytes(result.bytes)} in ${formatDuration(result.duration)}',
        ok: true,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return ToolPage(
      title: context.tr('سرعة التنزيل', 'Speed test'),
      subtitle: context.tr(
        'قِس سرعة التنزيل من خادم عام. تحتاج إنترنت.',
        'Measure download speed from a public server. Needs internet.',
      ),
      icon: Icons.speed_rounded,
      trailing: _running
          ? RoundIconButton(
              icon: Icons.stop_rounded,
              color: AppColors.danger,
              tooltip: context.tr('إيقاف', 'Stop'),
              onPressed: () => setState(() => _cancelRequested = true),
            )
          : null,
      children: [
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
          gradient: AppColors.brandGradient,
          child: Column(
            children: [
              Text(
                _mbps.toStringAsFixed(1),
                style: const TextStyle(
                  fontSize: 46,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: -1.6,
                ),
              ),
              Text(
                'Mbps',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Colors.white.withValues(alpha: 0.6),
                ),
              ),
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: _running ? null : (_mbps == 0 ? 0 : 1),
                  minHeight: 4,
                  backgroundColor: Colors.white.withValues(alpha: 0.12),
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _Metric(
                    label: context.tr('تم التنزيل', 'Downloaded'),
                    value: formatBytes(_bytes),
                  ),
                  _Metric(
                    label: context.tr('المدة', 'Time'),
                    value: formatDuration(_elapsed),
                  ),
                  _Metric(
                    label: context.tr('الاستجابة', 'Latency'),
                    value: _latency == null ? '—' : '$_latency ms',
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        AppField(
          controller: _url,
          label: context.tr('رابط الاختبار', 'Test URL'),
          hint: SpeedTestService.defaultUrl,
          mono: true,
          keyboardType: TextInputType.url,
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ القياس…', 'Measuring…')
              : context.tr('ابدأ الاختبار', 'Start test'),
          icon: Icons.speed_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (result != null && !result.ok && !result.cancelled) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.danger.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(AppRadius.md),
              border: Border.all(color: AppColors.danger.withValues(alpha: 0.25)),
            ),
            child: Text(
              result.error ?? context.tr('فشل الاختبار', 'Test failed'),
              style: mutedStyle(context).copyWith(fontSize: 11.5),
            ),
          ),
        ],
        if (result != null && result.cancelled) ...[
          const SizedBox(height: 14),
          Text(
            context.tr('أُوقف الاختبار.', 'Test stopped.'),
            style: mutedStyle(context).copyWith(fontSize: 11.5),
          ),
        ],
        const SizedBox(height: 16),
        AppCard(
          padding: const EdgeInsets.all(13),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.shield_outlined, size: 17, color: AppColors.primary),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  context.tr(
                    'التنزيل فقط: هذا الاختبار لا يرسل أي بيانات عنك إلى أي خدمة.',
                    'Download only: this test sends no data about you to any service.',
                  ),
                  style: mutedStyle(context).copyWith(fontSize: 11.5),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            fontSize: 9.5,
            color: Colors.white.withValues(alpha: 0.55),
          ),
        ),
      ],
    );
  }
}
