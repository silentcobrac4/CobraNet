import 'package:material_ui/material_ui.dart';

import '../../core/ip_utils.dart';
import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class SubnetScreen extends StatefulWidget {
  const SubnetScreen({super.key, this.initialInput = ''});
  final String initialInput;

  @override
  State<SubnetScreen> createState() => _SubnetScreenState();
}

class _SubnetScreenState extends State<SubnetScreen> {
  late final TextEditingController _input = TextEditingController(
    text: widget.initialInput.isNotEmpty
        ? widget.initialInput
        : (app.netInfo?.cidr ?? '192.168.1.0/24'),
  );
  SubnetInfo? _info;

  @override
  void initState() {
    super.initState();
    _info = IpUtils.parseSubnet(_input.text);
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  void _calculate() {
    final text = _input.text.trim();
    final info = IpUtils.parseSubnet(text);
    setState(() => _info = info);
    app.addHistory(
      tool: 'subnet',
      query: text,
      summary: info == null
          ? 'invalid'
          : '${info.cidr} · ${info.hostCount} hosts',
      ok: info != null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final info = _info;
    return ToolPage(
      title: context.tr('حاسبة الشبكة', 'Subnet calculator'),
      subtitle: context.tr(
        'احسب النطاق والقناع وعدد الأجهزة دون اتصال.',
        'Work out ranges, masks and host counts offline.',
      ),
      icon: Icons.calculate_rounded,
      children: [
        AppField(
          controller: _input,
          label: context.tr('الشبكة', 'Network'),
          hint: '192.168.1.0/24',
          mono: true,
          keyboardType: TextInputType.text,
          onSubmitted: (_) => _calculate(),
        ),
        if (_info == null) ...[
          const SizedBox(height: 8),
          Text(
            context.tr(
              'صيغة غير صحيحة. مثال: 192.168.1.0/24',
              'Invalid format. Example: 192.168.1.0/24',
            ),
            style: mutedStyle(context).copyWith(
              color: AppColors.danger,
              fontSize: 11.5,
            ),
          ),
        ],
        const SizedBox(height: 14),
        PrimaryButton(
          label: context.tr('احسب', 'Calculate'),
          icon: Icons.calculate_rounded,
          onPressed: _calculate,
        ),
        if (info != null) ...[
          const SizedBox(height: 18),
          ResultCard(
            title: info.cidr,
            trailing: Pill(
              label: info.isPrivate
                  ? context.tr('خاص', 'Private')
                  : context.tr('عام', 'Public'),
              color: info.isPrivate ? AppColors.primary : AppColors.accent,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InfoRow(
                  icon: Icons.tag_rounded,
                  label: context.tr('عنوان IP', 'IP address'),
                  value: info.ip,
                  mono: true,
                ),
                Divider(height: 1, color: context.borderColor),
                InfoRow(
                  icon: Icons.lan_rounded,
                  label: context.tr('قناع الشبكة', 'Netmask'),
                  value: info.mask,
                  mono: true,
                ),
                Divider(height: 1, color: context.borderColor),
                InfoRow(
                  icon: Icons.swap_horiz_rounded,
                  label: context.tr('Wildcard', 'Wildcard'),
                  value: info.wildcard,
                  mono: true,
                ),
                Divider(height: 1, color: context.borderColor),
                InfoRow(
                  icon: Icons.router_rounded,
                  label: context.tr('عنوان الشبكة', 'Network'),
                  value: info.network,
                  mono: true,
                ),
                Divider(height: 1, color: context.borderColor),
                InfoRow(
                  icon: Icons.first_page_rounded,
                  label: context.tr('أول جهاز', 'First host'),
                  value: info.firstHost,
                  mono: true,
                ),
                Divider(height: 1, color: context.borderColor),
                InfoRow(
                  icon: Icons.last_page_rounded,
                  label: context.tr('آخر جهاز', 'Last host'),
                  value: info.lastHost,
                  mono: true,
                ),
                Divider(height: 1, color: context.borderColor),
                InfoRow(
                  icon: Icons.campaign_rounded,
                  label: context.tr('عنوان البث', 'Broadcast'),
                  value: info.broadcast,
                  mono: true,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: StatTile(
                  value: '${info.hostCount}',
                  label: context.tr('أجهزة متاحة', 'Usable hosts'),
                  icon: Icons.devices_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: StatTile(
                  value: '${info.totalAddresses}',
                  label: context.tr('إجمالي العناوين', 'Total addresses'),
                  icon: Icons.numbers_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: StatTile(
                  value: '/${info.prefix}',
                  label: context.tr('البادئة', 'Prefix'),
                  icon: Icons.percent_rounded,
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }
}
