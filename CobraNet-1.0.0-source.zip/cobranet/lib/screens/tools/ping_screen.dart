import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class PingScreen extends StatefulWidget {
  const PingScreen({super.key, this.initialHost = ''});
  final String initialHost;

  @override
  State<PingScreen> createState() => _PingScreenState();
}

class _PingScreenState extends State<PingScreen> {
  late final TextEditingController _host =
      TextEditingController(text: widget.initialHost);
  int _count = 4;
  bool _running = false;
  bool _cancel = false;
  final List<PingSample> _samples = [];
  PingResult? _result;

  @override
  void dispose() {
    _cancel = true;
    _host.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final host = _host.text.trim();
    if (host.isEmpty) {
      showToast(context, context.tr('أدخل عنوانًا', 'Enter an address'), error: true);
      return;
    }
    setState(() {
      _running = true;
      _cancel = false;
      _samples.clear();
      _result = null;
    });
    final result = await PingService.run(
      host: host,
      count: _count,
      timeoutMs: app.settings.pingTimeoutMs,
      onSample: (sample) {
        if (!mounted) return;
        setState(() => _samples.add(sample));
      },
      isCancelled: () => _cancel,
    );
    if (!mounted) return;
    setState(() {
      _running = false;
      _result = result;
    });
    if (!result.usedTcp) {
      app.addHistory(
        tool: 'ping',
        query: host,
        summary:
            '${result.received}/${result.sent} · ${result.avgMs?.toStringAsFixed(1) ?? '—'}ms · ${result.lossPercent.toStringAsFixed(0)}%',
        detail: result.samples
            .map((s) => s.ok ? 'seq ${s.seq}: ${s.ms}ms' : 'seq ${s.seq}: ${s.error}')
            .join('\n'),
        ok: result.received > 0,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return ToolPage(
      title: context.tr('بينغ', 'Ping'),
      subtitle: context.tr(
        'قِس زمن الاستجابة وفقدان الحزم لمضيف على الشبكة.',
        'Measure round-trip time and packet loss to a host.',
      ),
      icon: Icons.network_ping_rounded,
      trailing: _running
          ? RoundIconButton(
              icon: Icons.stop_rounded,
              color: AppColors.danger,
              tooltip: context.tr('إيقاف', 'Stop'),
              onPressed: () => setState(() => _cancel = true),
            )
          : null,
      children: [
        AppField(
          controller: _host,
          label: context.tr('المضيف أو العنوان', 'Host or address'),
          hint: '192.168.1.1',
          mono: true,
          keyboardType: TextInputType.url,
          onSubmitted: (_) => _running ? null : _run(),
        ),
        const SizedBox(height: 12),
        SectionTitle(title: context.tr('عدد الحزم', 'Packet count')),
        LabeledChips(
          options: const ['4', '8', '16'],
          selected: '$_count',
          onSelected: (value) => setState(() => _count = int.parse(value)),
        ),
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ القياس…', 'Measuring…')
              : context.tr('ابدأ البينغ', 'Start ping'),
          icon: Icons.play_arrow_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (result != null) ...[
          const SizedBox(height: 18),
          _Summary(result: result),
        ],
        if (_samples.isNotEmpty) ...[
          const SizedBox(height: 14),
          ResultCard(
            title: context.tr('الحزم', 'Packets'),
            tone: result?.received == 0 && !_running
                ? AppColors.danger
                : AppColors.primary,
            child: Column(
              children: [
                for (final sample in _samples)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 44,
                          child: Text(
                            '#${sample.seq}',
                            style: context.monoStyle.copyWith(
                              fontSize: 11,
                              color: context.mutedColor,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            sample.ok
                                ? '${sample.ms} ms'
                                : _sampleError(context, sample.error),
                            style: bodyStyle(context).copyWith(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              color: sample.ok
                                  ? context.textColor
                                  : AppColors.danger,
                            ),
                          ),
                        ),
                        if (sample.note != null)
                          Pill(label: sample.note!, color: AppColors.accent),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
        if (result?.usedTcp == true) ...[
          const SizedBox(height: 12),
          _Note(
            text: context.tr(
              'هذا النظام لا يسمح ببينغ ICMP، لذلك قِسنا زمن الاتصال عبر TCP. النتيجة تقريبية لكنها مفيدة.',
              'This system blocks ICMP, so the app measured a TCP connect instead. The number is approximate but useful.',
            ),
          ),
        ],
        if (result?.error != null) ...[
          const SizedBox(height: 12),
          _Note(text: result!.error!, danger: true),
        ],
      ],
    );
  }

  String _sampleError(BuildContext context, String? error) {
    switch (error) {
      case 'unreachable':
        return context.tr('الوجهة غير متاحة', 'Destination unreachable');
      case 'timeout':
        return context.tr('انتهت المهلة', 'Timed out');
      case 'no tcp reply':
        return context.tr('لا رد TCP', 'No TCP reply');
      default:
        return context.tr('لا رد', 'No reply');
    }
  }
}

class _Summary extends StatelessWidget {
  const _Summary({required this.result});
  final PingResult result;

  @override
  Widget build(BuildContext context) {
    final ok = result.received > 0;
    return ResultCard(
      title: context.tr('الملخص', 'Summary'),
      tone: ok ? AppColors.primary : AppColors.danger,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: StatTile(
                  value: result.avgMs?.toStringAsFixed(1) ?? '—',
                  label: context.tr('المتوسط (ms)', 'Average (ms)'),
                  icon: Icons.speed_rounded,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: StatTile(
                  value: '${result.lossPercent.toStringAsFixed(0)}%',
                  label: context.tr('الفقدان', 'Loss'),
                  icon: Icons.percent_rounded,
                  color: result.lossPercent == 0
                      ? AppColors.primary
                      : AppColors.danger,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: StatTile(
                  value: '${result.minMs ?? '—'}',
                  label: context.tr('الأدنى (ms)', 'Min (ms)'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: StatTile(
                  value: '${result.maxMs ?? '—'}',
                  label: context.tr('الأعلى (ms)', 'Max (ms)'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: StatTile(
                  value: '${result.received}/${result.sent}',
                  label: context.tr('مستلمة', 'Received'),
                ),
              ),
            ],
          ),
          if (result.hostname != null && result.hostname != result.host) ...[
            const SizedBox(height: 12),
            InfoRow(
              icon: Icons.badge_outlined,
              label: context.tr('اسم المضيف', 'Hostname'),
              value: result.hostname!,
              mono: true,
            ),
          ],
        ],
      ),
    );
  }
}

class _Note extends StatelessWidget {
  const _Note({required this.text, this.danger = false});
  final String text;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final color = danger ? AppColors.danger : AppColors.accent;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: color.withValues(alpha: 0.25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline_rounded, size: 17, color: color),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              text,
              style: mutedStyle(context).copyWith(fontSize: 11.5),
            ),
          ),
        ],
      ),
    );
  }
}
