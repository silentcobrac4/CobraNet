import 'package:material_ui/material_ui.dart';

import '../../core/l10n.dart';
import '../../core/theme.dart';
import '../../services/net_tools.dart';
import '../../state/global.dart';
import '../../widgets/tool_page.dart';
import '../../widgets/ui.dart';

class PortScanScreen extends StatefulWidget {
  const PortScanScreen({super.key, this.initialHost = ''});
  final String initialHost;

  @override
  State<PortScanScreen> createState() => _PortScanScreenState();
}

class _PortScanScreenState extends State<PortScanScreen> {
  late final TextEditingController _host =
      TextEditingController(text: widget.initialHost);
  late final TextEditingController _ports =
      TextEditingController(text: 'common');
  String _preset = 'Common';
  bool _running = false;
  bool _cancelRequested = false;
  int _done = 0;
  int _total = 0;
  final List<PortScanResult> _results = [];

  static const _presets = <String, List<int>>{
    'Common': PortScanService.commonPorts,
    'Web': PortScanService.webPorts,
    'Home': PortScanService.homePorts,
    'Network': PortScanService.networkPorts,
  };

  @override
  void dispose() {
    _cancelRequested = true;
    _host.dispose();
    _ports.dispose();
    super.dispose();
  }

  List<int> _selectedPorts() {
    if (_preset == 'Custom') {
      return PortScanService.parsePorts(_ports.text);
    }
    return _presets[_preset] ?? PortScanService.commonPorts;
  }

  Future<void> _run() async {
    final host = _host.text.trim();
    if (host.isEmpty) {
      showToast(context, context.tr('أدخل عنوانًا', 'Enter an address'), error: true);
      return;
    }
    final ports = _selectedPorts();
    if (ports.isEmpty) {
      showToast(
        context,
        context.tr('أدخل منافذ صحيحة', 'Enter valid ports'),
        error: true,
      );
      return;
    }
    setState(() {
      _running = true;
      _cancelRequested = false;
      _done = 0;
      _total = ports.length;
      _results.clear();
    });
    final results = await PortScanService.scan(
      host: host,
      ports: ports,
      timeoutMs: app.settings.portTimeoutMs,
      onResult: (result, done, total) {
        if (!mounted) return;
        setState(() {
          _done = done;
          _total = total;
          if (result.open) _results.add(result);
        });
      },
      isCancelled: () => _cancelRequested,
    );
    if (!mounted) return;
    final open = results.where((r) => r.open).toList();
    setState(() {
      _running = false;
      _results
        ..clear()
        ..addAll(open);
    });
    app.addHistory(
      tool: 'ports',
      query: host,
      summary: open.isEmpty
          ? context.tr('لا منافذ مفتوحة', 'No open ports')
          : '${open.length} ${context.tr('منفذ مفتوح', 'open ports')}',
      detail: open.map((r) => '${r.port} (${r.ms}ms)').join('\n'),
      ok: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ToolPage(
      title: context.tr('فحص المنافذ', 'Port scan'),
      subtitle: context.tr(
        'افحص المنافذ المفتوحة على جهاز في شبكتك.',
        'Check which ports are open on a host.',
      ),
      icon: Icons.lan_rounded,
      trailing: _running
          ? RoundIconButton(
              icon: Icons.stop_rounded,
              color: AppColors.danger,
              tooltip: context.tr('إيقاف', 'Stop'),
              onPressed: () => setState(() => _cancelRequested = true),
            )
          : null,
      children: [
        AppField(
          controller: _host,
          label: context.tr('المضيف أو العنوان', 'Host or address'),
          hint: '192.168.1.1',
          mono: true,
          keyboardType: TextInputType.url,
        ),
        const SizedBox(height: 14),
        SectionTitle(title: context.tr('مجموعة المنافذ', 'Port set')),
        LabeledChips(
          options: const ['Common', 'Web', 'Home', 'Network', 'Custom'],
          selected: _preset,
          onSelected: (value) => setState(() => _preset = value),
        ),
        if (_preset == 'Custom') ...[
          const SizedBox(height: 12),
          AppField(
            controller: _ports,
            label: context.tr('المنافذ', 'Ports'),
            hint: '22,80,8000-8100',
            mono: true,
            keyboardType: TextInputType.text,
          ),
        ],
        const SizedBox(height: 16),
        PrimaryButton(
          label: _running
              ? context.tr('جارٍ الفحص…', 'Scanning…')
              : context.tr('ابدأ الفحص', 'Start scan'),
          icon: Icons.play_arrow_rounded,
          loading: _running,
          onPressed: _running ? null : _run,
        ),
        if (_running) ...[
          const SizedBox(height: 14),
          AppCard(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$_done / $_total',
                  style: context.monoStyle.copyWith(fontSize: 12),
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: _total == 0 ? null : _done / _total,
                    minHeight: 5,
                    backgroundColor: context.cardAltColor,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
        ],
        if (!_running && _done > 0) ...[
          const SizedBox(height: 18),
          ResultCard(
            title: context.tr('النتائج', 'Results'),
            tone: _results.isEmpty ? AppColors.accent : AppColors.primary,
            child: _results.isEmpty
                ? Text(
                    context.tr(
                      'لا توجد منافذ مفتوحة في هذه المجموعة.',
                      'No open ports in this set.',
                    ),
                    style: mutedStyle(context),
                  )
                : Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: _results
                        .map((r) => Pill(
                              label: '${r.port}',
                              color: AppColors.primary,
                              icon: Icons.check_rounded,
                            ))
                        .toList(),
                  ),
          ),
        ],
      ],
    );
  }
}
