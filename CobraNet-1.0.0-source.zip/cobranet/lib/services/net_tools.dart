import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import '../core/ip_utils.dart';

typedef CancelCheck = bool Function();

class NetToolException implements Exception {
  NetToolException(this.message);
  final String message;
  @override
  String toString() => message;
}

// ---------------------------------------------------------------------------
// Ping
// ---------------------------------------------------------------------------

class PingSample {
  PingSample({required this.seq, this.ms, this.error, this.note});
  final int seq;
  final int? ms;
  final String? error;
  final String? note;
  bool get ok => ms != null;
}

class PingResult {
  PingResult({
    required this.host,
    required this.samples,
    required this.sent,
    required this.received,
    required this.minMs,
    required this.avgMs,
    required this.maxMs,
    required this.lossPercent,
    this.hostname,
    this.usedTcp = false,
    this.duration = Duration.zero,
    this.error,
  });

  final String host;
  final List<PingSample> samples;
  final int sent;
  final int received;
  final int? minMs;
  final double? avgMs;
  final int? maxMs;
  final double lossPercent;
  final String? hostname;
  final bool usedTcp;
  final Duration duration;
  final String? error;

  bool get ok => error == null;
}

class PingService {
  PingService._();

  static Future<PingResult> run({
    required String host,
    int count = 4,
    int timeoutMs = 2000,
    void Function(PingSample sample)? onSample,
    CancelCheck? isCancelled,
  }) async {
    final target = host.trim();
    if (target.isEmpty) throw NetToolException('أدخل عنوانًا');
    final started = DateTime.now();
    final samples = <PingSample>[];
    var hostname = target;
    var sent = 0;
    var received = 0;
    var usedTcp = false;

    try {
      final waitSeconds = ((timeoutMs + 999) ~/ 1000).clamp(1, 10);
      final process = await Process.start('ping', [
        '-c',
        '$count',
        '-W',
        '$waitSeconds',
        target,
      ]);
      final buffer = StringBuffer();
      final subscription = process.stdout
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .listen((line) {
        buffer.writeln(line);
        final pingLine =
            RegExp(r'^PING\s+(\S+)\s+\(([^)]+)\)').firstMatch(line);
        if (pingLine != null) hostname = pingLine.group(1) ?? target;

        final seqMatch = RegExp(r'(?:icmp_)?seq=(\d+)').firstMatch(line);
        final timeMatch =
            RegExp(r'time[=<]\s*([0-9.]+)\s*ms').firstMatch(line);
        if (seqMatch != null) {
          final seq = int.tryParse(seqMatch.group(1)!) ?? samples.length + 1;
          sent++;
          if (timeMatch != null) {
            final ms = double.parse(timeMatch.group(1)!);
            received++;
            final sample = PingSample(seq: seq, ms: ms.round());
            samples.add(sample);
            onSample?.call(sample);
          } else {
            final error = line.contains('Unreachable')
                ? 'unreachable'
                : line.contains('timed out') || line.contains('timeout')
                    ? 'timeout'
                    : 'no reply';
            final sample = PingSample(seq: seq, error: error);
            samples.add(sample);
            onSample?.call(sample);
          }
        } else if (line.contains('100% packet loss') && sent == 0) {
          sent = count;
          for (var i = 1; i <= count; i++) {
            final sample = PingSample(seq: i, error: 'no reply');
            samples.add(sample);
            onSample?.call(sample);
          }
        }
      });

      process.stderr
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .listen((_) {});

      final exitCode = await process.exitCode.timeout(
        Duration(seconds: count * (waitSeconds + 1) + 6),
        onTimeout: () {
          process.kill();
          return -1;
        },
      );
      await subscription.cancel();
      if (isCancelled?.call() == true) {
        return _build(target, samples, sent, received, hostname, usedTcp,
            DateTime.now().difference(started), 'cancelled');
      }
      if (exitCode != 0 && samples.isEmpty) {
        final text = buffer.toString();
        if (text.contains('not found') ||
            text.contains('No such file') ||
            text.contains('Permission denied')) {
          usedTcp = true;
          return await _tcpPing(target, count, timeoutMs, onSample, started);
        }
        if (!text.contains('bytes from') && text.contains('Unknown host')) {
          return _build(target, samples, sent, received, hostname, usedTcp,
              DateTime.now().difference(started), 'اسم المضيف غير معروف');
        }
      }
      if (samples.isEmpty) {
        usedTcp = true;
        return await _tcpPing(target, count, timeoutMs, onSample, started);
      }
      return _build(target, samples, sent, received, hostname, usedTcp,
          DateTime.now().difference(started), null);
    } on ProcessException {
      return _tcpPing(target, count, timeoutMs, onSample, started);
    } catch (e) {
      return _tcpPing(target, count, timeoutMs, onSample, started, fallbackError: '$e');
    }
  }

  static Future<PingResult> _tcpPing(
    String host,
    int count,
    int timeoutMs,
    void Function(PingSample sample)? onSample,
    DateTime started, {
    String? fallbackError,
  }) async {
    final samples = <PingSample>[];
    var received = 0;
    const ports = [80, 443, 22, 53, 8080, 445, 62078];
    for (var i = 1; i <= count; i++) {
      var got = false;
      for (final port in ports) {
        final sw = Stopwatch()..start();
        try {
          final socket = await Socket.connect(
            host,
            port,
            timeout: Duration(milliseconds: timeoutMs.clamp(150, 3000)),
          );
          sw.stop();
          socket.destroy();
          received++;
          got = true;
          final sample = PingSample(seq: i, ms: sw.elapsedMilliseconds, note: 'TCP $port');
          samples.add(sample);
          onSample?.call(sample);
          break;
        } catch (_) {
          // Try the next common port.
        }
      }
      if (!got) {
        final sample = PingSample(seq: i, error: 'no tcp reply');
        samples.add(sample);
        onSample?.call(sample);
      }
    }
    return _build(host, samples, count, received, host, true,
        DateTime.now().difference(started),
        received == 0 ? (fallbackError ?? 'تعذّر الوصول إلى المضيف') : null);
  }

  static PingResult _build(
    String host,
    List<PingSample> samples,
    int sent,
    int received,
    String? hostname,
    bool usedTcp,
    Duration duration,
    String? error,
  ) {
    final values = samples.where((s) => s.ms != null).map((s) => s.ms!).toList();
    values.sort();
    final total = sent > 0 ? sent : samples.length;
    final minMs = values.isEmpty ? null : values.first;
    final maxMs = values.isEmpty ? null : values.last;
    final avg = values.isEmpty
        ? null
        : values.reduce((a, b) => a + b) / values.length;
    final loss = total == 0 ? 100.0 : ((total - received) / total) * 100;
    return PingResult(
      host: host,
      samples: samples,
      sent: total,
      received: received,
      minMs: minMs,
      avgMs: avg,
      maxMs: maxMs,
      lossPercent: loss.clamp(0, 100),
      hostname: hostname,
      usedTcp: usedTcp,
      duration: duration,
      error: error,
    );
  }
}

// ---------------------------------------------------------------------------
// Port scanning
// ---------------------------------------------------------------------------

class PortScanResult {
  const PortScanResult({
    required this.port,
    required this.open,
    required this.ms,
  });
  final int port;
  final bool open;
  final int ms;
}

class PortScanService {
  PortScanService._();

  static const commonPorts = <int>[
    21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1723,
    3306, 3389, 5900, 8080, 8443,
  ];

  static const webPorts = <int>[
    80, 443, 3000, 5000, 5173, 8000, 8008, 8080, 8443, 8888, 9000,
  ];

  static const homePorts = <int>[
    80, 443, 554, 631, 1883, 5000, 8008, 8009, 8080, 8443, 9100, 62078,
  ];

  static const networkPorts = <int>[
    22, 53, 67, 68, 123, 137, 138, 139, 161, 389, 445, 514, 631, 1900, 5353,
  ];

  static const _maxPorts = 4000;

  /// Parses `22,80,8000-8100` into a sorted unique list.
  static List<int> parsePorts(String input) {
    final ports = <int>{};
    final parts = input.split(RegExp(r'[,\s]+'));
    for (final part in parts) {
      final token = part.trim();
      if (token.isEmpty) continue;
      if (token.contains('-')) {
        final range = token.split('-');
        if (range.length != 2) continue;
        final start = int.tryParse(range[0]);
        final end = int.tryParse(range[1]);
        if (start == null || end == null) continue;
        final from = min(start, end).clamp(1, 65535);
        final to = max(start, end).clamp(1, 65535);
        for (var p = from; p <= to && ports.length < _maxPorts; p++) {
          ports.add(p);
        }
      } else {
        final port = int.tryParse(token);
        if (port != null && port >= 1 && port <= 65535) ports.add(port);
      }
    }
    final list = ports.toList()..sort();
    return list;
  }

  static Future<List<PortScanResult>> scan({
    required String host,
    required List<int> ports,
    int timeoutMs = 350,
    int concurrency = 80,
    void Function(PortScanResult result, int done, int total)? onResult,
    CancelCheck? isCancelled,
  }) async {
    final target = host.trim();
    if (target.isEmpty) throw NetToolException('أدخل عنوانًا');
    final queue = ports.toSet().toList()..sort();
    if (queue.isEmpty) throw NetToolException('لا توجد منافذ للفحص');
    final results = <PortScanResult>[];
    var index = 0;
    var done = 0;
    final workers = min(concurrency.clamp(1, 256), queue.length);

    Future<void> worker() async {
      while (true) {
        if (isCancelled?.call() == true) return;
        final i = index++;
        if (i >= queue.length) return;
        final port = queue[i];
        final sw = Stopwatch()..start();
        var open = false;
        try {
          final socket = await Socket.connect(
            target,
            port,
            timeout: Duration(milliseconds: timeoutMs.clamp(80, 5000)),
          );
          open = true;
          socket.destroy();
        } catch (_) {
          open = false;
        }
        sw.stop();
        done++;
        final result =
            PortScanResult(port: port, open: open, ms: sw.elapsedMilliseconds);
        results.add(result);
        onResult?.call(result, done, queue.length);
      }
    }

    await Future.wait(List.generate(workers, (_) => worker()));
    results.sort((a, b) => a.port.compareTo(b.port));
    return results;
  }
}

// ---------------------------------------------------------------------------
// WHOIS
// ---------------------------------------------------------------------------

class WhoisService {
  WhoisService._();

  static Future<String> lookup(String query, {int timeoutMs = 12000}) async {
    final clean = query
        .trim()
        .toLowerCase()
        .replaceAll(RegExp(r'^https?://'), '')
        .split('/')
        .first;
    if (clean.isEmpty) throw NetToolException('أدخل نطاقًا أو IP');
    final iana = await _query('whois.iana.org', clean, timeoutMs);
    final referral = RegExp(r'^\s*refer:\s*(\S+)', multiLine: true, caseSensitive: false).firstMatch(iana);
    if (referral != null) {
      final server = referral.group(1)!;
      try {
        final detailed = await _query(server, clean, timeoutMs);
        if (detailed.trim().isNotEmpty) return detailed;
      } catch (_) {}
    }
    if (iana.trim().isEmpty) {
      throw NetToolException('لم يصل رد من خادم WHOIS');
    }
    return iana;
  }

  static Future<String> _query(
    String server,
    String query,
    int timeoutMs,
  ) async {
    final socket = await Socket.connect(
      server,
      43,
      timeout: Duration(milliseconds: timeoutMs),
    );
    final buffer = BytesBuilder();
    final completer = Completer<void>();
    final subscription = socket.listen(
      (data) {
        if (buffer.length < 600 * 1024) buffer.add(data);
      },
      onDone: () {
        if (!completer.isCompleted) completer.complete();
      },
      onError: (Object error) {
        if (!completer.isCompleted) completer.completeError(error);
      },
      cancelOnError: true,
    );
    socket.write('$query\r\n');
    await socket.flush();
    try {
      await completer.future.timeout(Duration(milliseconds: timeoutMs));
    } on TimeoutException {
      // Partial responses are still useful.
    } finally {
      await subscription.cancel();
      socket.destroy();
    }
    final text = latin1.decode(buffer.takeBytes(), allowInvalid: true);
    return text.replaceAll('\r\n', '\n').trim();
  }
}

// ---------------------------------------------------------------------------
// Traceroute
// ---------------------------------------------------------------------------

class TraceHop {
  TraceHop({
    required this.ttl,
    required this.hosts,
    required this.times,
    required this.reached,
  });
  final int ttl;
  final List<String> hosts;
  final List<double> times;
  final bool reached;
}

class TraceResult {
  TraceResult({
    required this.host,
    required this.hops,
    this.error,
    this.note,
  });
  final String host;
  final List<TraceHop> hops;
  final String? error;
  final String? note;
  bool get ok => error == null && hops.isNotEmpty;
}

class TraceService {
  TraceService._();

  static Future<TraceResult> trace(
    String host, {
    int maxHops = 20,
    void Function(TraceHop hop)? onHop,
    CancelCheck? isCancelled,
  }) async {
    final target = host.trim();
    if (target.isEmpty) throw NetToolException('أدخل عنوانًا');

    // Prefer a real traceroute binary when the ROM ships one.
    for (final command in [
      ['traceroute', '-n', '-m', '$maxHops', '-w', '2', target],
      ['toybox', 'traceroute', '-n', '-m', '$maxHops', target],
    ]) {
      try {
        final result = await Process.run(command.first, command.sublist(1))
            .timeout(Duration(seconds: maxHops * 3 + 10));
        final text = '${result.stdout}\n${result.stderr}';
        if (result.exitCode == 0 && text.contains(RegExp(r'^\s*\d+\s', multiLine: true))) {
          final hops = _parseTraceroute(text);
          if (hops.isNotEmpty) {
            for (final hop in hops) {
              if (isCancelled?.call() == true) break;
              onHop?.call(hop);
            }
            return TraceResult(host: target, hops: hops, note: command.first);
          }
        }
      } catch (_) {}
    }

    // Fall back to TTL-limited pings, which work on stock Android.
    final hops = <TraceHop>[];
    var unsupported = false;
    for (var ttl = 1; ttl <= maxHops; ttl++) {
      if (isCancelled?.call() == true) break;
      try {
        final result = await Process.run('ping', [
          '-c',
          '1',
          '-W',
          '1',
          '-t',
          '$ttl',
          target,
        ]).timeout(const Duration(seconds: 4));
        final text = '${result.stdout}\n${result.stderr}';
        if (text.contains('invalid option') ||
            text.contains('Unknown option') ||
            text.contains('bad option')) {
          unsupported = true;
          break;
        }
        final from = RegExp(r'[Ff]rom\s+([0-9.]+)').firstMatch(text);
        final time =
            RegExp(r'time[=<]\s*([0-9.]+)\s*ms').firstMatch(text);
        final addresses = RegExp(r'([0-9]{1,3}(?:\.[0-9]{1,3}){3})')
            .allMatches(text)
            .map((m) => m.group(1)!)
            .toSet()
            .toList();
        final reached = result.exitCode == 0;
        final hopHosts = from != null
            ? [from.group(1)!]
            : reached
                ? [target]
                : <String>[];
        if (hopHosts.isEmpty && addresses.isNotEmpty && !reached) {
          hopHosts.addAll(addresses.take(2));
        }
        final hop = TraceHop(
          ttl: ttl,
          hosts: hopHosts,
          times: time == null ? const [] : [double.parse(time.group(1)!)],
          reached: reached,
        );
        hops.add(hop);
        onHop?.call(hop);
        if (reached) break;
      } catch (e) {
        if (e is ProcessException) {
          unsupported = true;
          break;
        }
      }
    }

    if (unsupported || hops.isEmpty) {
      return TraceResult(
        host: target,
        hops: hops,
        error: unsupported
            ? 'هذا الجهاز لا يسمح بتتبع المسار (traceroute غير متاح)'
            : 'لم يتم العثور على مسار',
      );
    }
    return TraceResult(
      host: target,
      hops: hops,
      note: 'ping TTL',
    );
  }

  static List<TraceHop> _parseTraceroute(String text) {
    final hops = <TraceHop>[];
    final lines = text.split('\n');
    for (final line in lines) {
      final match = RegExp(r'^\s*(\d+)\s+(.*)$').firstMatch(line);
      if (match == null) continue;
      final ttl = int.tryParse(match.group(1)!);
      if (ttl == null) continue;
      final rest = match.group(2)!;
      final hosts = RegExp(r'([0-9]{1,3}(?:\.[0-9]{1,3}){3})')
          .allMatches(rest)
          .map((m) => m.group(1)!)
          .toSet()
          .toList();
      final times = RegExp(r'([0-9.]+)\s*ms')
          .allMatches(rest)
          .map((m) => double.tryParse(m.group(1)!) ?? 0)
          .toList();
      if (hosts.isEmpty && times.isEmpty) continue;
      hops.add(TraceHop(
        ttl: ttl,
        hosts: hosts,
        times: times,
        reached: hosts.contains(hosts.isEmpty ? '' : hosts.last),
      ));
    }
    if (hops.isNotEmpty) {
      hops[hops.length - 1] = TraceHop(
        ttl: hops.last.ttl,
        hosts: hops.last.hosts,
        times: hops.last.times,
        reached: true,
      );
    }
    return hops;
  }
}

// ---------------------------------------------------------------------------
// Wake on LAN
// ---------------------------------------------------------------------------

class WolService {
  WolService._();

  static Future<int> wake({
    required String mac,
    Set<String> broadcasts = const {'255.255.255.255'},
    int port = 9,
  }) async {
    final bytes = MacUtils.toBytes(mac);
    if (bytes.length != 6) throw NetToolException('عنوان MAC غير صالح');
    final packet = <int>[
      ...List<int>.filled(6, 0xFF),
      for (var i = 0; i < 16; i++) ...bytes,
    ];
    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    var sent = 0;
    try {
      socket.broadcastEnabled = true;
      for (final target in broadcasts) {
        if (!IpUtils.isValid(target)) continue;
        try {
          socket.send(packet, InternetAddress(target), port);
          sent++;
        } catch (_) {}
      }
      await Future<void>.delayed(const Duration(milliseconds: 150));
    } finally {
      socket.close();
    }
    if (sent == 0) throw NetToolException('تعذّر إرسال الحزمة');
    return sent;
  }
}

// ---------------------------------------------------------------------------
// HTTP probe
// ---------------------------------------------------------------------------

class HttpProbeResult {
  HttpProbeResult({
    required this.url,
    required this.statusCode,
    required this.reasonPhrase,
    required this.headers,
    required this.redirects,
    required this.elapsedMs,
    required this.finalUrl,
    this.error,
  });

  final String url;
  final int statusCode;
  final String reasonPhrase;
  final Map<String, String> headers;
  final List<String> redirects;
  final int elapsedMs;
  final String finalUrl;
  final String? error;

  bool get ok => error == null;
}

class HttpProbeService {
  HttpProbeService._();

  static Future<HttpProbeResult> probe(String rawUrl) async {
    var text = rawUrl.trim();
    if (text.isEmpty) throw NetToolException('أدخل رابطًا');
    if (!text.contains('://')) text = 'https://$text';
    var uri = Uri.tryParse(text);
    if (uri == null || uri.host.isEmpty) {
      throw NetToolException('رابط غير صالح');
    }
    var current = uri;
    final redirects = <String>[];
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 10)
      ..userAgent = 'CobraNet/1.0 (open source network tools)';
    final sw = Stopwatch()..start();
    try {
      for (var i = 0; i <= 6; i++) {
        final request = await client.openUrl('GET', current);
        request.followRedirects = false;
        final response = await request.close();
        final headers = <String, String>{};
        response.headers.forEach((name, values) {
          headers[name] = values.join(', ');
        });
        final location = response.headers.value(HttpHeaders.locationHeader);
        if (response.isRedirect && location != null && i < 6) {
          redirects.add('${response.statusCode} → $current');
          current = current.resolve(location);
          await response.listen(null).cancel();
          continue;
        }
        final sub = response.listen((_) {});
        await sub.cancel();
        client.close(force: true);
        sw.stop();
        return HttpProbeResult(
          url: text,
          statusCode: response.statusCode,
          reasonPhrase: response.reasonPhrase,
          headers: headers,
          redirects: redirects,
          elapsedMs: sw.elapsedMilliseconds,
          finalUrl: current.toString(),
        );
      }
      client.close(force: true);
      sw.stop();
      return HttpProbeResult(
        url: text,
        statusCode: 0,
        reasonPhrase: '',
        headers: const {},
        redirects: redirects,
        elapsedMs: sw.elapsedMilliseconds,
        finalUrl: current.toString(),
        error: 'عدد تحويلات كبير جدًا',
      );
    } catch (e) {
      client.close(force: true);
      sw.stop();
      return HttpProbeResult(
        url: text,
        statusCode: 0,
        reasonPhrase: '',
        headers: const {},
        redirects: redirects,
        elapsedMs: sw.elapsedMilliseconds,
        finalUrl: current.toString(),
        error: _httpError(e),
      );
    }
  }

  static String _httpError(Object e) {
    if (e is SocketException) return 'تعذّر الاتصال بالخادم';
    if (e is HandshakeException) return 'فشل اتصال TLS';
    if (e is TimeoutException) return 'انتهت المهلة';
    return 'خطأ: $e';
  }
}

// ---------------------------------------------------------------------------
// Download speed test
// ---------------------------------------------------------------------------

class SpeedTestResult {
  SpeedTestResult({
    required this.url,
    required this.bytes,
    required this.duration,
    required this.mbps,
    this.latencyMs,
    this.cancelled = false,
    this.error,
  });
  final String url;
  final int bytes;
  final Duration duration;
  final double mbps;
  final int? latencyMs;
  final bool cancelled;
  final String? error;
  bool get ok => error == null && !cancelled;
}

class SpeedTestService {
  SpeedTestService._();

  static const defaultUrl =
      'https://speed.cloudflare.com/__down?bytes=25000000';

  static Future<SpeedTestResult> download({
    String url = defaultUrl,
    void Function(int bytes, double mbps, Duration elapsed)? onProgress,
    CancelCheck? isCancelled,
    int timeoutSeconds = 45,
  }) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 10)
      ..userAgent = 'CobraNet/1.0';
    final sw = Stopwatch()..start();
    StreamSubscription<List<int>>? subscription;
    var bytes = 0;
    var cancelled = false;
    try {
      final request = await client.getUrl(Uri.parse(url));
      final response = await request.close();
      if (response.statusCode >= 400) {
        client.close(force: true);
        return SpeedTestResult(
          url: url,
          bytes: 0,
          duration: sw.elapsed,
          mbps: 0,
          error: 'HTTP ${response.statusCode}',
        );
      }
      final completer = Completer<void>();
      var lastNotify = 0;
      subscription = response.listen(
        (chunk) {
          bytes += chunk.length;
          final elapsed = sw.elapsed;
          if (elapsed.inMilliseconds - lastNotify > 180) {
            lastNotify = elapsed.inMilliseconds;
            onProgress?.call(bytes, _mbps(bytes, elapsed), elapsed);
          }
          if (isCancelled?.call() == true) {
            cancelled = true;
            subscription?.cancel();
            if (!completer.isCompleted) completer.complete();
          }
          if (elapsed.inSeconds > timeoutSeconds) {
            cancelled = true;
            subscription?.cancel();
            if (!completer.isCompleted) completer.complete();
          }
        },
        onDone: () {
          if (!completer.isCompleted) completer.complete();
        },
        onError: (Object e) {
          if (!completer.isCompleted) completer.completeError(e);
        },
        cancelOnError: true,
      );
      await completer.future;
      sw.stop();
      client.close(force: true);
      final result = SpeedTestResult(
        url: url,
        bytes: bytes,
        duration: sw.elapsed,
        mbps: _mbps(bytes, sw.elapsed),
        cancelled: cancelled,
      );
      onProgress?.call(bytes, result.mbps, sw.elapsed);
      return result;
    } catch (e) {
      client.close(force: true);
      await subscription?.cancel();
      return SpeedTestResult(
        url: url,
        bytes: bytes,
        duration: sw.elapsed,
        mbps: _mbps(bytes, sw.elapsed),
        error: e is TimeoutException
            ? 'انتهت المهلة'
            : 'تعذّر تنزيل ملف الاختبار',
      );
    }
  }

  static double _mbps(int bytes, Duration elapsed) {
    final seconds = elapsed.inMicroseconds / 1000000;
    if (seconds <= 0) return 0;
    return (bytes * 8) / seconds / 1000000;
  }

  /// Three tiny requests to estimate round-trip latency.
  static Future<int?> latency(String url) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 6)
      ..userAgent = 'CobraNet/1.0';
    final values = <int>[];
    try {
      for (var i = 0; i < 3; i++) {
        final sw = Stopwatch()..start();
        final request = await client.getUrl(Uri.parse(url));
        final response = await request.close();
        await response.listen(null).cancel();
        sw.stop();
        values.add(sw.elapsedMilliseconds);
      }
      client.close(force: true);
      if (values.isEmpty) return null;
      values.sort();
      return values[values.length ~/ 2];
    } catch (_) {
      client.close(force: true);
      return null;
    }
  }
}
