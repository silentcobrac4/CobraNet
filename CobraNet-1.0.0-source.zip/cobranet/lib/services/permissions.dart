import 'dart:io';

import 'package:permission_handler/permission_handler.dart';

/// Wi-Fi names need a location (Android 12 and older) or nearby-devices
/// permission (Android 13+). Scanning itself only needs INTERNET, so a denial
/// degrades the label, never the tool.
class AppPermissions {
  AppPermissions._();

  static Future<bool> ensureWifiAccess() async {
    if (!Platform.isAndroid) return true;
    try {
      var location = await Permission.locationWhenInUse.status;
      var nearby = await Permission.nearbyWifiDevices.status;
      if (location.isGranted || nearby.isGranted) return true;
      if (location.isPermanentlyDenied || nearby.isPermanentlyDenied) {
        return false;
      }
      location = await Permission.locationWhenInUse.request();
      if (location.isGranted) return true;
      nearby = await Permission.nearbyWifiDevices.request();
      return nearby.isGranted;
    } catch (_) {
      return false;
    }
  }

  static Future<void> openSettings() async {
    try {
      await openAppSettings();
    } catch (_) {}
  }
}
