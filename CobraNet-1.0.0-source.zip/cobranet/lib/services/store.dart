import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/device.dart';
import '../models/history_entry.dart';
import '../models/scan_snapshot.dart';
import '../models/settings.dart';

/// All data lives on the device. There is no account, no cloud and no
/// analytics endpoint anywhere in this app.
class Store {
  Store._(this._prefs);

  final SharedPreferences _prefs;

  static const _kSettings = 'cobranet.settings.v1';
  static const _kKnown = 'cobranet.knownDevices.v1';
  static const _kHistory = 'cobranet.history.v1';
  static const _kLastScan = 'cobranet.lastScan.v1';

  static Future<Store> open() async {
    final prefs = await SharedPreferences.getInstance();
    return Store._(prefs);
  }

  Settings readSettings() {
    final raw = _prefs.getString(_kSettings);
    if (raw == null) return Settings();
    try {
      return Settings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return Settings();
    }
  }

  Future<void> writeSettings(Settings settings) =>
      _prefs.setString(_kSettings, jsonEncode(settings.toJson()));

  List<Device> readKnownDevices() {
    final raw = _prefs.getString(_kKnown);
    if (raw == null) return <Device>[];
    try {
      final list = jsonDecode(raw) as List;
      return list
          .whereType<Map>()
          .map((e) => Device.fromJson(Map<String, dynamic>.from(e)))
          .where((d) => d.ip.isNotEmpty)
          .toList();
    } catch (_) {
      return <Device>[];
    }
  }

  Future<void> writeKnownDevices(List<Device> devices) => _prefs.setString(
        _kKnown,
        jsonEncode(devices.map((d) => d.toJson(includeSeen: true)).toList()),
      );

  List<HistoryEntry> readHistory() {
    final raw = _prefs.getString(_kHistory);
    if (raw == null) return <HistoryEntry>[];
    try {
      final list = jsonDecode(raw) as List;
      return list
          .whereType<Map>()
          .map((e) => HistoryEntry.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return <HistoryEntry>[];
    }
  }

  Future<void> writeHistory(List<HistoryEntry> entries) =>
      _prefs.setString(
        _kHistory,
        jsonEncode(entries.map((e) => e.toJson()).toList()),
      );

  ScanSnapshot? readLastScan() {
    final raw = _prefs.getString(_kLastScan);
    if (raw == null) return null;
    try {
      return ScanSnapshot.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> writeLastScan(ScanSnapshot snapshot) =>
      _prefs.setString(_kLastScan, jsonEncode(snapshot.toJson()));

  Future<void> clearAll() async {
    await _prefs.remove(_kSettings);
    await _prefs.remove(_kKnown);
    await _prefs.remove(_kHistory);
    await _prefs.remove(_kLastScan);
  }

  /// Everything the backup feature exports.
  Map<String, dynamic> exportData({
    required Settings settings,
    required List<Device> knownDevices,
    required List<HistoryEntry> history,
    ScanSnapshot? lastScan,
  }) =>
      {
        'app': 'CobraNet',
        'version': 1,
        'exportedAt': DateTime.now().toIso8601String(),
        'settings': settings.toJson(),
        'knownDevices': knownDevices.map((d) => d.toJson()).toList(),
        'history': history.map((e) => e.toJson()).toList(),
        'lastScan': lastScan?.toJson(),
      };

  Future<void> importData(Map<String, dynamic> data) async {
    final settings = data['settings'];
    if (settings is Map) {
      await writeSettings(
        Settings.fromJson(Map<String, dynamic>.from(settings)),
      );
    }
    final known = data['knownDevices'];
    if (known is List) {
      final devices = known
          .whereType<Map>()
          .map((e) => Device.fromJson(Map<String, dynamic>.from(e)))
          .where((d) => d.ip.isNotEmpty)
          .toList();
      await writeKnownDevices(devices);
    }
    final history = data['history'];
    if (history is List) {
      final entries = history
          .whereType<Map>()
          .map((e) => HistoryEntry.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      await writeHistory(entries.take(200).toList());
    }
    final scan = data['lastScan'];
    if (scan is Map) {
      await writeLastScan(
        ScanSnapshot.fromJson(Map<String, dynamic>.from(scan)),
      );
    }
  }
}
