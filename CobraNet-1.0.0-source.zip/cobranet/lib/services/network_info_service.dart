import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:network_info_plus/network_info_plus.dart';

import '../core/ip_utils.dart';

/// Everything we know about the network this phone is attached to.
class NetInfo {
  const NetInfo({
    this.ssid,
    this.bssid,
    this.ip,
    this.gateway,
    this.mask,
    this.prefix = 24,
    this.connectionType = 'unknown',
    this.dnsServers = const [],
    this.interfaceName,
  });

  final String? ssid;
  final String? bssid;
  final String? ip;
  final String? gateway;
  final String? mask;
  final int prefix;
  final String connectionType;
  final List<String> dnsServers;
  final String? interfaceName;

  bool get offline => connectionType == 'none';
  bool get isWifi => connectionType == 'wifi';

  String? get cidr => ip == null ? null : '$ip/$prefix';

  String get displayNetwork {
    if (ssid != null && ssid!.trim().isNotEmpty && ssid != '<unknown ssid>') {
      return ssid!.trim();
    }
    if (offline) return 'offline';
    if (connectionType == 'mobile') return 'mobile';
    return connectionType;
  }

  int get hostCapacity {
    if (prefix >= 31) return prefix == 32 ? 1 : 2;
    return (1 << (32 - prefix)) - 2;
  }

  NetInfo copyWith({
    String? ssid,
    String? bssid,
    String? ip,
    String? gateway,
    String? mask,
    int? prefix,
    String? connectionType,
    List<String>? dnsServers,
    String? interfaceName,
    bool clearSsid = false,
    bool clearBssid = false,
  }) {
    return NetInfo(
      ssid: clearSsid ? null : (ssid ?? this.ssid),
      bssid: clearBssid ? null : (bssid ?? this.bssid),
      ip: ip ?? this.ip,
      gateway: gateway ?? this.gateway,
      mask: mask ?? this.mask,
      prefix: prefix ?? this.prefix,
      connectionType: connectionType ?? this.connectionType,
      dnsServers: dnsServers ?? this.dnsServers,
      interfaceName: interfaceName ?? this.interfaceName,
    );
  }
}

class NetworkInfoService {
  static final _info = NetworkInfo();

  /// Never throws: every plugin call is allowed to fail and we fall back to
  /// dart:io plus sane defaults.
  static Future<NetInfo> detect() async {
    String? ssid;
    String? bssid;
    String? wifiIp;
    String? gateway;
    String? mask;

    try {
      ssid = await _info.getWifiName();
      if (ssid != null) {
        ssid = ssid.replaceAll('"', '').trim();
        if (ssid.isEmpty || ssid == '<unknown ssid>' || ssid == 'null') {
          ssid = null;
        }
      }
    } catch (_) {}
    try {
      bssid = await _info.getWifiBSSID();
      if (bssid == '02:00:00:00:00:00' || bssid == '00:00:00:00:00:00') {
        bssid = null;
      }
    } catch (_) {}
    try {
      final value = await _info.getWifiIP();
      if (value != null && IpUtils.isValid(value)) wifiIp = value;
    } catch (_) {}
    try {
      final value = await _info.getWifiGatewayIP();
      if (value != null && IpUtils.isValid(value)) gateway = value;
    } catch (_) {}
    try {
      mask = await _info.getWifiSubmask();
    } catch (_) {}

    var connectionType = 'unknown';
    try {
      final list = await Connectivity().checkConnectivity();
      if (list.contains(ConnectivityResult.wifi)) {
        connectionType = 'wifi';
      } else if (list.contains(ConnectivityResult.ethernet)) {
        connectionType = 'ethernet';
      } else if (list.contains(ConnectivityResult.mobile)) {
        connectionType = 'mobile';
      } else if (list.contains(ConnectivityResult.vpn)) {
        connectionType = 'vpn';
      } else if (list.contains(ConnectivityResult.none)) {
        connectionType = 'none';
      } else if (list.isNotEmpty) {
        connectionType = list.first.name;
      }
    } catch (_) {}

    String? interfaceName;
    if (wifiIp == null || connectionType == 'unknown' || connectionType == 'ethernet') {
      try {
        final interfaces =
            await NetworkInterface.list(type: InternetAddressType.IPv4);
        // Prefer wlan*, then any private address.
        interfaces.sort((a, b) {
          final aw = a.name.startsWith('wlan') ? 0 : 1;
          final bw = b.name.startsWith('wlan') ? 0 : 1;
          return aw.compareTo(bw);
        });
        for (final iface in interfaces) {
          for (final addr in iface.addresses) {
            if (addr.isLoopback) continue;
            if (!IpUtils.isPrivate(addr.address)) continue;
            wifiIp ??= addr.address;
            interfaceName ??= iface.name;
            break;
          }
          if (wifiIp != null) break;
        }
      } catch (_) {}
    }

    int prefix = 24;
    final parsedPrefix = IpUtils.prefixFromMask(mask);
    if (parsedPrefix != null) prefix = parsedPrefix;
    if (mask == null || !IpUtils.isValid(mask)) {
      mask = IpUtils.maskFromPrefix(prefix);
    }

    if (gateway == null && wifiIp != null) {
      final value = IpUtils.toInt(wifiIp);
      if (value != null) {
        gateway = IpUtils.fromInt(
          (IpUtils.networkInt(value, prefix) + 1) & 0xFFFFFFFF,
        );
      }
    }

    final dns = <String>[];
    for (final prop in ['net.dns1', 'net.dns2', 'net.dns3']) {
      try {
        final result = await Process.run('getprop', [prop])
            .timeout(const Duration(milliseconds: 700));
        final value = (result.stdout ?? '').toString().trim();
        if (IpUtils.isValid(value) && !dns.contains(value)) dns.add(value);
      } catch (_) {}
    }

    return NetInfo(
      ssid: ssid,
      bssid: bssid,
      ip: wifiIp,
      gateway: gateway,
      mask: mask,
      prefix: prefix,
      connectionType: connectionType,
      dnsServers: dns,
      interfaceName: interfaceName,
    );
  }
}
