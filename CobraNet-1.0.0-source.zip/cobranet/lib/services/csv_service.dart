import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/device.dart';

class CsvService {
  CsvService._();

  static String _escape(String value) {
    if (value.contains(',') || value.contains('"') || value.contains('\n')) {
      return '"${value.replaceAll('"', '""')}"';
    }
    return value;
  }

  static String devicesToCsv(List<Device> devices) {
    final buffer = StringBuffer();
    buffer.writeln([
      'ip',
      'mac',
      'hostname',
      'customName',
      'type',
      'online',
      'favorite',
      'saved',
      'latencyMs',
      'openPorts',
      'notes',
      'lastSeen',
    ].join(','));
    for (final d in devices) {
      buffer.writeln([
        _escape(d.ip),
        _escape(d.mac ?? ''),
        _escape(d.hostname ?? ''),
        _escape(d.customName ?? ''),
        _escape(d.type.name),
        d.online ? '1' : '0',
        d.favorite ? '1' : '0',
        d.saved ? '1' : '0',
        d.latencyMs?.toString() ?? '',
        _escape(d.openPorts.join(';')),
        _escape(d.notes ?? ''),
        d.lastSeen.toIso8601String(),
      ].join(','));
    }
    return buffer.toString();
  }

  static Future<File> writeDevices(List<Device> devices) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/cobranet-devices.csv');
    await file.writeAsString(devicesToCsv(devices), encoding: utf8);
    return file;
  }

  static Future<void> shareDevices(List<Device> devices) async {
    final file = await writeDevices(devices);
    await SharePlus.instance.share(
      ShareParams(files: [XFile(file.path)], subject: 'CobraNet devices'),
    );
  }
}
