import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Backup is a plain JSON file so the user can move it anywhere, read it, and
/// keep using it even if this app disappears. No cloud, no proprietary format.
class BackupService {
  BackupService._();

  static Future<File> writeExport(Map<String, dynamic> data) async {
    final dir = await getTemporaryDirectory();
    final stamp = DateTime.now()
        .toIso8601String()
        .replaceAll(RegExp(r'[:.]'), '-')
        .substring(0, 19);
    final file = File('${dir.path}/cobranet-backup-$stamp.json');
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(data),
    );
    return file;
  }

  static Future<void> shareExport(File file, {String? text}) async {
    await SharePlus.instance.share(
      ShareParams(
        files: [XFile(file.path, mimeType: 'application/json')],
        subject: 'CobraNet backup',
        text: text,
      ),
    );
  }

  static Future<Map<String, dynamic>?> pickImport() async {
    final picked = await FilePicker.pickFile(
      type: FileType.custom,
      allowedExtensions: ['json'],
      dialogTitle: 'CobraNet backup',
    );
    if (picked == null) return null;
    final bytes = await picked.readAsBytes();
    final decoded = jsonDecode(utf8.decode(bytes));
    if (decoded is Map<String, dynamic>) return decoded;
    if (decoded is Map) return Map<String, dynamic>.from(decoded);
    throw const FormatException('invalid backup');
  }
}
