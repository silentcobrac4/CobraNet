import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// Offline lookup of a device's manufacturer from the first 3 bytes of its MAC
/// address (the OUI prefix). Data is shipped as `assets/oui.json`.
class OuiService {
  OuiService._();

  static Map<String, String>? _map;

  static Future<void> ensureLoaded() async {
    if (_map != null) return;
    try {
      final raw = await rootBundle.loadString('assets/oui.json');
      final decoded = jsonDecode(raw);
      if (decoded is Map) {
        _map = decoded.map(
          (key, value) => MapEntry(key.toString().toUpperCase(), value.toString()),
        );
      } else {
        _map = <String, String>{};
      }
    } catch (_) {
      _map = <String, String>{};
    }
  }

  /// Returns the vendor name for [mac], or null when unknown.
  static Future<String?> lookup(String? mac) async {
    await ensureLoaded();
    final prefix = _prefix(mac);
    if (prefix == null) return null;
    return _map?[prefix];
  }

  /// Synchronous variant, returns null if the data has not been loaded yet.
  static String? lookupSync(String? mac) {
    final prefix = _prefix(mac);
    if (prefix == null || _map == null) return null;
    return _map![prefix];
  }

  static String? _prefix(String? mac) {
    if (mac == null) return null;
    final cleaned = mac.replaceAll(RegExp(r'[^0-9A-Fa-f]'), '').toUpperCase();
    if (cleaned.length < 6) return null;
    return cleaned.substring(0, 6);
  }
}
