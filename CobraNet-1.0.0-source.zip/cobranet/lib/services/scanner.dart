import 'dart:async';
import 'dart:io';

import '../core/ip_utils.dart';
import '../models/device.dart';
import '../models/settings.dart';
import 'dns_client.dart';
import 'net_tools.dart';
import 'network_info_service.dart';

class ScanException implements Exception {
  ScanException(this.message);
  final String message;
  @override
  String toString() => message;
}

class ScanProgress {
  const ScanProgress({
    required this.phase,
    required this.done,
    required this.total,
    required this.found,
  });
  final String phase;
  final int done;
  final int total;
  final int found;

  double get fraction => total == 0 ? 0 : (done / total).clamp(0, 1);
}

class Scanner {
  Scanner._();

  /// Ports that say something about the kind of device (and give the user a
  /// useful head start). Kept small so a sweep stays fast on a phone.
  static const signaturePorts = <int>[
    22, 53, 80, 139, 443, 445, 554, 631, 1883, 3389, 8008, 8009, 9100, 62078,
  ];

  static Future<List<Device>> scan({
    NetInfo? info,
    required Settings settings,
    required List<Device> known,
    List<String>? hosts,
    void Function(ScanProgress progress)? onProgress,
    CancelCheck? isCancelled,
  }) async {
    final localIp = info?.ip;
    final hasLocal = localIp != null && IpUtils.isValid(localIp);

    final List<String> allHosts;
    if (hosts != null && hosts.isNotEmpty) {
      allHosts = hosts.where((h) => h != localIp).toList();
    } else if (hasLocal) {
      allHosts = IpUtils.hosts(localIp, info?.prefix ?? 24, cap: 1022)
          .where((h) => h != localIp)
          .toList();
    } else {
      allHosts = const [];
    }
    if (allHosts.isEmpty) throw ScanException('no-network');

    final probes = <String, _Probe>{};
    final concurrency = settings.scanConcurrency.clamp(1, 96);
    var index = 0;
    var done = 0;

    Future<void> pingWorker() async {
      while (true) {
        if (isCancelled?.call() == true) return;
        final i = index++;
        if (i >= allHosts.length) return;
        final ip = allHosts[i];
        probes[ip] = await _probe(ip, settings.scanTimeoutMs);
        done++;
        onProgress?.call(ScanProgress(
          phase: 'ping',
          done: done,
          total: allHosts.length,
          found: probes.values.where((p) => p.alive).length,
        ));
      }
    }

    await Future.wait(List.generate(concurrency, (_) => pingWorker()));

    if (isCancelled?.call() == true) return const [];

    final arp = await ArpTable.read();
    final devices = <String, Device>{};

    for (final ip in allHosts) {
      final probe = probes[ip];
      final mac = arp[ip];
      final alive = (probe?.alive ?? false) || mac != null;
      if (!alive) continue;
      final hostname = _cleanHostname(probe?.hostname, ip);
      final device = Device(
        ip: ip,
        mac: mac,
        hostname: hostname,
        online: true,
        latencyMs: probe?.ms,
        openPorts: const [],
        type: Device.inferType(
          ip: ip,
          hostname: hostname,
          gateway: info?.gateway,
          localIp: localIp,
        ),
      );
      devices[device.identity] = device;
    }

    // Read names for hosts that did not answer with one.
    if (settings.resolveNames && settings.deepScan && devices.isNotEmpty) {
      final servers = <String>[
        if (info?.gateway != null) info!.gateway!,
        ...(info?.dnsServers ?? const <String>[]),
        '1.1.1.1',
      ];
      final pending = devices.values
          .where((d) => d.hostname == null)
          .map((d) => d.identity)
          .toList();
      var nameDone = 0;
      var cursor = 0;
      Future<void> nameWorker() async {
        while (true) {
          if (isCancelled?.call() == true) return;
          final i = cursor++;
          if (i >= pending.length) return;
          final key = pending[i];
          final device = devices[key];
          if (device != null) {
            final result = await DnsClient.lookup(
              name: DnsClient.reverseName(device.ip),
              type: 'PTR',
              servers: servers,
              timeoutMs: 700,
            );
            if (result.records.isNotEmpty) {
              final name = _cleanHostname(result.records.first.value, device.ip);
              if (name != null) {
                devices[key] = device.copyWith(hostname: name);
              }
            }
          }
          nameDone++;
          onProgress?.call(ScanProgress(
            phase: 'names',
            done: nameDone,
            total: pending.length,
            found: devices.length,
          ));
        }
      }

      await Future.wait(List.generate(minInt(12, pending.length), (_) => nameWorker()));
    }

    if (settings.deepScan && devices.isNotEmpty && isCancelled?.call() != true) {
      final list = devices.values.toList();
      var portDone = 0;
      var portIndex = 0;
      Future<void> portWorker() async {
        while (true) {
          if (isCancelled?.call() == true) return;
          final i = portIndex++;
          if (i >= list.length) return;
          final device = list[i];
          final open = await _openPorts(device.ip, signaturePorts, 260);
          final type = Device.inferType(
            ip: device.ip,
            hostname: device.hostname,
            ports: open,
            gateway: info?.gateway,
            localIp: localIp,
          );
          devices[device.identity] = device.copyWith(
            openPorts: open,
            type: type,
          );
          portDone++;
          onProgress?.call(ScanProgress(
            phase: 'ports',
            done: portDone,
            total: list.length,
            found: devices.length,
          ));
        }
      }

      await Future.wait(List.generate(minInt(24, list.length), (_) => portWorker()));
    }

    if (hasLocal) {
      final selfMac = arp[localIp];
      final self = Device(
        ip: localIp,
        mac: selfMac,
        hostname: Platform.localHostname,
        type: DeviceType.thisDevice,
        latencyMs: 0,
        online: true,
      );
      devices[self.identity] = self;
    }

    final merged = <Device>[];
    for (final device in devices.values) {
      merged.add(_mergeKnown(device, known));
    }

    merged.sort((a, b) {
      final ai = IpUtils.toInt(a.ip) ?? 0;
      final bi = IpUtils.toInt(b.ip) ?? 0;
      return ai.compareTo(bi);
    });
    return merged;
  }

  static int minInt(int a, int b) => a < b ? a : b;

  static String? _cleanHostname(String? raw, String ip) {
    if (raw == null) return null;
    var name = raw.trim();
    if (name.endsWith('.')) name = name.substring(0, name.length - 1);
    if (name.isEmpty) return null;
    if (name == ip) return null;
    if (name.contains('.in-addr.arpa')) return null;
    if (name == 'localhost') return null;
    if (RegExp(r'^[0-9.]+$').hasMatch(name)) return null;
    return name;
  }

  static Device _mergeKnown(Device device, List<Device> known) {
    Device? match;
    final mac = device.mac;
    if (mac != null) {
      final normalized = MacUtils.normalize(mac);
      for (final item in known) {
        if (item.mac != null &&
            MacUtils.normalize(item.mac!) == normalized) {
          match = item;
          break;
        }
      }
    }
    if (match == null) {
      for (final item in known) {
        if (item.ip == device.ip) {
          match = item;
          break;
        }
      }
    }
    if (match == null) return device;
    return device.copyWith(
      customName: match.customName,
      notes: match.notes,
      favorite: match.favorite,
      firstSeen: match.firstSeen,
    );
  }

  static Future<_Probe> _probe(String ip, int timeoutMs) async {
    final waitSeconds = ((timeoutMs + 999) ~/ 1000).clamp(1, 5);
    try {
      final result = await Process.run('ping', [
        '-c',
        '1',
        '-W',
        '$waitSeconds',
        ip,
      ]).timeout(Duration(milliseconds: timeoutMs + 1800));
      final output = '${result.stdout}\n${result.stderr}';
      final timeMatch = RegExp(r'time[=<]\s*([0-9.]+)\s*ms').firstMatch(output);
      final hostMatch =
          RegExp(r'^PING\s+(\S+)\s+\(([^)]+)\)', multiLine: true)
              .firstMatch(output);
      var hostname = hostMatch?.group(1);
      if (hostname == null || hostname == ip || hostname == ip) {
        hostname = null;
      }
      final alive = result.exitCode == 0 || timeMatch != null;
      return _Probe(
        alive: alive,
        ms: timeMatch == null ? null : double.parse(timeMatch.group(1)!).round(),
        hostname: hostname,
      );
    } catch (_) {
      return const _Probe(alive: false);
    }
  }

  static Future<List<int>> _openPorts(
    String host,
    List<int> ports,
    int timeoutMs,
  ) async {
    final open = <int>[];
    await Future.wait(ports.map((port) async {
      try {
        final socket = await Socket.connect(
          host,
          port,
          timeout: Duration(milliseconds: timeoutMs),
        );
        open.add(port);
        socket.destroy();
      } catch (_) {}
    }));
    open.sort();
    return open;
  }
}

class _Probe {
  const _Probe({this.alive = false, this.ms, this.hostname});
  final bool alive;
  final int? ms;
  final String? hostname;
}

/// Reads the kernel's ARP cache. Some Android builds hide `/proc/net/arp`;
/// in that case we fall back to `ip neigh` and simply show no MAC addresses.
class ArpTable {
  ArpTable._();

  static Future<Map<String, String>> read() async {
    final table = <String, String>{};
    try {
      final file = File('/proc/net/arp');
      if (await file.exists()) {
        final lines = await file.readAsLines();
        for (final line in lines.skip(1)) {
          final fields = line.trim().split(RegExp(r'\s+'));
          if (fields.length < 4) continue;
          final ip = fields[0];
          final flags = fields[2].toLowerCase();
          final mac = fields[3];
          if (!IpUtils.isValid(ip)) continue;
          if (!MacUtils.isValid(mac)) continue;
          if (mac == '00:00:00:00:00:00') continue;
          if (flags == '0x0') continue;
          table[ip] = MacUtils.normalize(mac);
        }
      }
    } catch (_) {}

    if (table.isEmpty) {
      try {
        final result = await Process.run('ip', ['neigh'])
            .timeout(const Duration(seconds: 2));
        final text = '${result.stdout}\n${result.stderr}';
        final regex = RegExp(
          r'^([0-9.]+)\s+.*lladdr\s+([0-9a-fA-F:]{17}).*(REACHABLE|STALE|DELAY|PROBE|PERMANENT)',
          multiLine: true,
        );
        for (final match in regex.allMatches(text)) {
          final ip = match.group(1)!;
          final mac = match.group(2)!;
          if (IpUtils.isValid(ip) && MacUtils.isValid(mac)) {
            table[ip] = MacUtils.normalize(mac);
          }
        }
      } catch (_) {}
    }
    return table;
  }
}
