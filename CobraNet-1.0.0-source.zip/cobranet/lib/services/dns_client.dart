import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

/// A tiny DNS client (A, AAAA, CNAME, MX, TXT, NS, PTR, SOA) written against
/// the wire protocol so the app does not depend on a third-party resolver
/// library. Works against the gateway resolver or any public resolver.
class DnsRecord {
  const DnsRecord({required this.type, required this.value, this.ttl = 0});
  final String type;
  final String value;
  final int ttl;

  String get line => '$type\t$value';
}

class DnsResult {
  const DnsResult({
    required this.query,
    required this.type,
    required this.server,
    required this.ms,
    required this.records,
    this.status = 0,
    this.error,
  });

  final String query;
  final String type;
  final String server;
  final int ms;
  final List<DnsRecord> records;
  final int status;
  final String? error;

  bool get ok => error == null;

  String get statusText {
    switch (status) {
      case 0:
        return 'NOERROR';
      case 1:
        return 'FORMERR';
      case 2:
        return 'SERVFAIL';
      case 3:
        return 'NXDOMAIN';
      case 4:
        return 'NOTIMP';
      case 5:
        return 'REFUSED';
      default:
        return 'RCODE $status';
    }
  }

  String get summary {
    if (error != null) return error!;
    if (records.isEmpty) return '$statusText · لا سجلات';
    return '${records.length} ${records.length == 1 ? 'record' : 'records'} · ${ms}ms';
  }
}

class DnsClient {
  DnsClient._();

  static const types = <String, int>{
    'A': 1,
    'NS': 2,
    'CNAME': 5,
    'SOA': 6,
    'PTR': 12,
    'MX': 15,
    'TXT': 16,
    'AAAA': 28,
    'SRV': 33,
  };

  static const _typeNames = <int, String>{
    1: 'A',
    2: 'NS',
    5: 'CNAME',
    6: 'SOA',
    12: 'PTR',
    15: 'MX',
    16: 'TXT',
    28: 'AAAA',
    33: 'SRV',
  };

  static String reverseName(String ip) {
    final parts = ip.trim().split('.');
    if (parts.length != 4) return ip;
    return '${parts.reversed.join('.')}.in-addr.arpa';
  }

  /// Resolves [name]. [servers] is tried in order; when empty the caller's
  /// list (gateway + public resolvers) is used.
  static Future<DnsResult> lookup({
    required String name,
    String type = 'A',
    List<String> servers = const [],
    int timeoutMs = 2500,
  }) async {
    final typeId = types[type.toUpperCase()];
    if (typeId == null) {
      return DnsResult(
        query: name,
        type: type,
        server: '',
        ms: 0,
        records: const [],
        error: 'نوع سجل غير مدعوم',
      );
    }
    final query = name.trim().replaceAll(RegExp(r'^\.+|\.+$'), '');
    if (query.isEmpty) {
      return DnsResult(
        query: name,
        type: type,
        server: '',
        ms: 0,
        records: const [],
        error: 'اسم فارغ',
      );
    }

    final attemptServers = servers.isEmpty
        ? const ['1.1.1.1', '8.8.8.8', '9.9.9.9']
        : servers;

    DnsResult? last;
    for (final server in attemptServers) {
      if (!_isIp(server)) continue;
      final started = DateTime.now();
      try {
        var response = await _queryUdp(
          server: server,
          name: query,
          type: typeId,
          timeoutMs: timeoutMs,
        );
        if (response.truncated) {
          response = await _queryTcp(
            server: server,
            name: query,
            type: typeId,
            timeoutMs: timeoutMs + 1000,
          );
        }
        final elapsed = DateTime.now().difference(started).inMilliseconds;
        final parsed = _parse(response.bytes, response.id);
        return DnsResult(
          query: query,
          type: type.toUpperCase(),
          server: server,
          ms: elapsed,
          records: parsed.records,
          status: parsed.status,
          error: parsed.records.isEmpty && parsed.status != 0
              ? 'فشل الاستعلام (${parsed.status})'
              : null,
        );
      } catch (e) {
        last = DnsResult(
          query: query,
          type: type.toUpperCase(),
          server: server,
          ms: DateTime.now().difference(started).inMilliseconds,
          records: const [],
          error: _friendlyError(e),
        );
      }
    }
    return last ??
        DnsResult(
          query: query,
          type: type.toUpperCase(),
          server: '',
          ms: 0,
          records: const [],
          error: 'لا يوجد خادم DNS متاح',
        );
  }

  static String _friendlyError(Object error) {
    if (error is TimeoutException) return 'انتهت مهلة خادم DNS';
    if (error is SocketException) return 'تعذّر الوصول إلى خادم DNS';
    return 'خطأ: $error';
  }

  static bool _isIp(String value) {
    final parts = value.split('.');
    if (parts.length != 4) return false;
    for (final p in parts) {
      final n = int.tryParse(p);
      if (n == null || n < 0 || n > 255) return false;
    }
    return true;
  }

  static Future<_DnsResponse> _queryUdp({
    required String server,
    required String name,
    required int type,
    required int timeoutMs,
  }) async {
    final id = Random().nextInt(0xFFFF);
    final packet = _buildQuery(id, name, type);

    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    final completer = Completer<_DnsResponse>();
    Timer? timer;

    void finish(_DnsResponse? value, Object? error) {
      if (completer.isCompleted) return;
      timer?.cancel();
      try {
        socket.close();
      } catch (_) {}
      if (error != null) {
        completer.completeError(error);
      } else if (value != null) {
        completer.complete(value);
      } else {
        completer.completeError(TimeoutException('dns timeout'));
      }
    }

    socket.listen(
      (event) {
        if (event != RawSocketEvent.read) return;
        final datagram = socket.receive();
        if (datagram == null) return;
        final data = datagram.data;
        if (data.length < 12) return;
        final responseId = (data[0] << 8) | data[1];
        if (responseId != id) return;
        final flags = (data[2] << 8) | data[3];
        finish(
          _DnsResponse(
            id: id,
            bytes: data,
            truncated: (flags & 0x0200) != 0,
          ),
          null,
        );
      },
      onError: (Object e) => finish(null, e),
    );

    timer = Timer(Duration(milliseconds: timeoutMs), () => finish(null, null));
    socket.send(packet, InternetAddress(server), 53);
    return completer.future;
  }

  static Future<_DnsResponse> _queryTcp({
    required String server,
    required String name,
    required int type,
    required int timeoutMs,
  }) async {
    final id = Random().nextInt(0xFFFF);
    final packet = _buildQuery(id, name, type);
    final socket = await Socket.connect(
      server,
      53,
      timeout: Duration(milliseconds: timeoutMs),
    );
    try {
      final buffer = BytesBuilder();
      buffer.add([(packet.length >> 8) & 0xFF, packet.length & 0xFF]);
      buffer.add(packet);
      socket.add(buffer.takeBytes());
      await socket.flush();
      final response = await socket
          .timeout(Duration(milliseconds: timeoutMs))
          .fold<BytesBuilder>(BytesBuilder(), (b, chunk) {
            b.add(chunk);
            return b;
          });
      final bytes = response.takeBytes();
      if (bytes.length < 14) throw const FormatException('short dns response');
      final length = (bytes[0] << 8) | bytes[1];
      final data = bytes.sublist(2, min(2 + length, bytes.length));
      final flags = (data[2] << 8) | data[3];
      return _DnsResponse(
        id: id,
        bytes: data,
        truncated: (flags & 0x0200) != 0,
      );
    } finally {
      socket.destroy();
    }
  }

  static Uint8List _buildQuery(int id, String name, int type) {
    final builder = BytesBuilder();
    builder.add([(id >> 8) & 0xFF, id & 0xFF]);
    builder.add([0x01, 0x00]); // RD
    builder.add([0x00, 0x01]); // QDCOUNT
    builder.add([0x00, 0x00]); // ANCOUNT
    builder.add([0x00, 0x00]); // NSCOUNT
    builder.add([0x00, 0x00]); // ARCOUNT
    for (final label in name.split('.')) {
      final bytes = Uint8List.fromList(label.codeUnits);
      builder.add([bytes.length & 0xFF]);
      builder.add(bytes);
    }
    builder.add([0x00]);
    builder.add([(type >> 8) & 0xFF, type & 0xFF]);
    builder.add([0x00, 0x01]); // IN
    return builder.takeBytes();
  }

  static _ParsedDns _parse(Uint8List data, int id) {
    final records = <DnsRecord>[];
    if (data.length < 12) return const _ParsedDns(records: [], status: 2);
    final status = data[3] & 0x0F;
    final qdCount = (data[4] << 8) | data[5];
    final anCount = (data[6] << 8) | data[7];
    var offset = 12;

    for (var i = 0; i < qdCount; i++) {
      final name = _readName(data, offset);
      offset = name.next;
      if (offset + 4 > data.length) break;
      offset += 4;
    }

    for (var i = 0; i < anCount; i++) {
      if (offset >= data.length) break;
      final name = _readName(data, offset);
      offset = name.next;
      if (offset + 10 > data.length) break;
      final type = (data[offset] << 8) | data[offset + 1];
      final ttl = (data[offset + 4] << 24) |
          (data[offset + 5] << 16) |
          (data[offset + 6] << 8) |
          data[offset + 7];
      final rdLength = (data[offset + 8] << 8) | data[offset + 9];
      offset += 10;
      final rdStart = offset;
      final rdEnd = min(offset + rdLength, data.length);
      if (rdStart > data.length) break;

      String? value;
      switch (type) {
        case 1: // A
          if (rdLength == 4) {
            value = '${data[rdStart]}.${data[rdStart + 1]}.'
                '${data[rdStart + 2]}.${data[rdStart + 3]}';
          }
          break;
        case 28: // AAAA
          if (rdLength == 16) {
            final parts = <String>[];
            for (var j = 0; j < 16; j += 2) {
              parts.add(((data[rdStart + j] << 8) | data[rdStart + j + 1])
                  .toRadixString(16));
            }
            value = parts.join(':');
          }
          break;
        case 2: // NS
        case 5: // CNAME
        case 12: // PTR
          value = _readName(data, rdStart).name;
          break;
        case 15: // MX
          if (rdLength >= 2) {
            final preference = (data[rdStart] << 8) | data[rdStart + 1];
            final exchange = _readName(data, rdStart + 2).name;
            value = '$preference $exchange';
          }
          break;
        case 16: // TXT
          final chunks = <String>[];
          var pos = rdStart;
          while (pos < rdEnd) {
            final len = data[pos];
            pos++;
            if (pos + len > rdEnd) break;
            chunks.add(String.fromCharCodes(data.sublist(pos, pos + len)));
            pos += len;
          }
          value = chunks.join('');
          break;
        case 6: // SOA
          final mname = _readName(data, rdStart);
          final rname = _readName(data, mname.next);
          var pos = rname.next;
          final numbers = <String>[];
          for (var j = 0; j < 5 && pos + 4 <= data.length; j++) {
            numbers.add('${(data[pos] << 24) | (data[pos + 1] << 16) | (data[pos + 2] << 8) | data[pos + 3]}');
            pos += 4;
          }
          value = '${mname.name} ${rname.name} ${numbers.join(' ')}';
          break;
        case 33: // SRV
          if (rdLength >= 6) {
            final priority = (data[rdStart] << 8) | data[rdStart + 1];
            final weight = (data[rdStart + 2] << 8) | data[rdStart + 3];
            final port = (data[rdStart + 4] << 8) | data[rdStart + 5];
            final target = _readName(data, rdStart + 6).name;
            value = '$priority $weight $port $target';
          }
          break;
      }

      if (value != null) {
        records.add(DnsRecord(
          type: _typeNames[type] ?? 'TYPE$type',
          value: value,
          ttl: ttl,
        ));
      }
      offset = rdEnd + 0;
    }

    return _ParsedDns(records: records, status: status);
  }

  static _NameResult _readName(Uint8List data, int offset) {
    final labels = <String>[];
    var pos = offset;
    var jumped = false;
    var next = offset;
    var guard = 0;
    while (pos < data.length && guard < 64) {
      guard++;
      final len = data[pos];
      if (len == 0) {
        pos++;
        if (!jumped) next = pos;
        break;
      }
      if ((len & 0xC0) == 0xC0) {
        if (pos + 1 >= data.length) break;
        final pointer = ((len & 0x3F) << 8) | data[pos + 1];
        if (!jumped) next = pos + 2;
        jumped = true;
        pos = pointer;
        continue;
      }
      pos++;
      if (pos + len > data.length) break;
      labels.add(String.fromCharCodes(data.sublist(pos, pos + len)));
      pos += len;
      if (!jumped) next = pos;
    }
    return _NameResult(labels.join('.'), next);
  }
}

class _DnsResponse {
  const _DnsResponse({
    required this.id,
    required this.bytes,
    this.truncated = false,
  });
  final int id;
  final Uint8List bytes;
  final bool truncated;
}

class _ParsedDns {
  const _ParsedDns({required this.records, required this.status});
  final List<DnsRecord> records;
  final int status;
}

class _NameResult {
  const _NameResult(this.name, this.next);
  final String name;
  final int next;
}
