import '../core/ip_utils.dart';

enum DeviceType {
  router,
  thisDevice,
  phone,
  computer,
  printer,
  camera,
  tv,
  nas,
  iot,
  console,
  unknown,
}

/// One host on the local network.
class Device {
  Device({
    required this.ip,
    this.mac,
    this.hostname,
    this.customName,
    this.notes,
    this.favorite = false,
    this.online = true,
    this.latencyMs,
    List<int>? openPorts,
    this.type = DeviceType.unknown,
    DateTime? firstSeen,
    DateTime? lastSeen,
    this.saved = false,
  })  : openPorts = openPorts ?? <int>[],
        firstSeen = firstSeen ?? DateTime.now(),
        lastSeen = lastSeen ?? DateTime.now();

  final String ip;
  String? mac;
  String? hostname;
  String? customName;
  String? notes;
  bool favorite;
  bool online;
  int? latencyMs;
  List<int> openPorts;
  DeviceType type;
  DateTime firstSeen;
  DateTime lastSeen;

  /// True when this row came from the user's saved-device list.
  bool saved;

  String get identity {
    final m = mac;
    if (m != null && m.isNotEmpty) return 'mac:${MacUtils.normalize(m)}';
    return 'ip:$ip';
  }

  String get displayName {
    if (customName != null && customName!.trim().isNotEmpty) {
      return customName!.trim();
    }
    if (hostname != null && hostname!.trim().isNotEmpty && hostname != ip) {
      return hostname!.trim();
    }
    return ip;
  }

  bool get hasOpenPorts => openPorts.isNotEmpty;

  Device copyWith({
    String? ip,
    String? mac,
    String? hostname,
    String? customName,
    String? notes,
    bool? favorite,
    bool? online,
    int? latencyMs,
    List<int>? openPorts,
    DeviceType? type,
    DateTime? firstSeen,
    DateTime? lastSeen,
    bool? saved,
    bool clearMac = false,
    bool clearHostname = false,
    bool clearCustomName = false,
    bool clearNotes = false,
    bool clearLatency = false,
  }) {
    return Device(
      ip: ip ?? this.ip,
      mac: clearMac ? null : (mac ?? this.mac),
      hostname: clearHostname ? null : (hostname ?? this.hostname),
      customName: clearCustomName ? null : (customName ?? this.customName),
      notes: clearNotes ? null : (notes ?? this.notes),
      favorite: favorite ?? this.favorite,
      online: online ?? this.online,
      latencyMs: clearLatency ? null : (latencyMs ?? this.latencyMs),
      openPorts: openPorts ?? this.openPorts,
      type: type ?? this.type,
      firstSeen: firstSeen ?? this.firstSeen,
      lastSeen: lastSeen ?? this.lastSeen,
      saved: saved ?? this.saved,
    );
  }

  Map<String, dynamic> toJson({bool includeSeen = true}) => {
        'ip': ip,
        if (mac != null) 'mac': mac,
        if (hostname != null) 'hostname': hostname,
        if (customName != null) 'customName': customName,
        if (notes != null) 'notes': notes,
        'favorite': favorite,
        'online': online,
        if (latencyMs != null) 'latencyMs': latencyMs,
        if (openPorts.isNotEmpty) 'openPorts': openPorts,
        'type': type.name,
        if (includeSeen) 'firstSeen': firstSeen.toIso8601String(),
        if (includeSeen) 'lastSeen': lastSeen.toIso8601String(),
        'saved': saved,
      };

  factory Device.fromJson(Map<String, dynamic> json) {
    return Device(
      ip: (json['ip'] ?? '').toString(),
      mac: json['mac']?.toString(),
      hostname: json['hostname']?.toString(),
      customName: json['customName']?.toString(),
      notes: json['notes']?.toString(),
      favorite: json['favorite'] == true,
      online: json['online'] != false,
      latencyMs: (json['latencyMs'] as num?)?.toInt(),
      openPorts: (json['openPorts'] as List?)
              ?.map((e) => (e as num).toInt())
              .toList() ??
          <int>[],
      type: DeviceType.values.firstWhere(
        (t) => t.name == json['type'],
        orElse: () => DeviceType.unknown,
      ),
      firstSeen: _date(json['firstSeen']),
      lastSeen: _date(json['lastSeen']),
      saved: json['saved'] == true,
    );
  }

  static DateTime _date(Object? value) {
    if (value is String) return DateTime.tryParse(value) ?? DateTime.now();
    return DateTime.now();
  }

  /// A rough device type from ports and names. Deliberately heuristic: we do
  /// not ship an OUI vendor database, and guessing a vendor from a MAC prefix
  /// is worse than saying "unknown".
  static DeviceType inferType({
    required String ip,
    String? hostname,
    List<int> ports = const [],
    String? gateway,
    String? localIp,
  }) {
    if (localIp != null && ip == localIp) return DeviceType.thisDevice;
    final name = (hostname ?? '').toLowerCase();
    if (gateway != null && ip == gateway) return DeviceType.router;

    if (name.contains('router') ||
        name.contains('gateway') ||
        name.contains('repeater') ||
        name.contains('mesh') ||
        name.contains('fritz') ||
        name.contains('openwrt')) {
      return DeviceType.router;
    }
    if (name.contains('iphone') ||
        name.contains('ipad') ||
        name.contains('android') ||
        name.contains('redmi') ||
        name.contains('oneplus') ||
        name.contains('pixel') ||
        name.contains('galaxy')) {
      return DeviceType.phone;
    }
    if (name.contains('printer') ||
        name.contains('hp-') ||
        name.contains('epson') ||
        name.contains('brother') ||
        name.contains('canon')) {
      return DeviceType.printer;
    }
    if (name.contains('cam') || name.contains('ipc') || name.contains('nvr')) {
      return DeviceType.camera;
    }
    if (name.contains('tv') ||
        name.contains('roku') ||
        name.contains('chromecast') ||
        name.contains('firestick') ||
        name.contains('appletv') ||
        name.contains('bravia')) {
      return DeviceType.tv;
    }
    if (name.contains('nas') ||
        name.contains('synology') ||
        name.contains('qnap') ||
        name.contains('diskstation')) {
      return DeviceType.nas;
    }
    if (name.contains('playstation') ||
        name.contains('xbox') ||
        name.contains('nintendo')) {
      return DeviceType.console;
    }
    if (name.contains('esp') ||
        name.contains('tuya') ||
        name.contains('shelly') ||
        name.contains('tasmota') ||
        name.contains('sonoff')) {
      return DeviceType.iot;
    }
    if (name.contains('macbook') ||
        name.contains('laptop') ||
        name.contains('desktop') ||
        name.contains('pc-') ||
        name.contains('thinkpad')) {
      return DeviceType.computer;
    }

    if (ports.contains(9100) || ports.contains(631)) return DeviceType.printer;
    if (ports.contains(554)) return DeviceType.camera;
    if (ports.contains(62078)) return DeviceType.phone;
    if (ports.contains(8008) || ports.contains(8009)) return DeviceType.tv;
    if (ports.contains(1883) || ports.contains(8883)) return DeviceType.iot;
    if (ports.contains(445) || ports.contains(139)) {
      return ports.contains(3389) || ports.contains(22)
          ? DeviceType.computer
          : DeviceType.nas;
    }
    if (ports.contains(3389) || ports.contains(22)) return DeviceType.computer;
    if (ports.contains(53) && ports.contains(80)) return DeviceType.router;
    return DeviceType.unknown;
  }
}
