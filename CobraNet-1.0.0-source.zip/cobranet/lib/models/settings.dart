import 'package:material_ui/material_ui.dart';

class Settings {
  Settings({
    this.theme = ThemeMode.system,
    this.locale,
    this.pingCount = 4,
    this.pingTimeoutMs = 2000,
    this.scanTimeoutMs = 1200,
    this.scanConcurrency = 48,
    this.deepScan = true,
    this.resolveNames = true,
    this.showOffline = true,
    this.portTimeoutMs = 350,
  });

  final ThemeMode theme;

  /// null follows the device language.
  final String? locale;
  final int pingCount;
  final int pingTimeoutMs;
  final int scanTimeoutMs;
  final int scanConcurrency;
  final bool deepScan;
  final bool resolveNames;
  final bool showOffline;
  final int portTimeoutMs;

  Settings copyWith({
    ThemeMode? theme,
    String? locale,
    bool clearLocale = false,
    int? pingCount,
    int? pingTimeoutMs,
    int? scanTimeoutMs,
    int? scanConcurrency,
    bool? deepScan,
    bool? resolveNames,
    bool? showOffline,
    int? portTimeoutMs,
  }) {
    return Settings(
      theme: theme ?? this.theme,
      locale: clearLocale ? null : (locale ?? this.locale),
      pingCount: pingCount ?? this.pingCount,
      pingTimeoutMs: pingTimeoutMs ?? this.pingTimeoutMs,
      scanTimeoutMs: scanTimeoutMs ?? this.scanTimeoutMs,
      scanConcurrency: scanConcurrency ?? this.scanConcurrency,
      deepScan: deepScan ?? this.deepScan,
      resolveNames: resolveNames ?? this.resolveNames,
      showOffline: showOffline ?? this.showOffline,
      portTimeoutMs: portTimeoutMs ?? this.portTimeoutMs,
    );
  }

  Map<String, dynamic> toJson() => {
        'theme': theme.name,
        'locale': locale,
        'pingCount': pingCount,
        'pingTimeoutMs': pingTimeoutMs,
        'scanTimeoutMs': scanTimeoutMs,
        'scanConcurrency': scanConcurrency,
        'deepScan': deepScan,
        'resolveNames': resolveNames,
        'showOffline': showOffline,
        'portTimeoutMs': portTimeoutMs,
      };

  factory Settings.fromJson(Map<String, dynamic> json) {
    final themeName = json['theme']?.toString();
    return Settings(
      theme: ThemeMode.values.firstWhere(
        (t) => t.name == themeName,
        orElse: () => ThemeMode.system,
      ),
      locale: json['locale']?.toString(),
      pingCount: _int(json['pingCount'], 4).clamp(1, 50),
      pingTimeoutMs: _int(json['pingTimeoutMs'], 2000).clamp(200, 15000),
      scanTimeoutMs: _int(json['scanTimeoutMs'], 1200).clamp(200, 10000),
      scanConcurrency: _int(json['scanConcurrency'], 48).clamp(1, 128),
      deepScan: json['deepScan'] != false,
      resolveNames: json['resolveNames'] != false,
      showOffline: json['showOffline'] != false,
      portTimeoutMs: _int(json['portTimeoutMs'], 350).clamp(100, 5000),
    );
  }

  static int _int(Object? value, int fallback) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
