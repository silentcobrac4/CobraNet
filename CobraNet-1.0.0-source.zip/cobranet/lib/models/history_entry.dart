/// One line in the local tool history.
class HistoryEntry {
  HistoryEntry({
    required this.id,
    required this.tool,
    required this.query,
    required this.summary,
    required this.createdAt,
    this.detail,
    this.ok = true,
  });

  final String id;
  final String tool;
  final String query;
  final String summary;
  final String? detail;
  final DateTime createdAt;
  final bool ok;

  Map<String, dynamic> toJson() => {
        'id': id,
        'tool': tool,
        'query': query,
        'summary': summary,
        if (detail != null) 'detail': detail,
        'createdAt': createdAt.toIso8601String(),
        'ok': ok,
      };

  factory HistoryEntry.fromJson(Map<String, dynamic> json) => HistoryEntry(
        id: '${json['id']}',
        tool: '${json['tool']}',
        query: '${json['query']}',
        summary: '${json['summary']}',
        detail: json['detail']?.toString(),
        createdAt: DateTime.tryParse('${json['createdAt']}') ?? DateTime.now(),
        ok: json['ok'] != false,
      );
}
