import 'device.dart';

/// The result of one LAN scan, kept so the dashboard and history survive an
/// app restart.
class ScanSnapshot {
  ScanSnapshot({
    required this.startedAt,
    required this.finishedAt,
    required this.devices,
    this.ssid,
    this.localIp,
    this.gateway,
    this.cidr,
    this.cancelled = false,
  });

  final DateTime startedAt;
  final DateTime finishedAt;
  final List<Device> devices;
  final String? ssid;
  final String? localIp;
  final String? gateway;
  final String? cidr;
  final bool cancelled;

  int get onlineCount => devices.where((d) => d.online).length;

  Duration get duration => finishedAt.difference(startedAt);

  Map<String, dynamic> toJson() => {
        'startedAt': startedAt.toIso8601String(),
        'finishedAt': finishedAt.toIso8601String(),
        'ssid': ssid,
        'localIp': localIp,
        'gateway': gateway,
        'cidr': cidr,
        'cancelled': cancelled,
        'devices': devices.map((d) => d.toJson()).toList(),
      };

  factory ScanSnapshot.fromJson(Map<String, dynamic> json) {
    return ScanSnapshot(
      startedAt: DateTime.tryParse('${json['startedAt']}') ?? DateTime.now(),
      finishedAt: DateTime.tryParse('${json['finishedAt']}') ?? DateTime.now(),
      ssid: json['ssid']?.toString(),
      localIp: json['localIp']?.toString(),
      gateway: json['gateway']?.toString(),
      cidr: json['cidr']?.toString(),
      cancelled: json['cancelled'] == true,
      devices: (json['devices'] as List?)
              ?.whereType<Map>()
              .map((e) => Device.fromJson(Map<String, dynamic>.from(e)))
              .toList() ??
          <Device>[],
    );
  }
}
