import 'dart:math' as math;

import 'package:material_ui/material_ui.dart';

import '../core/l10n.dart';
import '../core/theme.dart';
import '../models/device.dart';

/// A small cobra made of network nodes: the snake's spine is a line of dots,
/// which doubles as the app's "connected devices" idea. Drawn in code, no
/// bitmap assets, no third-party artwork.
class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 44, this.showBackground = true});
  final double size;
  final bool showBackground;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _CobraPainter(showBackground: showBackground),
      ),
    );
  }
}

class _CobraPainter extends CustomPainter {
  _CobraPainter({required this.showBackground});
  final bool showBackground;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    if (showBackground) {
      final bg = Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF12D18E), Color(0xFF078A5D)],
        ).createShader(rect);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, Radius.circular(size.width * 0.28)),
        bg,
      );
    }

    final w = size.width;
    final h = size.height;
    final line = Paint()
      ..color = const Color(0xFF06251B).withValues(alpha: 0.9)
      ..strokeWidth = w * 0.075
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // S-shaped spine.
    final path = Path()
      ..moveTo(w * 0.62, h * 0.24)
      ..cubicTo(w * 0.34, h * 0.30, w * 0.70, h * 0.48, w * 0.44, h * 0.58)
      ..cubicTo(w * 0.24, h * 0.66, w * 0.34, h * 0.80, w * 0.56, h * 0.82);
    canvas.drawPath(path, line);

    // Nodes along the spine.
    final nodes = <Offset>[
      Offset(w * 0.62, h * 0.24),
      Offset(w * 0.50, h * 0.34),
      Offset(w * 0.55, h * 0.46),
      Offset(w * 0.44, h * 0.58),
      Offset(w * 0.38, h * 0.70),
      Offset(w * 0.56, h * 0.82),
    ];
    final nodePaint = Paint()..color = const Color(0xFF06251B);
    for (var i = 0; i < nodes.length; i++) {
      final r = i == 0 ? w * 0.055 : w * 0.036;
      canvas.drawCircle(nodes[i], r, nodePaint);
    }

    // Head: a rounded triangle with two eyes.
    final head = Path()
      ..moveTo(w * 0.58, h * 0.14)
      ..quadraticBezierTo(w * 0.78, h * 0.16, w * 0.76, h * 0.30)
      ..quadraticBezierTo(w * 0.68, h * 0.38, w * 0.58, h * 0.28)
      ..close();
    canvas.drawPath(head, Paint()..color = const Color(0xFF06251B));
    canvas.drawCircle(
      Offset(w * 0.66, h * 0.22),
      w * 0.017,
      Paint()..color = const Color(0xFF12D18E),
    );
    canvas.drawCircle(
      Offset(w * 0.72, h * 0.245),
      w * 0.014,
      Paint()..color = const Color(0xFFFFD166),
    );

    // Tongue.
    final tongue = Paint()
      ..color = const Color(0xFFFF5C5C)
      ..strokeWidth = w * 0.022
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(w * 0.76, h * 0.28),
      Offset(w * 0.87, h * 0.31),
      tongue,
    );
    canvas.drawLine(
      Offset(w * 0.87, h * 0.31),
      Offset(w * 0.92, h * 0.27),
      tongue,
    );
  }

  @override
  bool shouldRepaint(covariant _CobraPainter oldDelegate) =>
      oldDelegate.showBackground != showBackground;
}

class DeviceGlyph extends StatelessWidget {
  const DeviceGlyph({
    super.key,
    required this.type,
    this.size = 42,
    this.iconSize,
  });

  final DeviceType type;
  final double size;
  final double? iconSize;

  static IconData iconFor(DeviceType type) {
    switch (type) {
      case DeviceType.router:
        return Icons.router_rounded;
      case DeviceType.thisDevice:
        return Icons.phone_android_rounded;
      case DeviceType.phone:
        return Icons.smartphone_rounded;
      case DeviceType.computer:
        return Icons.laptop_mac_rounded;
      case DeviceType.printer:
        return Icons.print_rounded;
      case DeviceType.camera:
        return Icons.videocam_rounded;
      case DeviceType.tv:
        return Icons.tv_rounded;
      case DeviceType.nas:
        return Icons.dns_rounded;
      case DeviceType.iot:
        return Icons.sensors_rounded;
      case DeviceType.console:
        return Icons.sports_esports_rounded;
      case DeviceType.unknown:
        return Icons.devices_other_rounded;
    }
  }

  static Color colorFor(DeviceType type) {
    switch (type) {
      case DeviceType.router:
        return AppColors.accent;
      case DeviceType.thisDevice:
        return AppColors.primary;
      case DeviceType.phone:
        return const Color(0xFF6FC3FF);
      case DeviceType.computer:
        return const Color(0xFF9C8CFF);
      case DeviceType.printer:
        return const Color(0xFFFF9F6B);
      case DeviceType.camera:
        return const Color(0xFFFF7A8A);
      case DeviceType.tv:
        return const Color(0xFF5FE3D0);
      case DeviceType.nas:
        return const Color(0xFFB6D86F);
      case DeviceType.iot:
        return const Color(0xFFF1A7FF);
      case DeviceType.console:
        return const Color(0xFF8FD47A);
      case DeviceType.unknown:
        return AppColors.darkMuted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = colorFor(type);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(size * 0.3),
        border: Border.all(color: color.withValues(alpha: 0.22)),
      ),
      child: Icon(
        iconFor(type),
        color: color,
        size: iconSize ?? size * 0.48,
      ),
    );
  }
}

String deviceTypeLabel(BuildContext context, DeviceType type) {
  switch (type) {
    case DeviceType.router:
      return context.tr('موجّه', 'Router');
    case DeviceType.thisDevice:
      return context.tr('هذا الجهاز', 'This device');
    case DeviceType.phone:
      return context.tr('هاتف', 'Phone');
    case DeviceType.computer:
      return context.tr('حاسوب', 'Computer');
    case DeviceType.printer:
      return context.tr('طابعة', 'Printer');
    case DeviceType.camera:
      return context.tr('كاميرا', 'Camera');
    case DeviceType.tv:
      return context.tr('تلفاز', 'TV');
    case DeviceType.nas:
      return context.tr('تخزين شبكي', 'NAS');
    case DeviceType.iot:
      return context.tr('جهاز ذكي', 'Smart device');
    case DeviceType.console:
      return context.tr('ألعاب', 'Console');
    case DeviceType.unknown:
      return context.tr('جهاز', 'Device');
  }
}

/// A slow radar sweep used while a scan runs.
class ScanRadar extends StatefulWidget {
  const ScanRadar({
    super.key,
    this.size = 168,
    this.active = true,
    this.found = 0,
    this.progress = 0,
    this.child,
  });

  final double size;
  final bool active;
  final int found;
  final double progress;
  final Widget? child;

  @override
  State<ScanRadar> createState() => _ScanRadarState();
}

class _ScanRadarState extends State<ScanRadar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2600),
  );

  @override
  void initState() {
    super.initState();
    if (widget.active) _controller.repeat();
  }

  @override
  void didUpdateWidget(covariant ScanRadar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !_controller.isAnimating) {
      _controller.repeat();
    } else if (!widget.active && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: Semantics(
        label: widget.active ? 'جارٍ الفحص' : 'شبكة',
        child: Stack(
          alignment: Alignment.center,
          children: [
            AnimatedBuilder(
              animation: _controller,
              builder: (context, _) => CustomPaint(
                size: Size.square(widget.size),
                painter: _RadarPainter(
                  angle: _controller.value * math.pi * 2,
                  found: widget.found,
                  progress: widget.progress,
                  dark: context.isDark,
                  active: widget.active,
                ),
              ),
            ),
            if (widget.child != null) widget.child!,
          ],
        ),
      ),
    );
  }
}

class _RadarPainter extends CustomPainter {
  _RadarPainter({
    required this.angle,
    required this.found,
    required this.progress,
    required this.dark,
    required this.active,
  });

  final double angle;
  final int found;
  final double progress;
  final bool dark;
  final bool active;

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.width / 2;
    final base = dark ? const Color(0xFF16241F) : const Color(0xFFE7F1EB);

    canvas.drawCircle(center, radius, Paint()..color = base);

    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = (dark ? Colors.white : Colors.black).withValues(alpha: 0.09);
    for (var i = 1; i <= 3; i++) {
      canvas.drawCircle(center, radius * i / 3.4, ring);
    }
    canvas.drawLine(
      Offset(center.dx - radius * 0.8, center.dy),
      Offset(center.dx + radius * 0.8, center.dy),
      ring,
    );
    canvas.drawLine(
      Offset(center.dx, center.dy - radius * 0.8),
      Offset(center.dx, center.dy + radius * 0.8),
      ring,
    );

    if (active) {
      final sweepRect = Rect.fromCircle(center: center, radius: radius * 0.94);
      final sweep = Paint()
        ..shader = SweepGradient(
          startAngle: angle - 1.1,
          endAngle: angle,
          colors: [
            AppColors.primary.withValues(alpha: 0.0),
            AppColors.primary.withValues(alpha: 0.32),
          ],
          transform: GradientRotation(0),
        ).createShader(sweepRect)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(center, radius * 0.94, sweep);

      final line = Paint()
        ..color = AppColors.primary.withValues(alpha: 0.8)
        ..strokeWidth = 1.6
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(
        center,
        Offset(
          center.dx + math.cos(angle) * radius * 0.92,
          center.dy + math.sin(angle) * radius * 0.92,
        ),
        line,
      );
    }

    // Device dots, placed deterministically so they do not jump around.
    final count = found.clamp(0, 14);
    for (var i = 0; i < count; i++) {
      final a = (i * 2.399963) % (math.pi * 2);
      final r = radius * (0.22 + ((i % 5) * 0.12));
      final dot = Offset(
        center.dx + math.cos(a) * r,
        center.dy + math.sin(a) * r,
      );
      canvas.drawCircle(
        dot,
        2.8,
        Paint()..color = AppColors.primary.withValues(alpha: 0.9),
      );
      canvas.drawCircle(
        dot,
        5.2,
        Paint()..color = AppColors.primary.withValues(alpha: 0.16),
      );
    }

    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = AppColors.primary;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - 1.5),
      -math.pi / 2,
      math.pi * 2 * progress.clamp(0, 1),
      false,
      arc,
    );
  }

  @override
  bool shouldRepaint(covariant _RadarPainter oldDelegate) =>
      oldDelegate.angle != angle ||
      oldDelegate.found != found ||
      oldDelegate.progress != progress ||
      oldDelegate.active != active;
}
