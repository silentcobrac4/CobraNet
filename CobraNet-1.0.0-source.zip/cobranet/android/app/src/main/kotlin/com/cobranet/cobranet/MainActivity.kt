package com.cobranet.cobranet

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
